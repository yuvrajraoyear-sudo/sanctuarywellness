// ---------- state & utils ----------
const state = { classes: [], categories: [], filter: { category: null, intensity: null }, email: localStorage.getItem('pulse_email') || '' };

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const el = (tag, props = {}, ...children) => {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k.startsWith('on')) node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'style' && typeof v === 'object') Object.assign(node.style, v);
    else node.setAttribute(k, v);
  }
  for (const c of children) {
    if (c == null || c === false) continue;
    node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return node;
};

const fmtTime = (iso) => new Date(iso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
const fmtDay = (iso) => {
  const d = new Date(iso), now = new Date();
  const days = Math.floor((d - now) / 86400000);
  const opts = { weekday: 'long', month: 'short', day: 'numeric' };
  if (d.toDateString() === now.toDateString()) return 'Today';
  const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1);
  if (d.toDateString() === tomorrow.toDateString()) return 'Tomorrow';
  return d.toLocaleDateString([], opts);
};
const fmtDayKey = (iso) => new Date(iso).toDateString();

function toast(msg, type = '') {
  const t = el('div', { class: `toast ${type}` }, msg);
  $('#toast-root').appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 300); }, 3200);
}

async function api(path, options = {}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------- router ----------
const routes = { home: renderHome, classes: renderClasses, schedule: renderSchedule, mybookings: renderBookings };
function navigate(route) {
  location.hash = '#' + route;
  const view = routes[route] || routes.home;
  $$('.nav-links a').forEach(a => a.classList.toggle('active', a.dataset.route === route));
  const app = $('#app'); app.innerHTML = ''; view(app);
  window.scrollTo(0, 0);
}

document.addEventListener('click', (e) => {
  const t = e.target.closest('[data-route]');
  if (t) { e.preventDefault(); navigate(t.dataset.route); }
});

// ---------- data ----------
async function loadClasses() {
  const [c, cats] = await Promise.all([
    api('/api/classes' + buildQuery()),
    state.categories.length ? Promise.resolve(state.categories) : api('/api/categories')
  ]);
  state.classes = c; state.categories = cats;
}

function buildQuery() {
  const p = new URLSearchParams();
  if (state.filter.category) p.set('category', state.filter.category);
  if (state.filter.intensity) p.set('intensity', state.filter.intensity);
  const q = p.toString(); return q ? '?' + q : '';
}

// ---------- views ----------
function renderHome(root) {
  const hero = el('section', { class: 'hero' },
    el('div', { class: 'wrap hero-grid' },
      el('div', {},
        el('span', { class: 'eyebrow' }, 'New — 200+ classes every week'),
        el('h1', {}, 'Move better. Feel better. Every day.'),
        el('p', { class: 'lede' }, 'Book strength, yoga, cardio and mobility classes from top trainers in your city. One membership. Zero friction.'),
        el('div', { class: 'hero-cta' },
          el('button', { class: 'btn btn-primary', 'data-route': 'classes' }, 'Explore classes'),
          el('button', { class: 'btn', 'data-route': 'schedule' }, 'View schedule')
        ),
        el('div', { class: 'hero-stats' },
          el('div', {}, el('div', { class: 'num' }, '50+'), el('div', { class: 'lbl' }, 'Trainers')),
          el('div', {}, el('div', { class: 'num' }, '12'), el('div', { class: 'lbl' }, 'Studios')),
          el('div', {}, el('div', { class: 'num' }, '4.9★'), el('div', { class: 'lbl' }, 'Avg rating'))
        )
      ),
      el('div', { class: 'hero-visual' },
        el('img', { src: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=900&q=80', alt: 'Fitness' }),
        el('div', { class: 'hero-card' },
          el('div', { class: 'avatar' }, 'P'),
          el('div', { class: 'meta' }, el('strong', {}, 'HIIT Blast'), el('span', {}, 'Today · 6:00 PM · Priya Sharma')),
          el('div', { class: 'live' }, 'Booking')
        )
      )
    )
  );

  const features = el('section', { class: 'section' },
    el('div', { class: 'wrap' },
      el('div', { class: 'section-head' },
        el('div', {}, el('h2', {}, 'Why Pulse'), el('p', {}, 'A better way to build the fitness habit — designed around your schedule, energy and goals.'))
      ),
      el('div', { class: 'features' },
        el('div', { class: 'feat' }, el('div', { class: 'feat-icon' }, '⚡'), el('h4', {}, 'One-tap booking'), el('p', {}, 'Reserve a spot in seconds. Cancel anytime, no penalty.')),
        el('div', { class: 'feat' }, el('div', { class: 'feat-icon' }, '🎯'), el('h4', {}, 'Every discipline'), el('p', {}, 'Yoga, strength, HIIT, boxing, cycling, Pilates — all under one roof.')),
        el('div', { class: 'feat' }, el('div', { class: 'feat-icon' }, '🌱'), el('h4', {}, 'Trainers who care'), el('p', {}, 'Every trainer is vetted, certified and rated by the community.'))
      )
    )
  );

  root.appendChild(hero);
  root.appendChild(features);
  root.appendChild(renderPopular());
}

function renderPopular() {
  const section = el('section', { class: 'section', style: { paddingTop: '0' } });
  const wrap = el('div', { class: 'wrap' });
  wrap.appendChild(el('div', { class: 'section-head' },
    el('div', {}, el('h2', {}, 'Popular this week'), el('p', {}, 'Trending classes with spots still available.')),
    el('button', { class: 'btn', 'data-route': 'classes' }, 'See all')
  ));
  const grid = el('div', { class: 'grid' });
  wrap.appendChild(grid);
  section.appendChild(wrap);

  for (let i = 0; i < 6; i++) grid.appendChild(el('div', { class: 'skel skel-card' }));

  loadClasses().then(() => {
    grid.innerHTML = '';
    state.classes.slice(0, 6).forEach(c => grid.appendChild(classCard(c)));
  }).catch(e => { grid.innerHTML = ''; grid.appendChild(el('p', {}, 'Could not load classes.')); });

  return section;
}

function classCard(c) {
  const spotsClass = c.spots_left === 0 ? 'full' : c.spots_left <= 3 ? 'low' : '';
  const spotsText = c.spots_left === 0 ? 'Fully booked' : `${c.spots_left} spots left`;

  return el('div', { class: 'card' },
    el('div', { class: 'card-img' },
      el('img', { src: c.image_url, alt: c.title, loading: 'lazy' }),
      el('div', { class: 'card-tag' }, c.category)
    ),
    el('div', { class: 'card-body' },
      el('h3', {}, c.title),
      el('div', { class: 'card-meta' },
        el('span', {}, fmtDay(c.starts_at)),
        el('span', { class: 'dot' }),
        el('span', {}, fmtTime(c.starts_at)),
        el('span', { class: 'dot' }),
        el('span', {}, `${c.duration} min`)
      ),
      el('div', { class: 'card-meta' },
        el('span', {}, c.trainer),
        el('span', { class: 'dot' }),
        el('span', {}, c.location)
      ),
      el('div', { class: 'card-foot' },
        el('span', { class: `card-spots ${spotsClass}` }, spotsText),
        el('button', {
          class: 'btn btn-accent',
          disabled: c.spots_left === 0 ? '' : null,
          onClick: () => openBooking(c)
        }, c.spots_left === 0 ? 'Full' : 'Book')
      )
    )
  );
}

function renderClasses(root) {
  const hero = el('section', { class: 'section', style: { paddingTop: '48px', paddingBottom: '24px' } },
    el('div', { class: 'wrap' },
      el('span', { class: 'eyebrow' }, 'Book a class'),
      el('h1', { style: { marginTop: '12px' } }, 'Find your next workout'),
      el('p', { class: 'lede', style: { marginTop: '12px' } }, 'Filter by discipline and intensity to match how you feel today.')
    )
  );

  const filtersRow = el('div', { class: 'wrap' });
  const catFilters = el('div', { class: 'filters' });
  const intFilters = el('div', { class: 'filters' });
  const grid = el('div', { class: 'grid' });

  function rebuildFilters() {
    catFilters.innerHTML = '';
    const catChip = (name, val) => el('button', {
      class: 'chip' + (state.filter.category === val ? ' active' : ''),
      onClick: () => { state.filter.category = val; refresh(); }
    }, name);
    catFilters.appendChild(catChip('All', null));
    state.categories.forEach(c => catFilters.appendChild(catChip(c, c)));

    intFilters.innerHTML = '';
    const intChip = (name, val) => el('button', {
      class: 'chip' + (state.filter.intensity === val ? ' active' : ''),
      onClick: () => { state.filter.intensity = val; refresh(); }
    }, name);
    ['Low','Medium','High'].forEach(l => {
      const isActive = state.filter.intensity === l;
      intFilters.appendChild(intChip(l + ' intensity', isActive ? null : l));
    });
  }

  async function refresh() {
    grid.innerHTML = '';
    for (let i = 0; i < 6; i++) grid.appendChild(el('div', { class: 'skel skel-card' }));
    rebuildFilters();
    try {
      await loadClasses();
      grid.innerHTML = '';
      if (!state.classes.length) {
        grid.appendChild(el('div', { class: 'empty', style: { gridColumn: '1 / -1' } },
          el('h3', {}, 'No classes match'),
          el('p', {}, 'Try clearing filters to see everything on offer.')
        ));
        return;
      }
      state.classes.forEach(c => grid.appendChild(classCard(c)));
    } catch (e) {
      grid.innerHTML = ''; grid.appendChild(el('p', {}, 'Failed to load classes.'));
    }
  }

  filtersRow.appendChild(catFilters);
  filtersRow.appendChild(intFilters);

  root.appendChild(hero);
  root.appendChild(filtersRow);
  root.appendChild(el('section', { class: 'section', style: { paddingTop: '24px' } }, el('div', { class: 'wrap' }, grid)));
  refresh();
}

function renderSchedule(root) {
  const hero = el('section', { class: 'section', style: { paddingTop: '48px', paddingBottom: '24px' } },
    el('div', { class: 'wrap' },
      el('span', { class: 'eyebrow' }, 'Weekly schedule'),
      el('h1', { style: { marginTop: '12px' } }, 'Plan your week'),
      el('p', { class: 'lede', style: { marginTop: '12px' } }, 'Every upcoming class across all studios, day by day.')
    )
  );

  const container = el('div', { class: 'wrap' });
  container.appendChild(el('p', { class: 'muted' }, 'Loading schedule…'));

  loadClasses().then(() => {
    container.innerHTML = '';
    if (!state.classes.length) {
      container.appendChild(el('div', { class: 'empty' }, el('h3', {}, 'Nothing scheduled'), el('p', {}, 'Check back soon.')));
      return;
    }
    const grouped = {};
    state.classes.forEach(c => { const k = fmtDayKey(c.starts_at); (grouped[k] = grouped[k] || []).push(c); });
    Object.entries(grouped).forEach(([day, list]) => {
      const dayEl = el('div', { class: 'schedule-day' });
      dayEl.appendChild(el('h3', {}, fmtDay(list[0].starts_at)));
      list.forEach(c => {
        const spotsClass = c.spots_left === 0 ? 'full' : c.spots_left <= 3 ? 'low' : '';
        dayEl.appendChild(el('div', { class: 'schedule-row' },
          el('div', { class: 'time' }, fmtTime(c.starts_at), el('small', {}, `${c.duration} min`)),
          el('div', { class: 'info' },
            el('h4', {}, c.title),
            el('div', { class: 'card-meta' },
              el('span', {}, c.category),
              el('span', { class: 'dot' }),
              el('span', {}, c.trainer),
              el('span', { class: 'dot' }),
              el('span', {}, c.location)
            )
          ),
          el('div', { class: 'r-right', style: { display: 'contents' } },
            el('span', { class: `card-spots ${spotsClass}` }, c.spots_left === 0 ? 'Full' : `${c.spots_left} left`),
            el('button', {
              class: 'btn btn-accent', disabled: c.spots_left === 0 ? '' : null,
              onClick: () => openBooking(c)
            }, c.spots_left === 0 ? 'Full' : 'Book')
          )
        ));
      });
      container.appendChild(dayEl);
    });
  });

  root.appendChild(hero);
  root.appendChild(el('section', { class: 'section', style: { paddingTop: '0' } }, container));
}

function renderBookings(root) {
  const hero = el('section', { class: 'section', style: { paddingTop: '48px', paddingBottom: '24px' } },
    el('div', { class: 'wrap' },
      el('span', { class: 'eyebrow' }, 'Your reservations'),
      el('h1', { style: { marginTop: '12px' } }, 'My bookings'),
      el('p', { class: 'lede', style: { marginTop: '12px' } }, 'Look up your bookings by the email you used to reserve.')
    )
  );

  const wrap = el('div', { class: 'wrap' });
  const input = el('input', { type: 'email', placeholder: 'you@example.com', value: state.email });
  const lookupBtn = el('button', { class: 'btn btn-primary', onClick: doLookup }, 'Look up');
  wrap.appendChild(el('div', { class: 'email-lookup' }, input, lookupBtn));

  const list = el('div', {});
  wrap.appendChild(list);

  async function doLookup() {
    const email = input.value.trim();
    if (!email) return toast('Enter an email first', 'error');
    state.email = email; localStorage.setItem('pulse_email', email);
    list.innerHTML = '<p class="muted">Loading…</p>';
    try {
      const rows = await api('/api/bookings?email=' + encodeURIComponent(email));
      list.innerHTML = '';
      if (!rows.length) {
        list.appendChild(el('div', { class: 'empty' },
          el('h3', {}, 'No bookings yet'),
          el('p', {}, 'Book your first class to see it here.'),
          el('button', { class: 'btn btn-primary', 'data-route': 'classes', style: { marginTop: '16px' } }, 'Browse classes')
        ));
        return;
      }
      rows.forEach(b => {
        list.appendChild(el('div', { class: 'booking-card' },
          el('img', { src: b.image_url, alt: b.title }),
          el('div', {},
            el('div', { style: { marginBottom: '6px' } }, el('span', { class: `status ${b.status}` }, b.status)),
            el('h4', { style: { fontSize: '1.05rem', fontWeight: '600', marginBottom: '4px', fontFamily: 'Inter,sans-serif' } }, b.title),
            el('div', { class: 'card-meta' },
              el('span', {}, fmtDay(b.starts_at)),
              el('span', { class: 'dot' }),
              el('span', {}, fmtTime(b.starts_at)),
              el('span', { class: 'dot' }),
              el('span', {}, b.trainer),
              el('span', { class: 'dot' }),
              el('span', {}, b.location)
            )
          ),
          el('div', { class: 'b-actions' },
            b.status === 'confirmed'
              ? el('button', { class: 'btn btn-danger', onClick: () => cancelBooking(b.booking_id, email, doLookup) }, 'Cancel')
              : el('span', { class: 'muted', style: { fontSize: '.85rem' } }, 'Cancelled')
          )
        ));
      });
    } catch (e) { list.innerHTML = ''; toast(e.message, 'error'); }
  }

  if (state.email) doLookup();

  root.appendChild(hero);
  root.appendChild(el('section', { class: 'section', style: { paddingTop: '0' } }, wrap));
}

async function cancelBooking(id, email, cb) {
  if (!confirm('Cancel this booking?')) return;
  try {
    await api(`/api/bookings/${id}/cancel`, { method: 'POST', body: JSON.stringify({ email }) });
    toast('Booking cancelled', 'success');
    cb && cb();
  } catch (e) { toast(e.message, 'error'); }
}

// ---------- booking modal ----------
function openBooking(cls) {
  const overlay = el('div', { class: 'modal-overlay', onClick: (e) => { if (e.target === overlay) overlay.remove(); } });
  const name = el('input', { type: 'text', placeholder: 'Your name', required: '' });
  const email = el('input', { type: 'email', placeholder: 'you@example.com', value: state.email, required: '' });
  const phone = el('input', { type: 'tel', placeholder: 'Optional' });
  const submit = el('button', { class: 'btn btn-accent btn-block', style: { marginTop: '8px' } }, 'Confirm booking');

  const form = el('form', {
    onSubmit: async (e) => {
      e.preventDefault();
      submit.disabled = true; submit.textContent = 'Booking…';
      try {
        await api('/api/bookings', {
          method: 'POST',
          body: JSON.stringify({
            class_id: cls.id,
            user_name: name.value.trim(),
            user_email: email.value.trim(),
            user_phone: phone.value.trim() || null
          })
        });
        state.email = email.value.trim();
        localStorage.setItem('pulse_email', state.email);
        toast('Booking confirmed! 🎉', 'success');
        overlay.remove();
        // refresh current view
        const current = (location.hash || '#home').slice(1);
        navigate(current);
      } catch (err) {
        toast(err.message, 'error');
        submit.disabled = false; submit.textContent = 'Confirm booking';
      }
    }
  },
    el('div', { class: 'field' }, el('label', {}, 'Full name'), name),
    el('div', { class: 'field' }, el('label', {}, 'Email'), email),
    el('div', { class: 'field' }, el('label', {}, 'Phone (optional)'), phone),
    submit
  );

  const modal = el('div', { class: 'modal', style: { position: 'relative' } },
    el('button', { class: 'modal-close', onClick: () => overlay.remove() }, '×'),
    el('h2', {}, cls.title),
    el('p', { class: 'sub' }, `${cls.trainer} · ${cls.location}`),
    el('div', { class: 'summary' },
      el('div', { class: 'row' }, el('span', {}, 'When'), el('span', {}, `${fmtDay(cls.starts_at)} · ${fmtTime(cls.starts_at)}`)),
      el('div', { class: 'row' }, el('span', {}, 'Duration'), el('span', {}, `${cls.duration} min`)),
      el('div', { class: 'row' }, el('span', {}, 'Intensity'), el('span', {}, cls.intensity)),
      el('div', { class: 'row' }, el('span', {}, 'Spots left'), el('span', {}, cls.spots_left))
    ),
    form
  );

  overlay.appendChild(modal);
  $('#modal-root').appendChild(overlay);
  setTimeout(() => name.focus(), 100);
}

// ---------- boot ----------
const initial = (location.hash || '#home').slice(1);
navigate(routes[initial] ? initial : 'home');
