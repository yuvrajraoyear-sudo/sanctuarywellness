const express = require('express');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- in-memory store ----------
const store = { classes: [], bookings: [], nextClassId: 1, nextBookingId: 1 };

function seed() {
  const now = new Date();
  const at = (dayOffset, hour, min = 0) => {
    const d = new Date(now);
    d.setDate(d.getDate() + dayOffset);
    d.setHours(hour, min, 0, 0);
    return d.toISOString();
  };
  const rows = [
    ['Sunrise Yoga Flow', 'Yoga', 'Aarav Mehta', 'Downtown Studio', 60, 20, 'Low',
      'Gentle vinyasa flow to start your day with balance and mindfulness.',
      'https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=1200', at(0, 7)],
    ['HIIT Blast', 'HIIT', 'Priya Sharma', 'Central Gym', 45, 15, 'High',
      'High intensity intervals to torch calories and build endurance.',
      'https://images.unsplash.com/photo-1518611012118-696072aa579a?w=1200', at(0, 18)],
    ['Strength & Conditioning', 'Strength', 'Rohan Kapoor', 'Iron House', 60, 12, 'Medium',
      'Compound lifts and functional strength work for all levels.',
      'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200', at(1, 9)],
    ['Spin Ride', 'Cardio', 'Neha Kulkarni', 'Cycle Room', 45, 24, 'High',
      'Beat-driven indoor cycling class with climbs, sprints and recovery.',
      'https://images.unsplash.com/photo-1591741535018-d042766c62eb?w=1200', at(1, 19)],
    ['Boxing Basics', 'Boxing', 'Vikram Rao', 'The Ring', 55, 16, 'High',
      'Learn stance, footwork and combinations in a supportive setting.',
      'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?w=1200', at(2, 18, 30)],
    ['Deep Stretch & Mobility', 'Mobility', 'Meera Iyer', 'Zen Corner', 45, 18, 'Low',
      'Slow, targeted stretches to release tension and improve range.',
      'https://images.unsplash.com/photo-1552693673-1bf958298935?w=1200', at(2, 8)],
    ['Pilates Core', 'Pilates', 'Ananya Das', 'Studio B', 50, 14, 'Medium',
      'Precision core work using mat-based Pilates principles.',
      'https://images.unsplash.com/photo-1518310383802-640c2de311b2?w=1200', at(3, 10)],
    ['Functional Training', 'Strength', 'Karan Malhotra', 'Iron House', 55, 12, 'Medium',
      'Movement patterns that translate to real-world strength.',
      'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=1200', at(3, 17)],
    ['Kickboxing Cardio', 'Cardio', 'Sana Ali', 'The Ring', 50, 18, 'High',
      'Fast-paced kickboxing choreography set to music.',
      'https://images.unsplash.com/photo-1517438322307-e67111335449?w=1200', at(4, 18)],
    ['Restorative Yoga', 'Yoga', 'Aarav Mehta', 'Zen Corner', 60, 20, 'Low',
      'Longer holds with props for deep nervous-system reset.',
      'https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=1200', at(4, 20)],
    ['Barre Sculpt', 'Pilates', 'Ananya Das', 'Studio B', 50, 16, 'Medium',
      'Ballet-inspired isometric work for lean, toned muscles.',
      'https://images.unsplash.com/photo-1518310952931-b1de897abd40?w=1200', at(5, 9)],
    ['Bootcamp', 'HIIT', 'Priya Sharma', 'Outdoor Park', 60, 20, 'High',
      'Full body circuit outdoors — bodyweight, bands and sled.',
      'https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200', at(5, 7)]
  ];
  for (const r of rows) {
    store.classes.push({
      id: store.nextClassId++,
      title: r[0], category: r[1], trainer: r[2], location: r[3],
      duration: r[4], capacity: r[5], intensity: r[6],
      description: r[7], image_url: r[8], starts_at: r[9]
    });
  }
}
seed();

// ---------- helpers ----------
function bad(res, code, msg) { return res.status(code).json({ error: msg }); }
function spotsLeft(cls) {
  const booked = store.bookings.filter(b => b.class_id === cls.id && b.status === 'confirmed').length;
  return { booked, spots_left: Math.max(0, cls.capacity - booked) };
}
function withSpots(cls) { return { ...cls, ...spotsLeft(cls) }; }

// ---------- API ----------
app.get('/api/classes', (req, res) => {
  const { category, intensity } = req.query;
  const cutoff = Date.now() - 60 * 60 * 1000;
  let list = store.classes.filter(c => new Date(c.starts_at).getTime() >= cutoff);
  if (category) list = list.filter(c => c.category === category);
  if (intensity) list = list.filter(c => c.intensity === intensity);
  list.sort((a, b) => new Date(a.starts_at) - new Date(b.starts_at));
  res.json(list.map(withSpots));
});

app.get('/api/classes/:id', (req, res) => {
  const cls = store.classes.find(c => c.id === Number(req.params.id));
  if (!cls) return bad(res, 404, 'Class not found');
  res.json(withSpots(cls));
});

app.get('/api/categories', (req, res) => {
  const set = new Set(store.classes.map(c => c.category));
  res.json(Array.from(set).sort());
});

app.post('/api/bookings', (req, res) => {
  const { class_id, user_name, user_email, user_phone } = req.body || {};
  if (!class_id || !user_name || !user_email) return bad(res, 400, 'Missing required fields');
  if (!/^\S+@\S+\.\S+$/.test(user_email)) return bad(res, 400, 'Invalid email');

  const cls = store.classes.find(c => c.id === Number(class_id));
  if (!cls) return bad(res, 404, 'Class not found');

  const dupe = store.bookings.find(b => b.class_id === cls.id && b.user_email === user_email && b.status === 'confirmed');
  if (dupe) return bad(res, 409, 'You have already booked this class');

  const { spots_left } = spotsLeft(cls);
  if (spots_left <= 0) return bad(res, 409, 'Class is fully booked');

  const booking = {
    id: store.nextBookingId++,
    class_id: cls.id,
    user_name, user_email, user_phone: user_phone || null,
    status: 'confirmed',
    created_at: new Date().toISOString()
  };
  store.bookings.push(booking);
  res.json({ id: booking.id, class_id: cls.id, status: 'confirmed' });
});

app.get('/api/bookings', (req, res) => {
  const email = (req.query.email || '').toString();
  if (!email) return res.json([]);
  const rows = store.bookings
    .filter(b => b.user_email === email)
    .map(b => {
      const c = store.classes.find(x => x.id === b.class_id);
      return {
        booking_id: b.id, status: b.status, created_at: b.created_at,
        class_id: c.id, title: c.title, category: c.category, trainer: c.trainer,
        location: c.location, duration: c.duration, image_url: c.image_url, starts_at: c.starts_at
      };
    })
    .sort((a, b) => new Date(a.starts_at) - new Date(b.starts_at));
  res.json(rows);
});

app.post('/api/bookings/:id/cancel', (req, res) => {
  const { email } = req.body || {};
  if (!email) return bad(res, 400, 'Email required');
  const b = store.bookings.find(x => x.id === Number(req.params.id) && x.user_email === email);
  if (!b) return bad(res, 404, 'Booking not found');
  b.status = 'cancelled';
  res.json({ ok: true });
});

// ---------- boot ----------
const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => console.log(`fitapp on ${PORT}`));
