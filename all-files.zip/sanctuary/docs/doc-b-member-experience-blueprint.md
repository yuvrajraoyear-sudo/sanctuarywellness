# Doc B — Member Experience Blueprint
**Project:** Sanctuary Wellness by Play Haus
**Version:** 1.0
**Owner:** Hospitality + Product

The blueprint maps every meaningful moment in a member's relationship with Sanctuary — from the first whisper of interest to a returning member 18 months in. For each stage it captures the **physical**, **digital**, **emotional**, and **operational** layers so software choices reflect real hospitality, not the other way around.

**How to read a stage:**
- **Moment** — the human moment
- **Physical** — what happens in the club
- **Digital** — what happens in the app / channels
- **Emotional job** — what the member should feel
- **Standard** — the promise we're making
- **Failure mode** — what mustn't happen
- **Ops owner** — who is accountable

---

## Stage 1 — First Inquiry

**Moment.** A prospective member hears about Sanctuary — a friend, a workshop, HYROX, Paradiso, Instagram.

**Physical.** N/A (may include Paradiso café visit).

**Digital.**
- Landing page (Play Haus / Sanctuary micro-site — outside V1 app scope)
- WhatsApp / email inquiry form
- Manager receives lead in staff CRM

**Emotional job.** *Curiosity acknowledged, not exploited.*

**Standard.**
- Response within 90 minutes during club hours, always by a named human ("Hi — I'm Aditi from Sanctuary…")
- First message includes an invitation to visit, never a price list

**Failure mode.** Automated reply that reads like a form.

**Ops owner.** Manager on duty (front-of-house).

---

## Stage 2 — The Tour

**Moment.** Prospective member walks the club with a host.

**Physical.**
- 45-minute walk-through: reception → mobility studio → recovery suite (sauna, steam, ice, contrast) → breath studio → Paradiso corner
- Complimentary Paradiso item at the end
- No pitch. Host answers questions.

**Digital.**
- Host takes a **Signature-lite** note on tablet during the tour: preferred time, goals, injuries, coffee preference
- On tour end, host offers to send a summary via WhatsApp — with no CTA

**Emotional job.** *Welcomed, not sold.*

**Standard.**
- One host per tour, no overlap
- The follow-up WhatsApp is a note, not a brochure

**Failure mode.** A hard close, a pricing PDF, or asking for a decision on the spot.

**Ops owner.** Host / manager.

---

## Stage 3 — Joining

**Moment.** The member decides. The paperwork.

**Physical.**
- Manager completes a short intake in a quiet room — medical basics, goals, contraindications
- Membership card handed over in a small linen sleeve (physical artefact matters)
- Locker allocated; locker number is recorded on the member's Signature

**Digital.**
- Manager provisions the account in the staff panel: creates the member record, sets tier (Explorer), records Signature-lite from tour
- Member receives a short welcome email: warm, one CTA — "Open the app"
- WhatsApp welcome from the manager (personal, signed)
- First app open: onboarding is **six screens** max — see Stage 4

**Emotional job.** *Received, not processed.*

**Standard.**
- No forms over three fields at once
- Onboarding is completable in under 4 minutes
- The membership card is physical, well made, and not an afterthought

**Failure mode.** Any legalese, any surprise charge, any generic system email.

**Ops owner.** Manager (physical), Product (digital onboarding flow).

---

## Stage 4 — First App Open (Onboarding)

**Moment.** Member opens the Sanctuary app at home the day of joining.

**Digital flow (6 screens):**
1. **The Welcome** — a full-bleed image, member's first name, one line: *"Welcome, Yuvraj."* Tap to continue.
2. **What brings you here** — 4 chips (Recovery · Movement · Performance · Calm) — multi-select. Feeds Concierge.
3. **When are you here** — morning / midday / evening / weekend — for scheduling recommendations.
4. **A few preferences (Signature)** — sauna temp, herbal tea, coffee. Skippable.
5. **Sensitive** — injuries, contraindications (private, staff-visible only). Skippable, clearly optional.
6. **Your first ritual** — one recommended Ritual (usually a Recovery Reset) with a "Reserve" button and a "Later" button.

**Emotional job.** *Known already.*

**Standard.**
- Skippable at every step
- No account creation friction (invite-linked)
- After onboarding, member lands on the Arrival dashboard populated with their preferences

**Failure mode.** A 12-screen tour, a "profile completeness" bar, gamified onboarding.

**Ops owner.** Product.

---

## Stage 5 — First Visit

**Moment.** The member walks in for their first ritual.

**Physical.**
- Reception recognises the member by first name — Signature card is visible on the staff tablet
- Locker key is already prepared (Signature: preferred locker); a towel of their preferred weight
- Preferred herbal tea is brewed or ready
- Trainer / attendant introduces themselves and walks the ritual with the member

**Digital.**
- On entering, member's phone offers to check in (geofence + QR fallback)
- App switches to a **"You've arrived"** mode: reduced surface, only the ritual in progress
- After the ritual, one-tap feedback (three-emoji + optional note)
- Concierge follows up in the evening: *"How did the sauna feel? Anything to remember?"*

**Emotional job.** *Recognised. Guided. Restored.*

**Standard.**
- Zero waiting at reception
- Trainer is present at ritual start (never a self-serve first visit)
- Signature preferences observed on day one

**Failure mode.** Member asked "First time?" or "What's your name?" more than once.

**Ops owner.** Reception, trainer on duty.

---

## Stage 6 — The First Two Weeks

**Moment.** Habit is fragile. Trust is forming.

**Physical.**
- On the 2nd visit, staff greet by name and reference the Signature (temperature, tea)
- On the 3rd visit, the trainer offers one small refinement ("try 12 minutes this time")

**Digital.**
- Concierge appears at day 2, day 5, day 10 — each with a *specific* invitation, not a nag
- Day 7: first weekly Recovery Index summary, gentle
- Day 14: Timeline records "First Two Weeks" as a milestone, quietly

**Emotional job.** *This is becoming mine.*

**Standard.**
- No push notification storm; max 1 per day
- No streak counters that shame

**Failure mode.** Any "Your streak is at risk!" language.

**Ops owner.** Product (Concierge cadence), trainer on duty.

---

## Stage 7 — The Habit Forms (30 days)

**Moment.** Member has completed ~12 sessions across rituals.

**Physical.**
- Trainer proactively suggests a short review conversation (5 minutes at the end of a session)

**Digital.**
- Member is elevated from **Explorer** to **Member** on the Status Ladder — a private note appears on the Timeline
- Concierge shifts tone: from *inviting* to *anticipating* ("I've held Wednesday morning for you, as usual.")
- Recovery Index has enough data to show real trends

**Emotional job.** *Recognised as a regular.*

**Standard.**
- Elevation is celebrated privately (in-app note + handwritten-style WhatsApp), not publicly announced

**Failure mode.** A push saying "You're a Member now!" with confetti.

**Ops owner.** Trainer, Product.

---

## Stage 8 — First Community Moment

**Moment.** Member joins a monthly challenge (Recovery Streak, 30-Day Mobility) or attends a workshop.

**Physical.**
- Small-format workshop (max 12 members), hosted in-club by a trainer or invited guest
- Herbal tea and Paradiso snacks; no branded swag

**Digital.**
- Challenge opt-in, opt-out at any time
- Leaderboards opt-in
- Workshop booking mirrors ritual booking flow

**Emotional job.** *Belonging.*

**Standard.**
- Community is small and curated, never open to all
- Photography from events shared only with explicit consent

**Failure mode.** A gamified challenge with a public shame board.

**Ops owner.** Community lead / manager.

---

## Stage 9 — First Referral

**Moment.** Member brings a friend.

**Physical.**
- Guest arrives with a guest-pass code
- Reception greets both by name (member's Signature already told us who's coming)
- Guest receives the same welcome tea and towel

**Digital.**
- Member issues guest pass in-app (one tap; unique code by WhatsApp)
- Referred guest gets a light onboarding surface (just enough to check in)
- If the guest joins, member receives referral credit and Timeline milestone

**Emotional job.** *Trusted. Sharing something valuable.*

**Standard.**
- Guest passes are limited, valuable, and their scarcity is respected
- No public "referred by" branding on the guest experience

**Failure mode.** Referral rewards feel transactional or expire aggressively.

**Ops owner.** Product, reception.

---

## Stage 10 — Renewal

**Moment.** The subscription renews.

**Physical.**
- No physical interaction unless the member requests it

**Digital.**
- 30 days before: gentle in-app note, no CTA — "Your membership renews on the 24th."
- 7 days before: WhatsApp note — "All set for the 24th. Nothing to do. If plans change, tap here."
- Day of: confirmation email with GST invoice
- If payment fails: retry ladder (3h, 6h, 12h), then a manager reaches out personally by day 2

**Emotional job.** *Taken care of.*

**Standard.**
- No urgency copy, ever
- No upsell inserted into renewal flow

**Failure mode.** "Renew now to keep your benefits" — this line is banned.

**Ops owner.** Product, finance, manager.

---

## Stage 11 — Freeze or Pause

**Moment.** Member is travelling, injured, or life happens.

**Digital.**
- Self-serve up to 30 days/year (freeze) or unlimited pause (billing halted, access revoked)
- Concierge notes it warmly: "See you when you're back."

**Physical.**
- On return, staff greet the member with a note: "Welcome back. We saved your Wednesday slot."

**Emotional job.** *Not abandoned.*

**Standard.**
- No penalty language
- Timeline records the pause as a chapter, not a gap

**Failure mode.** Repeated push notifications during the pause.

**Ops owner.** Product.

---

## Stage 12 — Returning After a Long Absence

**Moment.** A member re-engages after 60+ days.

**Physical.**
- Manager personally reaches out with a warm note (WhatsApp, signed)
- On return, first ritual is complimentary (small hospitality gesture)

**Digital.**
- Concierge greets: *"It's been a while, Yuvraj. Would you like to ease back in with a Recovery Reset?"*
- Recovery Index resets its cadence to gentle
- Timeline records a "Return" moment

**Emotional job.** *Welcomed back, without embarrassment.*

**Standard.**
- No re-onboarding required
- No "You've been away!" nag copy

**Failure mode.** Automated re-engagement drip that reads like a churn campaign.

**Ops owner.** Manager, Product.

---

## Stage 13 — Elevation (Resident → Inner Circle → Founder)

**Moment.** Member reaches a new tier.

**Physical.**
- **Resident:** a small note handwritten by the founder, mailed to home address (with consent)
- **Inner Circle:** an in-person moment at the club — coffee with the manager, a small gift (a linen towel, a candle, a book from Paradiso)
- **Founder:** by invitation only; annual Founder dinner; permanent recognition in the club (name on a small brass plate at reception is one option)

**Digital.**
- Timeline milestone appears
- Benefits update quietly in Membership
- Concierge tone adjusts (more familiar, more anticipatory)

**Emotional job.** *Seen. Belonging deepens.*

**Standard.**
- Every elevation includes a physical component. Digital-only is not enough.
- No public announcement without explicit member consent

**Failure mode.** A "Congratulations, you've levelled up!" banner.

**Ops owner.** Founder / manager (physical), Product (digital).

---

## Stage 14 — Annual Wellness Review

**Moment.** On the anniversary of joining.

**Physical.**
- 30-minute review with a trainer: read the year, agree on next year's rhythm
- A printed one-page annual summary (elegant, minimalist, signed by the trainer)

**Digital.**
- Timeline highlights the year (rituals, milestones, favourite services)
- App generates the printed summary PDF the trainer uses in the review
- Member receives a saveable digital copy

**Emotional job.** *Progress made real.*

**Standard.**
- Annual review is a genuine conversation, not a sales meeting
- Any renewal upgrade is proposed only if it demonstrably fits

**Failure mode.** Turning the review into an upsell.

**Ops owner.** Trainer, manager.

---

## Stage 15 — Off-boarding (voluntary)

**Moment.** A member decides to leave.

**Physical.**
- Manager reaches out personally (not to save the deal, but to close the chapter well)
- A short exit conversation, offered
- Locker items returned, a note

**Digital.**
- Self-serve cancellation with two taps and no confirm-shame
- Confirmation is warm: *"We understand. Your data is yours — download it here. Your seat will be waiting."*
- Timeline records the closure gracefully

**Emotional job.** *Respected on the way out.*

**Standard.**
- The exit flow is as beautiful as the joining flow
- No last-ditch discounts

**Failure mode.** A retention popup with a "Wait! Here's 20% off" offer.

**Ops owner.** Product, manager.

---

## Cross-cutting Standards

**Punctual hospitality.** Notifications and staff messages are punctual, not aggressive. Every reach-out has a reason and a person behind it.

**Named humans.** Every message from the club is signed — Concierge whispers included, when they carry a trainer's attribution.

**Physical + digital parity.** The digital experience should never feel warmer than the physical one, and vice versa. They rise together.

**Silence is a feature.** There are days when the app should say nothing. That's fine.

---

## Physical ↔ Digital Touchpoint Matrix

| Stage | Physical touchpoint | Digital touchpoint | Owner |
|---|---|---|---|
| Inquiry | — | Landing / WhatsApp reply | Manager |
| Tour | 45-min walk, Paradiso item | Signature-lite note | Host |
| Joining | Card, locker, intake | Provisioning, welcome email | Manager |
| First open | — | 6-screen onboarding | Product |
| First visit | Recognition, ritual walk | Check-in, arrival mode, evening whisper | Reception, trainer |
| First 2 weeks | 2nd/3rd visit refinements | Concierge cadence, weekly Index | Trainer, product |
| 30-day habit | Trainer review chat | Elevation to Member on Timeline | Trainer, product |
| First community | Workshop | Opt-in challenge | Community lead |
| Referral | Guest greeting | Guest pass flow | Reception, product |
| Renewal | — | Notes on 30d / 7d / day-of | Product, finance |
| Freeze/pause | Return greeting | Self-serve pause | Product |
| Long return | Manager note, comp session | Concierge re-open | Manager, product |
| Elevation | Handwritten note / gift / dinner | Timeline milestone | Founder, product |
| Annual review | 30-min conversation, print | Year summary PDF | Trainer, product |
| Off-boarding | Manager conversation, locker | Two-tap cancel, data export | Manager, product |

---

## Review Checklist

- [ ] All 15 stages match how Sanctuary actually intends to operate
- [ ] Physical + digital ownership is clear at every stage
- [ ] Cancellation and return flows meet the hospitality standard
- [ ] Elevation ceremonies include a physical component (mandatory)
- [ ] Onboarding is genuinely 6 screens or fewer
- [ ] Concierge cadence is right (day 2, 5, 10, weekly thereafter)
- [ ] Referral guest experience is defined for both member and guest

Once approved, the Service Playbook (Doc C) codifies the protocols staff and software must honour for each service.
