# Phase 15 — Risks, Compliance & Governance

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

Everything that could go wrong, everything the law asks of us, and who is accountable when a decision has to be made. This is the last document in the specification set and the first document the leadership team should re-read every quarter.

Sections:
1. Risk register (full)
2. Governance model
3. Decision rights
4. Compliance calendar (DPDP, GST, RBI, health data, employment)
5. Data-processing register
6. Incident policy
7. AI-specific governance
8. Insurance
9. Legal artefacts and versioning
10. Ethics charter
11. Review checklist

---

## 1. Risk register (full)

Risks scored on a 1–5 scale for **likelihood** and **impact**; product of the two prioritises attention.

### 1.1 Product & experience

| Risk | L | I | Score | Owner | Mitigation |
|---|---|---|---|---|---|
| Concierge produces a whisper that offends or misleads | 2 | 4 | 8 | Product | Two-layer safety, ops review in Alpha, banned-word list |
| Concierge safety-event mishandled | 1 | 5 | 5 | Ops | Drilled runbook, sub-3-min ack SLO, blameless postmortem |
| Member data exposure via RLS misconfig | 2 | 5 | 10 | Platform | RLS-first schema, integration tests per role, external audit annually |
| Overbooking (slot-hold race) | 1 | 5 | 5 | Platform | Row-locks, unique-constraint on `reservation_slots`, load tests |
| Feedback friction leads to silent churn | 3 | 3 | 9 | Product | Post-ritual whisper opt-in survey; ops listening posts |
| App outage during peak evening | 2 | 4 | 8 | Platform | Read-only degraded mode, static shell fallback |
| Voice drift (whispers start sounding generic) | 3 | 3 | 9 | Product+Coach | Weekly audit, quarterly voice refresh |

### 1.2 Physical & ops

| Risk | L | I | Score | Owner | Mitigation |
|---|---|---|---|---|---|
| Injury on premises | 2 | 5 | 10 | Ops | Physio on-site, first-aid trained staff, insurance, runbook 8 |
| Infection risk (plunge, sauna hygiene) | 2 | 4 | 8 | Facilities | Hygiene protocols, water rotation, weekly deep clean |
| Coach walk-out or dispute | 2 | 4 | 8 | GM | Multi-coach coverage matrix, employment terms, exit interviews |
| Equipment failure (sauna, chiller) | 3 | 3 | 9 | Facilities | Maintenance contracts, spare-parts inventory, runbooks 1 & 2 |
| Fire, electrical, flood | 1 | 5 | 5 | Facilities | Insurance, drills, alarm system, sprinklers, spill response |
| Emergency medical event | 2 | 5 | 10 | Ops | Emergency numbers posted, defibrillator on-site, staff CPR-trained |

### 1.3 Business & financial

| Risk | L | I | Score | Owner | Mitigation |
|---|---|---|---|---|---|
| Rent inflation or lease dispute | 2 | 4 | 8 | Founder | Long lease with cap; legal advisor on file |
| Payment gateway pricing change | 2 | 3 | 6 | Finance | Exit plan (Phase 9 §11.2) — Cashfree/Juspay |
| Currency shocks (equipment imports) | 3 | 2 | 6 | Finance | Local suppliers where possible |
| Customer concentration (Founding Members over-represented) | 3 | 3 | 9 | Growth | Broaden acquisition channels post P2 |
| Refund and dispute volume | 2 | 2 | 4 | Ops | Clear policies, ops discretion within cap |

### 1.4 Regulatory

| Risk | L | I | Score | Owner | Mitigation |
|---|---|---|---|---|---|
| DPDP non-compliance | 2 | 5 | 10 | DPO | Data-processing register, DPO appointed, quarterly audit |
| GST filing error | 2 | 3 | 6 | Finance | External CA, monthly reconciliation |
| RBI e-mandate policy change | 3 | 3 | 9 | Finance+Product | Monitor circulars; Razorpay maintains compliance layer |
| Health-data breach | 1 | 5 | 5 | Platform+DPO | Field-level encryption, minimal collection, 72h notification plan |
| Employment or PoSH complaint | 2 | 4 | 8 | HR | Committee, training, external ombudsperson |
| Advertising / consumer complaint | 2 | 3 | 6 | Brand | Voice review, no unproven claims, disclaimer where needed |

### 1.5 Reputation & brand

| Risk | L | I | Score | Owner | Mitigation |
|---|---|---|---|---|---|
| Press mischaracterises brand | 3 | 3 | 9 | Founder+PR | Press one-pager, founder-first interviews |
| Founding Member leaves publicly and negatively | 2 | 3 | 6 | Founder | Personal outreach, graceful exit |
| Voice inconsistency across surfaces | 3 | 3 | 9 | Product+Brand | Central style guide, review cadence |
| Trademark / naming conflict (Sanctuary, Paradiso, HYROX) | 2 | 3 | 6 | Legal | Class 41/44 filings, watch service |
| Instagram or social account compromise | 2 | 3 | 6 | Marketing | 2FA, limited admin, recovery plan |

### 1.6 Existential

| Risk | L | I | Score | Owner | Mitigation |
|---|---|---|---|---|---|
| Founder incapacity | 1 | 5 | 5 | Board | Governance, insurance, deputisation plan |
| Loss of GM or Head Coach | 2 | 4 | 8 | Founder | Succession bench, cross-training |
| Extended location closure (30+ days) | 1 | 5 | 5 | GM+Finance | Insurance, reserve fund, secondary offering (retreat, online) |

Top-of-mind (score ≥ 9): safety event, RLS misconfig, injury, coach walk-out, equipment failure, feedback friction, voice drift, press mischaracterisation, RBI change, DPDP compliance, customer concentration, medical event, brand voice inconsistency.

---

## 2. Governance model

### 2.1 Product Council

- **Members:** Founder, GM, Product Lead, Head Coach, Design Lead
- **Cadence:** every two weeks
- **Purpose:** review WRM + L1 metrics, product roadmap adjustments, feature flag decisions, whisper audit
- **Decision authority:** feature scope, roll-out gates

### 2.2 Ops Council

- **Members:** GM, Head Coach, Concierge Ops Lead, Facilities Lead, Paradiso Manager
- **Cadence:** weekly
- **Purpose:** incidents, member complaints, staffing, ambient standards, ops SLA adherence

### 2.3 Safety Committee

- **Members:** GM, Head Coach, Physiotherapist, DPO, Platform Lead
- **Cadence:** monthly, or within 24h of a Sev-1 safety event
- **Purpose:** Concierge safety events, contraindication reviews, incident postmortems

### 2.4 Brand Council

- **Members:** Founder, Design Lead, Product Lead, Coach lead
- **Cadence:** monthly
- **Purpose:** editorial approvals, voice audit, campaign or press decisions

### 2.5 Board (formal)

- **Members:** Founder + external advisors (2–3)
- **Cadence:** quarterly
- **Purpose:** strategy, hiring at leadership level, capital decisions, risk register review

---

## 3. Decision rights

Rendered in RACI shorthand for the most-contested decisions.

| Decision | Responsible | Accountable | Consulted | Informed |
|---|---|---|---|---|
| Ship a new ritual | Head Coach | GM | Ops, Product, Physio | Members via note |
| Kill a feature flag | Product Lead | Product Lead | Platform | Ops |
| Refund > ₹5,000 | Ops | GM | Finance | Member |
| Concierge prompt change | Product | Product Lead | Coach lead | Ops |
| Ban a member | GM | Founder | Head Coach | Legal |
| Publish a monthly letter | Editor | Founder | Coach author | — |
| Launch new location | Founder | Board | GM, Finance | All |
| Hire GM / Head Coach | Founder | Founder | Board | All staff |
| Retire a class | Head Coach | GM | Product, Ops | Members via note |
| Change pricing | Founder | Founder | Finance, Product | Members via note |
| Ship an ops-visible feature | Product | Product Lead | Ops | — |

---

## 4. Compliance calendar

### 4.1 DPDP Act 2023

- **Ongoing:** consent artefacts on every collection; data-principal request handling (30-day SLA)
- **Quarterly:** DPO audit of processing register
- **Annually:** external privacy audit
- **Ad-hoc:** breach notification to DPB within 72 hours + affected members

### 4.2 GST

- **Monthly:** GSTR-1, GSTR-3B; reconciliation
- **Annually:** GSTR-9

### 4.3 RBI e-mandate

- **Ongoing:** pre-debit notification 24h before charge; AFA above threshold
- **On circulars:** legal/product review within 30 days

### 4.4 Health data

- **Ongoing:** minimum-necessary collection; field-level encryption
- **On erasure request:** free-text purged within 30 days; categorical flags retained for audit only

### 4.5 Employment & PoSH

- **On hiring:** background check, offer letter, training
- **Quarterly:** PoSH training refresh
- **Annually:** external ombudsperson refresh

### 4.6 Tax & finance

- **Monthly:** payroll, TDS, PF/ESI
- **Quarterly:** advance tax
- **Annually:** ITR, audit if applicable

### 4.7 Insurance renewals

- **Annually:** general liability, professional indemnity, cyber, property, employee medical, key-person

---

## 5. Data-processing register

Maintained at `docs/registers/data-processing.md`. Fields per row:

- Vendor / process
- Categories of personal data
- Categories of special data (health)
- Purpose
- Legal basis (contract / consent / legitimate interest / legal obligation)
- Data subjects (members, guests, staff, minors)
- Sub-processors (if any)
- Region of processing
- Cross-border transfer safeguard (if applicable)
- Retention period
- Contract reference
- Last reviewed date

Populated at launch; reviewed quarterly by DPO.

---

## 6. Incident policy

- **Any member harm event** (physical injury, safety-related distress) → GM + Head Coach + Founder informed within 30 minutes
- **Any data event** → DPO + Platform + Founder within 30 minutes; DPB and affected members within 72 hours
- **Any Sev-1** → status page + email within 30 minutes; postmortem within 5 business days
- **Blameless postmortems** — the person closest to the incident is not the person on trial; systems and processes are

Postmortem template:
1. Summary
2. Impact (who, how many, for how long)
3. Timeline (detection, response, resolution)
4. Root cause
5. Contributing factors (5-whys)
6. What went well
7. Action items (owner, due date, category: prevention / detection / mitigation)
8. Communication log

Filed at `docs/incidents/YYYY-MM-DD-slug.md`.

---

## 7. AI-specific governance

Beyond §Phase 8 §9 safety mechanisms:

- **Model change requires council review.** A new provider, model version, or prompt version cannot ship without Product Council + Coach lead approval.
- **Prompt library is versioned** in Git; every deployed message references its prompt id and version.
- **Whisper library is bounded.** No new whisper type ships without a brand review.
- **Adversarial red-teaming quarterly.** Internal team + one external reviewer.
- **Right-to-explanation.** A member can ask why they received a whisper; ops can retrieve the trigger (not the raw prompt) and explain in plain language.
- **No LLM-produced legal, medical, financial, or employment communication.** Ever.
- **LLM cannot self-write action confirmations.** Structured actions execute only via server code paths with domain validation.

---

## 8. Insurance

Coverage lines at launch:

| Line | Purpose | Coverage anchor |
|---|---|---|
| General liability | Third-party bodily / property | ₹5 cr |
| Professional indemnity | Coaching, wellness advice | ₹5 cr |
| Property (buildings, contents) | Fire, theft, damage | Full value |
| Business interruption | 12 months | Full cover |
| Cyber liability | Data breach, ransomware | ₹5 cr |
| Directors & Officers | Board protection | ₹2 cr |
| Employer's liability + WC | Staff injury | Statutory + ₹1 cr |
| Employee medical | Group health, opd | ₹5 lakh per family, tier-based |
| Key-person | Founder + Head Coach | To be decided |

Reviewed annually or on material change (new location, new service line).

---

## 9. Legal artefacts and versioning

- Terms of service
- Privacy policy
- Health intake and consent
- Photography and likeness consent
- Refund and cancellation policy
- Guest terms
- Founder Circle / Inner Circle terms
- Employment contracts
- Coach contractor agreements (where applicable)
- Vendor DPAs (per Phase 9)
- Intellectual property (Sanctuary, Paradiso, HYROX-India licensing) filings and renewals

All documents versioned in the CMS (Phase 9 §9.2) with legal counsel sign-off. Members are notified of material changes at least 30 days before effect.

---

## 10. Ethics charter

Read aloud at every new-hire onboarding.

- We tell members the truth, especially when it costs us.
- We do not sell what a member does not need.
- We do not use fear, guilt, or aspirational shame to acquire or retain.
- We do not treat member data as a marketing surface. Ever.
- We treat coaches as senior collaborators, not scripts.
- We treat physical labour — housekeeping, kitchen, maintenance — with the same care as coaching.
- We build for the calmest possible experience of being human in a room we designed.
- Where our discipline fails a member, we say so and we make it right.
- We remove features that do not serve.
- We measure our own voice against our own words.

---

## 11. Review checklist

- [ ] Full risk register acknowledged with owners for every score-9+ item
- [ ] Governance model (Product / Ops / Safety / Brand / Board) staffed and cadenced
- [ ] Decision-rights RACI matches how the team actually operates
- [ ] Compliance calendar assigned to Finance + DPO + HR
- [ ] Data-processing register created and populated within 30 days of launch
- [ ] Incident policy and blameless postmortem template committed
- [ ] AI governance guardrails (model change council, versioned prompts, red-team quarterly) accepted
- [ ] Insurance cover lines are procured before P1 opens
- [ ] Legal artefacts drafted with counsel and versioned in the CMS
- [ ] Ethics charter read aloud at every new-hire onboarding (not just printed)
