# Phase 10 — Analytics, KPIs & North Star

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

We measure what we would defend to a member sitting across from us. We do not measure what makes a dashboard look busy. The metrics chosen here are shaped by the brand promise: known, restored, respected, in good hands, belonging.

Sections:
1. North Star metric
2. Companion metrics (L1)
3. Product health metrics (L2)
4. Brand metrics (L3)
5. Financial metrics
6. Concierge metrics
7. Ops metrics (physical experience)
8. Cohort & retention analysis
9. Guardrail metrics
10. Instrumentation coverage
11. Reporting cadence & owners
12. Review checklist

---

## 1. North Star metric

**Weekly Restored Members (WRM):** the count of members who, in a given week, completed at least one ritual or class **and** reported the visit as *"Restored"* or *"Steady"* on the post-ritual feedback.

Why:
- Combines usage and outcome.
- Restored is our word, not the industry's.
- Cannot be juked by cheap incentives or discounts.
- Aligned with hospitality: attendance without emotional return is not a win.

Target trajectory:
- End of Month 3 (soft launch): 80 WRM
- End of Year 1: 700 WRM
- End of Year 2 (two locations): 2,000 WRM

WRM is displayed on the ops wall in Vasant Kunj as a slowly ticking number — not a scoreboard.

---

## 2. Companion metrics — L1 (weekly review)

The five metrics that partner WRM. If WRM moves but any of these are off, we investigate.

| Metric | Definition | Direction | Target trajectory |
|---|---|---|---|
| Active members | Distinct members with at least one attended visit in trailing 30 days | Up | 90% of paid membership |
| Feedback response rate | % of completed rituals with a feedback submission | Up | > 55% |
| Weekly Restored share | WRM / active members | Up (bounded) | > 65% at maturity |
| Membership renewal rate | % of memberships renewing in the 30 days after natural expiry | Up | > 88% Year-1, > 92% Year-2 |
| Concierge whisper open rate | % of delivered whispers opened by member | Up (bounded) | > 60% |

---

## 3. Product health metrics — L2 (bi-weekly)

Grouped by member journey.

### 3.1 Acquisition
- Introductions requested → intro completed
- Intro completed → first-visit booked
- First-visit booked → attended
- First visit → paid membership within 14 days

### 3.2 Activation (first 30 days)
- Rituals attended in first 30 days (target median: 4)
- Signature seeded (target: 90% within week 1)
- First Concierge whisper opened (target: 85% within week 1)

### 3.3 Engagement
- Visits per member per week (target median: 2)
- Ritual mix (share of Recovery / Movement / Performance / Mindfulness usage)
- Class fill rate by pillar and by coach
- Weekend usage share

### 3.4 Retention
- 30/60/90/180-day retention cohorts
- Churn reason distribution (schedule / cost / injury / moved / no reason)
- Reactivation rate 90 days post-cancel

### 3.5 Referral & growth
- Referrals sent per member per quarter
- Referral → member conversion rate (target: > 25%)
- Guest passes issued vs. guest → member conversion (target: > 12%)

---

## 4. Brand metrics — L3 (monthly / quarterly)

Softer, slower, said aloud to leadership.

- **Net Recommend** — asked at day 30 and quarterly: *"On a scale of 1 to 10, how likely are you to bring someone you care about?"*. Reported as Promoters − Detractors. Target: > 55.
- **Belonging** — quarterly one-question survey: *"Sanctuary feels like my place." (Agree / Neither / Disagree)*. Target: Agree ≥ 75%.
- **Attribution recall** — quarterly: *"Which coach at Sanctuary knows you best?"* — % who name a real trainer. Target: > 80%.
- **Whisper voice audit** — internal weekly sampling; % rated 4+/5 for voice fidelity by product + coach panel. Target: > 90%.

---

## 5. Financial metrics

Reported monthly to leadership.

### 5.1 Revenue

- Gross Merchandise Revenue (GMR) — total inflow from plans + drop-ins + Paradiso
- Net Revenue — after refunds, discounts (rare)
- MRR (memberships only)
- ARR — MRR × 12 + annual-plan bookings
- Revenue per active member (target: ₹6,500 / month at Year-1 blended)

### 5.2 Cost

- COGS-lite: consumables (towels, teas, Paradiso F&B), utilities
- Platform cost per member (Phase 7 §7)
- Trainer utilisation (booked hours / available hours) — target: 65–75% (higher is not healthier for the experience)

### 5.3 Unit economics

- CAC — total marketing + intro-call FTE cost ÷ new paid members in period
- LTV — 24-month projected margin per member, cohort-basis
- LTV / CAC — target > 3 by end of Year-1
- Payback period — target < 4 months

### 5.4 Category mix

- Membership dues share
- Drop-in and guest-pass share
- Paradiso share
- Event & workshop share
- Retail / merch share (Year-2)

---

## 6. Concierge metrics

Concierge earns its keep by measurable warmth.

### 6.1 Delivery

- Whisper compose latency p95 < 6s
- Conversation turn latency p95 < 3s
- Send success rate > 99.5%
- Undeliverable whispers held in queue (retry backoff)

### 6.2 Engagement

- Open rate on whispers (see §2)
- Conversation initiation rate (whispers → member reply) — target: > 15%
- Median conversation length (turns) — target: 2–4
- Action confirmation rate (proposed → confirmed) — target: > 40%

### 6.3 Safety

- Safety events per 1,000 conversations — tracked but not targeted (rare is expected)
- Time from safety event to human ack — target p95 < 3 min
- False-positive rate on safety triggers — target < 10%
- Zero missed safety escalations (blocking; any miss is Sev-1)

### 6.4 Quality

- Whisper voice audit score (see §4)
- % conversations flagged by ops on weekly review
- Prompt regressions caught in CI vs. in prod (target: 100% in CI)

---

## 7. Ops metrics — physical experience

Sanctuary is physical. Digital metrics are half the picture.

- **Arrival to first-service delay** — median from check-in to seated in sauna / on mat. Target: < 4 min.
- **Locker readiness** — % of visits where the member's stated locker was ready and stocked. Target: > 98%.
- **Trainer name recall** — internal audit: does the trainer greet the member by name and reference last visit within 30 seconds? Target: > 90%.
- **Ambient temperature and lighting** — per-suite audit at open / mid-day / close. Deviation < 1°C / < 5% brightness.
- **Cleanliness cycle** — sauna wipe-down after every session, plunge water rotation on schedule. Logged in ops app.
- **Paradiso order-to-serve time** — target median < 8 min in-club, < 15 min post-ritual.
- **Post-ritual escort** — member escorted to Paradiso or exit by the same coach who ran their ritual, > 80% of the time.

---

## 8. Cohort & retention analysis

- Cohorts defined by join month
- Retention curves at 30/60/90/180/365 days
- Segmentation:
  - By tier at join
  - By onboarding path (intro-led vs. guest → member)
  - By primary pillar in first 30 days (Recovery / Movement / Performance / Mindfulness)
  - By assigned coach
- Analysis reviewed monthly
- Any cohort with retention 15pp below trend gets a diagnostic

---

## 9. Guardrail metrics

Metrics that must not move the wrong way while others improve.

| Guardrail | Bound |
|---|---|
| Post-ritual "Off" share | ≤ 6% weekly (any spike investigated in 48h) |
| Cancellation < 4h before | ≤ 8% weekly |
| No-show rate | ≤ 3% weekly |
| Payment failure rate | ≤ 2% of attempted charges |
| Support tickets per 100 members per week | ≤ 4 |
| Sev-1 incidents per quarter | 0 (target) |
| Whisper opt-outs | ≤ 5% of members ever |

---

## 10. Instrumentation coverage

Every Phase 4 flow must emit:
- At least one `*_started` event
- One `*_completed` event
- Named failure events

Additional required event categories:
- Screen views (route)
- Component interactions (component, variant, action)
- Concierge lifecycle (composed, delivered, opened, engaged, action_proposed, action_confirmed, safety_event)
- Payment lifecycle (checkout_opened, checkout_completed, charge_succeeded, charge_failed, refund_issued)
- Onboarding lifecycle (inquiry, intro, health_intake, signature, first_ritual)
- Session-replay opt-in / opt-out
- Consent events

Event property standards:
- `member_id` (server-side only, never in URL)
- `location_id`
- `session_time_ist` (ISO)
- `feature_flags_active` (map)
- `client_platform` (web / staff-tablet)
- No health data. No payment amounts (only bucketed ranges).

QA gate: any new endpoint or component with `data-event` must have its event registered in the taxonomy file (`packages/analytics/taxonomy.ts`), otherwise CI fails.

---

## 11. Reporting cadence & owners

| Report | Cadence | Owner | Audience |
|---|---|---|---|
| WRM dashboard | Live | Product | All |
| L1 companion metrics | Weekly | Product | Leadership |
| L2 product health | Bi-weekly | Product | Product + Ops |
| L3 brand | Monthly | Founder / Brand | Leadership |
| Financial | Monthly | Finance | Leadership |
| Concierge quality | Weekly | Product + Coach lead | Product |
| Ops experience | Weekly | Ops lead | Ops + Founder |
| Cohort review | Monthly | Product | Product + Growth |
| Incident review | Per-incident + monthly rollup | Platform | Leadership |

Dashboards live in PostHog (product), Metabase or Grafana (finance and ops), and a curated Notion "Wall" page for narrative context that numbers alone don't carry.

---

## 12. Review checklist

- [ ] North Star (Weekly Restored Members) is the right compound of use + outcome
- [ ] L1 companions are the right five (or add / drop)
- [ ] Financial targets (LTV/CAC > 3, payback < 4 months, revenue / active member ₹6,500) are aligned to business plan
- [ ] Concierge engagement thresholds (open > 60%, action confirmation > 40%, safety p95 ack < 3 min) are acceptable
- [ ] Ops metrics (arrival delay, locker readiness, name recall) are measured with the current tablet + ops app
- [ ] Guardrails are strict enough to prevent bad growth
- [ ] Instrumentation gate in CI is committed
- [ ] Report cadence and owner names finalised
