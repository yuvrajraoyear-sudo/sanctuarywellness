# Phase 3 — Database Schema
**Project:** Sanctuary Wellness by Play Haus
**Version:** 1.0
**Stack:** Supabase (PostgreSQL 15), row-level security enforced everywhere.
**Depends on:** PRD v1.1 · Brand Bible · MX Blueprint · Service Playbook · Phase 2 IA

This is the source-of-truth schema. It supports V1 (Sanctuary members) and is intentionally shaped so Phase 2 (Sports) and Phase 3 (full Paradiso, Kids) slot in without a rewrite.

> **Placeholder — full schema follows.** Sections below are filled in sequence.

---

## 1. Principles

1. **RLS on every table.** No table ever ships with RLS disabled in prod. Even lookup tables carry a `select using (true)` policy so intent is explicit.
2. **UUID v4 primary keys everywhere.** Predictable, safe for URLs, no enumeration risk.
3. **Timestamps in UTC.** Every table has `created_at`, `updated_at`. IST is a rendering concern.
4. **Soft-delete only where audit-important.** `deleted_at` on: members, reservations, invoices, tickets, timeline milestones, guest passes. Everything else hard-deletes.
5. **Enums live in Postgres.** Not TypeScript. Enums generate typed clients (via Supabase codegen).
6. **Money is `bigint` paise.** Never `float`. Currency column defaults `INR`.
7. **JSONB for evolving shapes.** Signature preferences, Concierge context, Recovery Index inputs, analytics payloads — all JSONB with documented shapes.
8. **Namespacing for the super-app.** Every product-scoped table carries a `product` column (`sanctuary` | `sports` | `paradiso` | `kids`) even when V1 only uses `sanctuary`.
9. **Location-scoped from day one.** Every operational table carries `location_id`. V1 has one location; the FK is inert but present.
10. **Triggers do the accounting.** Reservations, attendance, and challenge progress emit Timeline milestones and Recovery Index inputs via triggers, not application code. One source of truth.
11. **Audit privileged actions.** Refunds, tier elevations, plan changes, staff provisioning, feature-flag toggles → `audit_log`.
12. **Two schemas.** `public` for member-facing data (RLS-protected), `staff` for internal ops surfaces (role-gated). One project.

## 2. Cross-cutting conventions

### 2.1 Column templates

Every table includes:

```sql
id           uuid primary key default gen_random_uuid(),
created_at   timestamptz not null default now(),
updated_at   timestamptz not null default now()
```

Optional but common:

```sql
deleted_at   timestamptz,
metadata     jsonb not null default '{}'::jsonb
```

### 2.2 Enums (declared once)

```sql
create type product_scope   as enum ('sanctuary','sports','paradiso','kids');
create type user_role       as enum ('member','trainer','manager','admin','owner');
create type member_status   as enum ('active','frozen','paused','expired','cancelled','pending');
create type tier_level      as enum ('explorer','member','resident','inner_circle','founder');
create type reservation_status as enum ('reserved','waitlisted','confirmed','checked_in','completed','no_show','cancelled_member','cancelled_staff','late_cancelled');
create type ritual_slug     as enum ('morning_reset','recovery_reset','evening_wind_down','weekend_recharge','athlete_prep','post_event_restore','custom');
create type service_category as enum ('recovery','movement','strength','breath','other');
create type intensity       as enum ('low','medium','high');
create type notification_channel as enum ('inapp','push','email','whatsapp','sms');
create type notification_category as enum ('reservation','membership','payment','concierge','timeline','challenge','support','birthday','other');
create type payment_status  as enum ('created','authorized','captured','failed','refunded','partially_refunded');
create type invoice_status  as enum ('draft','issued','paid','overdue','void');
create type ticket_status   as enum ('open','pending','resolved','closed');
create type support_priority as enum ('low','normal','high','urgent');
create type challenge_status as enum ('draft','open','closed','archived');
create type milestone_type  as enum ('joined','first_ritual','session_count','tier_elevation','challenge_completed','recovery_hours','anniversary','return','custom');
```

### 2.3 Naming

- Tables: `snake_case`, plural (`members`, `reservations`)
- Columns: `snake_case`, singular, boolean columns prefixed `is_` or `has_`
- Foreign keys: `<table_singular>_id` (`member_id`, not `user_id`)
- Junction tables: `<a>_<b>` alphabetical (`ritual_services`, `reservation_slots`)
- Indices: `idx_<table>_<cols>`; unique: `uq_<table>_<cols>`; check constraints: `chk_<table>_<name>`

### 2.4 Auth linkage

Supabase manages `auth.users` (built-in). Our `public.members` table has `auth_user_id uuid references auth.users(id) on delete restrict`. Members are provisioned by staff before signing in — see Section 3.

### 2.5 Money & currency

All amounts stored as `bigint` in the smallest unit (paise). Every money column pairs with a `currency char(3) not null default 'INR'`. UI formats at the edge.

### 2.6 Timezone

Store UTC (`timestamptz`). Render IST (`Asia/Kolkata`) in the UI. Never mix.

### 2.7 Retention

Members can request export (JSON + PDF) and deletion under Signature → Privacy. Deletion path: soft-delete PII → anonymize related rows → after 30 days, hard-delete PII columns. Financial records retained per Indian tax rules (8 years).

## 3. Identity & profiles

### 3.1 `members`

The single canonical row per human. `auth_user_id` links to Supabase Auth.

```sql
create table public.members (
  id                uuid primary key default gen_random_uuid(),
  auth_user_id      uuid unique references auth.users(id) on delete restrict,
  first_name        text not null,
  last_name         text,
  email             citext not null unique,
  phone             text unique,
  date_of_birth     date,
  gender            text,
  role              user_role not null default 'member',
  status            member_status not null default 'pending',
  tier              tier_level not null default 'explorer',
  primary_location_id uuid references public.locations(id),
  joined_at         timestamptz,
  invited_by        uuid references public.members(id),
  invite_code       text unique,
  invite_sent_at    timestamptz,
  invite_accepted_at timestamptz,
  is_founder        boolean not null default false,
  quiet_please      boolean not null default false,
  consent_marketing boolean not null default false,
  consent_health_share_with_trainer boolean not null default false,
  metadata          jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz
);

create index idx_members_status on public.members(status);
create index idx_members_tier on public.members(tier);
create index idx_members_location on public.members(primary_location_id);
create index idx_members_created on public.members(created_at desc);
```

**Notes.**
- `pending` = provisioned by staff, has not signed in yet. On first successful login, trigger promotes to `active`.
- `role` is a coarse gate; fine-grained trainer scoping lives in `trainer_assignments` (Section 4).
- `is_founder` is denormalized for fast filtering; tier is the authoritative source.

### 3.2 `member_signature`

One row per member. Preferences the club uses to know the member. All optional; all owned by member.

```sql
create table public.member_signature (
  member_id            uuid primary key references public.members(id) on delete cascade,
  preferred_locker     text,
  preferred_sauna_temp_c smallint check (preferred_sauna_temp_c between 40 and 100),
  preferred_tea        text,
  preferred_coffee     text,
  preferred_trainer_id uuid references public.members(id),
  preferred_time_slot  text,     -- 'morning'|'midday'|'evening'|'late'
  preferred_music      text,
  preferred_scent      text,
  birthday_pref        text check (birthday_pref in ('celebrate','quietly','not_at_all')) default 'quietly',
  intents              text[] not null default '{}',  -- ['recovery','movement','performance','calm']
  goals                text,
  updated_at           timestamptz not null default now(),
  metadata             jsonb not null default '{}'::jsonb
);
```

### 3.3 `member_health`

Sensitive. Trainer visibility gated on `members.consent_health_share_with_trainer`.

```sql
create table public.member_health (
  member_id            uuid primary key references public.members(id) on delete cascade,
  height_cm            smallint,
  weight_g             integer,           -- grams, integer-only precision
  body_fat_pct         numeric(4,1),
  muscle_mass_g        integer,
  injuries             jsonb not null default '[]'::jsonb,           -- [{area, since, notes}]
  contraindications    text[] not null default '{}',                 -- ['cardio','pregnancy','raynauds',...]
  medications_note     text,
  emergency_contact    jsonb,             -- { name, phone, relation }
  medical_clearance_uploaded boolean not null default false,
  medical_clearance_expires_at date,
  updated_at           timestamptz not null default now(),
  metadata             jsonb not null default '{}'::jsonb
);
```

### 3.4 `trainer_profiles`

Extends a member row when `role = 'trainer'`.

```sql
create table public.trainer_profiles (
  member_id       uuid primary key references public.members(id) on delete cascade,
  display_name    text not null,
  bio             text,
  headshot_url    text,
  specialities    text[] not null default '{}',
  certifications  jsonb not null default '[]'::jsonb,   -- [{name, issuer, valid_until}]
  cpr_valid_until date,
  hyrox_certified boolean not null default false,
  active          boolean not null default true,
  hire_date       date,
  employment_type text check (employment_type in ('full_time','part_time','freelance')),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
```

### 3.5 `trainer_assignments`

Which members a trainer has an ongoing relationship with (1:1 or advisory). Used for RLS scoping.

```sql
create table public.trainer_assignments (
  id           uuid primary key default gen_random_uuid(),
  trainer_id   uuid not null references public.members(id) on delete cascade,
  member_id    uuid not null references public.members(id) on delete cascade,
  role         text not null check (role in ('primary','secondary','advisory')),
  started_at   date not null default current_date,
  ended_at     date,
  created_at   timestamptz not null default now(),
  unique(trainer_id, member_id, role)
);

create index idx_trainer_assignments_trainer on public.trainer_assignments(trainer_id) where ended_at is null;
create index idx_trainer_assignments_member on public.trainer_assignments(member_id) where ended_at is null;
```

## 4. Locations, rooms, capacity

### 4.1 `locations`

```sql
create table public.locations (
  id           uuid primary key default gen_random_uuid(),
  code         text not null unique,     -- 'DEL-01'
  name         text not null,            -- 'Sanctuary Delhi'
  address      text not null,
  city         text not null,
  timezone     text not null default 'Asia/Kolkata',
  geo_lat      numeric(9,6),
  geo_lng      numeric(9,6),
  active       boolean not null default true,
  opens_at     time not null default '06:00',
  closes_at    time not null default '22:00',
  metadata     jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
```

### 4.2 `rooms`

Physical spaces that hold sessions (Sauna Suite 1, Ice Pod 2, Breath Studio, Mobility Studio, etc.).

```sql
create table public.rooms (
  id           uuid primary key default gen_random_uuid(),
  location_id  uuid not null references public.locations(id) on delete restrict,
  code         text not null,             -- 'SAUNA-1'
  name         text not null,             -- 'Sauna Suite 1'
  kind         text not null,             -- 'sauna','ice_bath','steam','studio','contrast','recovery'
  capacity     smallint not null check (capacity > 0),
  reset_minutes smallint not null default 0,  -- turnaround time
  amenities    jsonb not null default '{}'::jsonb,
  active       boolean not null default true,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  unique(location_id, code)
);
```

### 4.3 `staff_shifts`

Optional in V1 for staffing analytics; explicit for HR-ready scheduling later.

```sql
create table public.staff_shifts (
  id           uuid primary key default gen_random_uuid(),
  location_id  uuid not null references public.locations(id),
  staff_id     uuid not null references public.members(id),
  starts_at    timestamptz not null,
  ends_at      timestamptz not null,
  role_on_shift user_role not null,
  notes        text,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index idx_shifts_location_time on public.staff_shifts(location_id, starts_at);
create index idx_shifts_staff_time on public.staff_shifts(staff_id, starts_at);
```

## 5. Service & ritual catalogue

### 5.1 `services`

The service catalogue drives booking + Service Playbook. Admin-editable.

```sql
create table public.services (
  id                uuid primary key default gen_random_uuid(),
  product           product_scope not null default 'sanctuary',
  slug              text not null,                          -- 'ice-bath'
  name              text not null,                          -- 'Ice Bath'
  category          service_category not null,
  intensity         intensity not null default 'medium',
  duration_min      smallint not null check (duration_min > 0),
  default_capacity  smallint not null check (default_capacity > 0),
  requires_trainer  boolean not null default false,
  trainer_cert_required text[] not null default '{}',
  preparation_md    text,                                   -- markdown
  contraindications text[] not null default '{}',
  protocol_md       text,                                   -- trainer-facing
  paradiso_pairings uuid[] not null default '{}',           -- FK-ish to paradiso_items.id
  recovery_signal   text not null default 'none',           -- 'recovery','heat','cold','mobility','strength','breath','none'
  recovery_weight   numeric(3,2) not null default 0.0,      -- feeds Recovery Index
  image_url         text,
  active            boolean not null default true,
  metadata          jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique(product, slug)
);
```

### 5.2 `service_variants`

Some services have variants (Sauna Traditional vs Infrared; Breathwork protocols).

```sql
create table public.service_variants (
  id            uuid primary key default gen_random_uuid(),
  service_id    uuid not null references public.services(id) on delete cascade,
  slug          text not null,          -- 'traditional' / 'infrared'
  name          text not null,
  duration_min  smallint,               -- overrides service default when set
  capacity      smallint,
  metadata      jsonb not null default '{}'::jsonb,
  active        boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique(service_id, slug)
);
```

### 5.3 `rituals`

Composed sequences. First-class product objects.

```sql
create table public.rituals (
  id                uuid primary key default gen_random_uuid(),
  product           product_scope not null default 'sanctuary',
  slug              ritual_slug not null unique,
  name              text not null,
  tagline           text,
  description_md    text,
  ideal_time_of_day text check (ideal_time_of_day in ('morning','midday','evening','late','any')) default 'any',
  total_duration_min smallint not null,
  hero_image_url    text,
  intent_tags       text[] not null default '{}',          -- ['recovery','calm','performance']
  first_timer_ok    boolean not null default true,         -- requires trainer walkthrough if false
  paradiso_suggestion_id uuid,                             -- default pairing
  active            boolean not null default true,
  metadata          jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);
```

### 5.4 `ritual_steps`

Ordered composition. Each step points at a service (or variant).

```sql
create table public.ritual_steps (
  id            uuid primary key default gen_random_uuid(),
  ritual_id     uuid not null references public.rituals(id) on delete cascade,
  step_order    smallint not null,
  service_id    uuid not null references public.services(id) on delete restrict,
  variant_id    uuid references public.service_variants(id),
  duration_min  smallint not null,
  buffer_min_before smallint not null default 0,
  buffer_min_after  smallint not null default 0,
  is_optional   boolean not null default false,
  notes         text,
  unique(ritual_id, step_order)
);

create index idx_ritual_steps_service on public.ritual_steps(service_id);
```

### 5.5 `sessions`

Scheduled service slots. This is the concrete supply against which reservations are made. Generated by admin tools or a scheduler.

```sql
create table public.sessions (
  id            uuid primary key default gen_random_uuid(),
  product       product_scope not null default 'sanctuary',
  service_id    uuid not null references public.services(id),
  variant_id    uuid references public.service_variants(id),
  location_id   uuid not null references public.locations(id),
  room_id       uuid references public.rooms(id),
  trainer_id    uuid references public.members(id),        -- when applicable
  starts_at     timestamptz not null,
  ends_at       timestamptz not null,
  capacity      smallint not null check (capacity > 0),
  status        text not null default 'scheduled' check (status in ('scheduled','open','closed','cancelled','completed')),
  is_private    boolean not null default false,            -- 1:1 or invite-only
  price_paise   bigint not null default 0,
  currency      char(3) not null default 'INR',
  visibility    text not null default 'members',           -- 'members','staff_only'
  metadata      jsonb not null default '{}'::jsonb,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  check (ends_at > starts_at)
);

create index idx_sessions_service_time on public.sessions(service_id, starts_at);
create index idx_sessions_location_time on public.sessions(location_id, starts_at);
create index idx_sessions_trainer_time on public.sessions(trainer_id, starts_at) where trainer_id is not null;
create index idx_sessions_room_time on public.sessions(room_id, starts_at) where room_id is not null;
```

**Design note.** A ritual reservation is a *bundle* of individual session reservations (Section 7). This preserves capacity math per room while presenting rituals as one experience.

## 6. Membership plans & subscriptions

### 6.1 `plans`

Plan catalogue. Admin-editable. Historical plans retained (never delete).

```sql
create table public.plans (
  id                 uuid primary key default gen_random_uuid(),
  product            product_scope not null default 'sanctuary',
  slug               text not null unique,                 -- 'sanctuary-monthly-core'
  name               text not null,
  tagline            text,
  description_md     text,
  cadence            text not null check (cadence in ('monthly','quarterly','annual','custom')),
  price_paise        bigint not null,
  currency           char(3) not null default 'INR',
  billing_interval_months smallint not null,
  tier_on_purchase   tier_level,                            -- optional bump on purchase
  includes           jsonb not null default '{}'::jsonb,    -- {'rituals_per_month': 12, 'guest_passes': 2, 'paradiso_credits_paise': 0}
  gst_rate           numeric(4,2) not null default 18.00,
  is_public          boolean not null default true,         -- false = internal / by-invite
  active             boolean not null default true,
  metadata           jsonb not null default '{}'::jsonb,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);
```

### 6.2 `memberships`

One active membership per member per product at a time. Historical memberships retained.

```sql
create table public.memberships (
  id                    uuid primary key default gen_random_uuid(),
  member_id             uuid not null references public.members(id) on delete restrict,
  plan_id               uuid not null references public.plans(id),
  product               product_scope not null default 'sanctuary',
  status                member_status not null default 'active',
  starts_on             date not null,
  ends_on               date not null,
  renews_at             timestamptz,
  is_auto_renew         boolean not null default true,
  auto_renew_mandate_id uuid references public.payment_mandates(id),
  freeze_days_used      smallint not null default 0,
  paused_at             timestamptz,
  cancelled_at          timestamptz,
  cancellation_reason   text,
  metadata              jsonb not null default '{}'::jsonb,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),
  deleted_at            timestamptz
);

create unique index uq_membership_one_active
  on public.memberships(member_id, product)
  where status in ('active','frozen') and deleted_at is null;

create index idx_memberships_member on public.memberships(member_id);
create index idx_memberships_status on public.memberships(status);
create index idx_memberships_renews on public.memberships(renews_at) where is_auto_renew;
```

### 6.3 `membership_ledger`

Every event on a membership (start, freeze, unfreeze, renew, upgrade, downgrade, cancel). Immutable audit trail.

```sql
create table public.membership_ledger (
  id             uuid primary key default gen_random_uuid(),
  membership_id  uuid not null references public.memberships(id) on delete cascade,
  event          text not null check (event in ('started','renewed','upgraded','downgraded','frozen','unfrozen','paused','resumed','cancelled','expired','credit_added','credit_used')),
  effective_at   timestamptz not null default now(),
  amount_paise   bigint,
  currency       char(3) default 'INR',
  actor_id       uuid references public.members(id),        -- who did it (member or staff)
  notes          text,
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);

create index idx_ledger_membership_time on public.membership_ledger(membership_id, effective_at desc);
```

### 6.4 `membership_credits`

Credits from waitlist, referrals, comp sessions.

```sql
create table public.membership_credits (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id),
  kind           text not null check (kind in ('referral','comp','goodwill','rollover','guest')),
  amount         integer not null,                          -- integer count of credits, not money
  currency_hint  text,                                      -- e.g. 'ritual', 'guest_pass'
  granted_at     timestamptz not null default now(),
  expires_at     timestamptz,
  redeemed_at    timestamptz,
  reservation_id uuid references public.reservations(id),   -- when consumed
  notes          text,
  created_at     timestamptz not null default now()
);

create index idx_credits_member_active on public.membership_credits(member_id) where redeemed_at is null;
```

## 7. Reservations, waitlists, attendance

### 7.1 `reservations`

Aggregate object. A reservation can be a single-service booking or a composed ritual booking (with N child slot rows).

```sql
create table public.reservations (
  id                uuid primary key default gen_random_uuid(),
  member_id         uuid not null references public.members(id) on delete restrict,
  product           product_scope not null default 'sanctuary',
  location_id       uuid not null references public.locations(id),
  ritual_id         uuid references public.rituals(id),        -- null for à la carte
  service_id        uuid references public.services(id),       -- null for ritual (child rows carry it)
  starts_at         timestamptz not null,                       -- earliest child starts_at
  ends_at           timestamptz not null,                       -- latest child ends_at
  status            reservation_status not null default 'reserved',
  is_waitlisted     boolean not null default false,
  waitlist_position smallint,
  waitlist_offered_at timestamptz,
  waitlist_confirm_deadline timestamptz,
  membership_id     uuid references public.memberships(id),     -- which membership this consumed
  credits_used      smallint not null default 0,
  member_note       text,                                       -- pre-arrival note
  cancellation_reason text,
  cancelled_by      uuid references public.members(id),
  cancelled_at      timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz,
  check ((ritual_id is null) <> (service_id is null) or ritual_id is not null),  -- allow ritual-with-service null
  check (ends_at > starts_at)
);

create index idx_reservations_member_time on public.reservations(member_id, starts_at desc);
create index idx_reservations_status on public.reservations(status);
create index idx_reservations_starts_at on public.reservations(starts_at);
create index idx_reservations_waitlist_deadline on public.reservations(waitlist_confirm_deadline)
  where is_waitlisted and status = 'reserved';
```

### 7.2 `reservation_slots`

Child rows — the actual slot holds against `sessions`. One row per underlying session held.

```sql
create table public.reservation_slots (
  id             uuid primary key default gen_random_uuid(),
  reservation_id uuid not null references public.reservations(id) on delete cascade,
  session_id     uuid not null references public.sessions(id) on delete restrict,
  step_order     smallint not null default 1,                  -- position within a ritual
  status         reservation_status not null default 'reserved',
  checked_in_at  timestamptz,
  completed_at   timestamptz,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique(reservation_id, session_id)
);

create index idx_reservation_slots_session on public.reservation_slots(session_id);
create unique index uq_reservation_slots_member_session
  on public.reservation_slots(session_id, ((select member_id from public.reservations r where r.id = reservation_id)))
  -- Postgres note: enforce single-hold-per-member-per-session in a trigger instead if the subquery index is unsupported
  ;

-- Simpler: enforce via trigger (see Section 19).
```

### 7.3 `waitlist_holds`

When a session fills, waitlisted `reservation_slots` sit in this ordered queue. When a spot opens, the head of the queue is offered a 15-minute confirm window.

```sql
create table public.waitlist_holds (
  id             uuid primary key default gen_random_uuid(),
  session_id     uuid not null references public.sessions(id) on delete cascade,
  reservation_id uuid not null references public.reservations(id) on delete cascade,
  position       smallint not null,
  offered_at     timestamptz,
  confirm_deadline timestamptz,
  status         text not null default 'waiting' check (status in ('waiting','offered','confirmed','expired','released')),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique(session_id, reservation_id)
);

create index idx_waitlist_active on public.waitlist_holds(session_id, position) where status in ('waiting','offered');
```

### 7.4 `attendance`

Recorded when a member checks in (geofence, QR, or staff mark). One row per `reservation_slot`.

```sql
create table public.attendance (
  id             uuid primary key default gen_random_uuid(),
  reservation_slot_id uuid not null references public.reservation_slots(id) on delete cascade,
  member_id      uuid not null references public.members(id),
  session_id     uuid not null references public.sessions(id),
  location_id    uuid not null references public.locations(id),
  method         text not null check (method in ('geofence','qr','staff_manual','walk_in')),
  checked_in_at  timestamptz not null default now(),
  checked_in_by  uuid references public.members(id),
  duration_seconds integer,
  temperature_c  smallint,                                -- for heat/cold sessions
  note           text,
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  unique(reservation_slot_id)
);

create index idx_attendance_member_time on public.attendance(member_id, checked_in_at desc);
create index idx_attendance_session on public.attendance(session_id);
```

### 7.5 `post_ritual_feedback`

One-tap emotion + optional note. Feeds Recovery Index and Concierge.

```sql
create table public.post_ritual_feedback (
  id             uuid primary key default gen_random_uuid(),
  reservation_id uuid not null references public.reservations(id) on delete cascade,
  member_id      uuid not null references public.members(id),
  emotion        text not null check (emotion in ('restored','calm','energised','ok','not_great')),
  note           text,
  created_at     timestamptz not null default now(),
  unique(reservation_id)
);
```

### 7.6 `cancellation_policies`

Configurable per product / plan / service. Applied at cancel time by a function.

```sql
create table public.cancellation_policies (
  id                       uuid primary key default gen_random_uuid(),
  scope                    text not null check (scope in ('global','plan','service')),
  scope_ref_id             uuid,                                  -- plan_id or service_id
  free_cancel_hours_prior  smallint not null default 4,
  late_cancel_credit_cost  smallint not null default 1,
  no_show_credit_cost      smallint not null default 1,
  no_show_strike_delta     smallint not null default 1,
  reschedule_hours_prior   smallint not null default 4,
  max_reschedules          smallint not null default 1,
  active                   boolean not null default true,
  created_at               timestamptz not null default now(),
  updated_at               timestamptz not null default now()
);
```

### 7.7 `strikes`

Members accumulate strikes from no-shows. Threshold triggers a concierge conversation (not a punishment).

```sql
create table public.strikes (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  reservation_id uuid references public.reservations(id),
  reason         text not null default 'no_show',
  weight         smallint not null default 1,
  cleared_at     timestamptz,
  cleared_by     uuid references public.members(id),
  created_at     timestamptz not null default now()
);

create index idx_strikes_member_active on public.strikes(member_id) where cleared_at is null;
```

## 8. Concierge & AI

### 8.1 `concierge_whispers`

Every AI-authored or trainer-authored recommendation. Structured object with an action.

```sql
create table public.concierge_whispers (
  id                uuid primary key default gen_random_uuid(),
  member_id         uuid not null references public.members(id) on delete cascade,
  theme             text not null,                          -- 'recovery_reset','sleep_nudge','guest_pass',...
  title             text not null,                          -- copy from Brand Bible voice
  body_md           text not null,
  rationale         text,                                   -- shown on tap
  action_kind       text not null check (action_kind in ('reserve_ritual','reserve_service','open_url','snooze','no_action')),
  action_payload    jsonb not null default '{}'::jsonb,
  attributed_trainer_id uuid references public.members(id),
  status            text not null default 'draft' check (status in ('draft','approved','sent','followed','dismissed','snoozed','expired')),
  scheduled_for     timestamptz,
  sent_at           timestamptz,
  followed_at       timestamptz,
  dismissed_at      timestamptz,
  snoozed_until     timestamptz,
  model_name        text,
  model_version     text,
  prompt_hash       text,
  input_snapshot    jsonb,                                  -- what the AI saw
  output_raw        jsonb,                                  -- what the AI said
  metadata          jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index idx_whispers_member_time on public.concierge_whispers(member_id, created_at desc);
create index idx_whispers_status on public.concierge_whispers(status);
create index idx_whispers_scheduled on public.concierge_whispers(scheduled_for) where status = 'approved';
```

### 8.2 `concierge_conversations` & `concierge_messages`

When a member opens the Concierge surface directly, we thread messages.

```sql
create table public.concierge_conversations (
  id           uuid primary key default gen_random_uuid(),
  member_id    uuid not null references public.members(id) on delete cascade,
  started_at   timestamptz not null default now(),
  ended_at     timestamptz,
  last_message_at timestamptz not null default now(),
  metadata     jsonb not null default '{}'::jsonb,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create index idx_concierge_convo_member on public.concierge_conversations(member_id, last_message_at desc);

create table public.concierge_messages (
  id              uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.concierge_conversations(id) on delete cascade,
  role            text not null check (role in ('member','concierge','trainer','system')),
  content_md      text not null,
  action_kind     text,
  action_payload  jsonb,
  attributed_trainer_id uuid references public.members(id),
  model_name      text,
  model_version   text,
  prompt_hash     text,
  redacted        boolean not null default false,
  created_at      timestamptz not null default now()
);

create index idx_concierge_msg_convo on public.concierge_messages(conversation_id, created_at);
```

### 8.3 `concierge_safety_events`

Any red-flag detection (medical, mental-health). Escalated to a human, always.

```sql
create table public.concierge_safety_events (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id),
  source         text not null check (source in ('whisper','conversation','feedback')),
  source_id      uuid,
  category       text not null,                              -- 'chest_pain','injury','mental_health','other'
  severity       text not null check (severity in ('advisory','urgent','emergency')),
  handled_by     uuid references public.members(id),
  handled_at     timestamptz,
  notes          text,
  created_at     timestamptz not null default now()
);
```

## 9. Recovery Index & progress

### 9.1 `recovery_index_inputs`

Raw signals, one row per emission. Feeds a rollup view.

```sql
create table public.recovery_index_inputs (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  input_kind     text not null check (input_kind in ('session','self_report','wearable')),
  signal         text not null,                              -- 'recovery','heat','cold','mobility','strength','breath','sleep','stress','mood','hydration'
  value_numeric  numeric,                                    -- e.g. minutes, score
  value_text     text,
  weight         numeric(3,2) not null default 1.0,
  reservation_id uuid references public.reservations(id),
  session_id     uuid references public.sessions(id),
  self_report_id uuid references public.self_reports(id),
  observed_at    timestamptz not null default now(),
  created_at     timestamptz not null default now()
);

create index idx_ri_inputs_member_time on public.recovery_index_inputs(member_id, observed_at desc);
create index idx_ri_inputs_signal on public.recovery_index_inputs(member_id, signal, observed_at desc);
```

### 9.2 `self_reports`

Member self-reported wellness signals (mood, sleep, hydration, stress, flexibility).

```sql
create table public.self_reports (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  reported_for   date not null,                              -- date the report describes
  mood           smallint check (mood between 1 and 5),
  sleep_hours    numeric(3,1),
  sleep_quality  smallint check (sleep_quality between 1 and 5),
  stress         smallint check (stress between 1 and 5),
  hydration_l   numeric(3,1),
  flexibility    smallint check (flexibility between 1 and 5),
  weight_g       integer,
  body_fat_pct   numeric(4,1),
  note           text,
  created_at     timestamptz not null default now(),
  unique(member_id, reported_for)
);
```

### 9.3 `recovery_index_daily`

Rollup, one row per member per day. Written by a scheduled function.

```sql
create table public.recovery_index_daily (
  member_id       uuid not null references public.members(id) on delete cascade,
  day             date not null,
  score           smallint not null check (score between 0 and 100),
  narrative       text,                                     -- 'Steady. Sleep dipped Tuesday–Thursday.'
  components      jsonb not null default '{}'::jsonb,       -- per-signal breakdown
  computed_at     timestamptz not null default now(),
  primary key (member_id, day)
);

create index idx_ri_daily_day on public.recovery_index_daily(day desc);
```

### 9.4 `wellness_metrics`

Historical anthropometrics + composite scores over time.

```sql
create table public.wellness_metrics (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  measured_at    timestamptz not null default now(),
  weight_g       integer,
  body_fat_pct   numeric(4,1),
  muscle_mass_g  integer,
  bmi            numeric(4,1),
  mobility_score smallint,
  wellness_score smallint,
  source         text not null default 'self' check (source in ('self','trainer','wearable','device')),
  created_at     timestamptz not null default now()
);

create index idx_metrics_member_time on public.wellness_metrics(member_id, measured_at desc);
```

## 10. Timeline & status ladder

### 10.1 `timeline_milestones`

Emitted (mostly automatically) by triggers on reservations, attendance, memberships, referrals. Rendered as the Member Timeline.

```sql
create table public.timeline_milestones (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  kind           milestone_type not null,
  occurred_at    timestamptz not null default now(),
  title          text not null,
  body_md        text,
  icon           text,
  media_url      text,
  data           jsonb not null default '{}'::jsonb,        -- structured detail (session count, tier from/to, etc.)
  visible_to_member boolean not null default true,
  emitted_by     text not null default 'system',            -- 'system' | 'staff' | member_id
  deleted_at     timestamptz,
  created_at     timestamptz not null default now()
);

create index idx_timeline_member_time on public.timeline_milestones(member_id, occurred_at desc);
create index idx_timeline_kind on public.timeline_milestones(kind);
```

**Trigger emissions (implemented in Section 19):**
- First reservation → `first_ritual`
- Every 10th attendance → `session_count`
- Recovery hours crossing 100 / 250 / 500 → `recovery_hours`
- Tier change → `tier_elevation`
- Challenge completion → `challenge_completed`
- Membership anniversary → `anniversary`
- Return after 60+ days absence → `return`

### 10.2 `tier_definitions`

Editable rules for the status ladder.

```sql
create table public.tier_definitions (
  tier           tier_level primary key,
  display_name   text not null,
  min_days_active smallint not null default 0,
  min_sessions   smallint not null default 0,
  invite_only    boolean not null default false,
  benefits_md    text,
  guest_passes_per_month smallint not null default 0,
  paradiso_discount_pct  smallint not null default 0,
  priority_booking_hours smallint not null default 0
);
```

Seed values:

| tier | days | sessions | invite | passes/mo |
|---|---:|---:|:---:|---:|
| explorer | 0 | 0 | false | 0 |
| member | 30 | 12 | false | 1 |
| resident | 90 | 40 | false | 2 |
| inner_circle | 180 | 100 | false | 3 |
| founder | — | — | true | 4 |

### 10.3 `tier_transitions`

Audit trail for elevations. Written by trigger + admin action.

```sql
create table public.tier_transitions (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  from_tier      tier_level,
  to_tier        tier_level not null,
  reason         text,                                       -- 'system_criteria','manager_override','founder_invite'
  actor_id       uuid references public.members(id),
  occurred_at    timestamptz not null default now(),
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);
```

## 11. Community: challenges, badges, events

### 11.1 `challenges`

```sql
create table public.challenges (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique,
  name           text not null,
  tagline        text,
  description_md text,
  hero_image_url text,
  starts_on      date not null,
  ends_on        date not null,
  status         challenge_status not null default 'draft',
  criteria       jsonb not null default '{}'::jsonb,        -- {'kind':'sessions','signal':'recovery','count':10}
  reward         jsonb not null default '{}'::jsonb,        -- {'badge': 'recovery-streak-2026-07'}
  visibility     text not null default 'members',
  leaderboard_public boolean not null default false,
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  check (ends_on >= starts_on)
);
```

### 11.2 `challenge_participants`

```sql
create table public.challenge_participants (
  id             uuid primary key default gen_random_uuid(),
  challenge_id   uuid not null references public.challenges(id) on delete cascade,
  member_id      uuid not null references public.members(id) on delete cascade,
  joined_at      timestamptz not null default now(),
  progress       jsonb not null default '{}'::jsonb,        -- {'count': 6, 'last_signal_at': '...'}
  completed_at   timestamptz,
  opted_in_leaderboard boolean not null default false,
  unique(challenge_id, member_id)
);

create index idx_challenge_participants_member on public.challenge_participants(member_id);
```

### 11.3 `badges` & `member_badges`

```sql
create table public.badges (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique,
  name           text not null,
  description_md text,
  icon_url       text,
  created_at     timestamptz not null default now()
);

create table public.member_badges (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  badge_id       uuid not null references public.badges(id),
  awarded_at     timestamptz not null default now(),
  source         text,                                       -- 'challenge:recovery-streak-2026-07'
  unique(member_id, badge_id)
);
```

### 11.4 `events`

Workshops, socials, Founder dinners.

```sql
create table public.events (
  id                uuid primary key default gen_random_uuid(),
  slug              text not null unique,
  name              text not null,
  description_md    text,
  hero_image_url    text,
  location_id       uuid references public.locations(id),
  starts_at         timestamptz not null,
  ends_at           timestamptz not null,
  capacity          smallint not null,
  visibility        text not null default 'members' check (visibility in ('members','tier','invite')),
  visibility_tier   tier_level,
  is_invite_only    boolean not null default false,
  price_paise       bigint not null default 0,
  currency          char(3) not null default 'INR',
  metadata          jsonb not null default '{}'::jsonb,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table public.event_rsvps (
  id             uuid primary key default gen_random_uuid(),
  event_id       uuid not null references public.events(id) on delete cascade,
  member_id      uuid not null references public.members(id) on delete cascade,
  status         text not null default 'confirmed' check (status in ('invited','confirmed','waitlisted','declined','cancelled','attended','no_show')),
  invited_at     timestamptz,
  responded_at   timestamptz,
  plus_ones      smallint not null default 0,
  notes          text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  unique(event_id, member_id)
);
```

## 12. Paradiso (V1 subset)

### 12.1 `paradiso_items`

Menu items surfaced inside Sanctuary in V1.

```sql
create table public.paradiso_items (
  id             uuid primary key default gen_random_uuid(),
  slug           text not null unique,
  name           text not null,
  description    text,
  category       text not null,                              -- 'drink','bowl','snack','recovery','coffee','tea'
  price_paise    bigint not null,
  member_price_paise bigint,                                 -- when different
  currency       char(3) not null default 'INR',
  nutrition      jsonb not null default '{}'::jsonb,         -- {calories, protein_g, sugar_g, ...}
  dietary_flags  text[] not null default '{}',               -- ['vegan','gf','high_protein',...]
  pairs_with_services uuid[] not null default '{}',          -- default pairings for ritual suggestions
  image_url      text,
  active         boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
```

### 12.2 `paradiso_orders`

```sql
create table public.paradiso_orders (
  id                uuid primary key default gen_random_uuid(),
  member_id         uuid not null references public.members(id) on delete restrict,
  location_id       uuid not null references public.locations(id),
  status            text not null default 'placed' check (status in ('placed','preparing','ready','collected','cancelled','refunded')),
  pickup_at         timestamptz not null,
  total_paise       bigint not null,
  currency          char(3) not null default 'INR',
  applied_to_statement boolean not null default false,
  reservation_id    uuid references public.reservations(id),  -- when linked to a ritual
  notes             text,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz
);

create index idx_paradiso_orders_member on public.paradiso_orders(member_id, created_at desc);
create index idx_paradiso_orders_pickup on public.paradiso_orders(pickup_at);

create table public.paradiso_order_items (
  id             uuid primary key default gen_random_uuid(),
  order_id       uuid not null references public.paradiso_orders(id) on delete cascade,
  item_id        uuid not null references public.paradiso_items(id),
  qty            smallint not null default 1 check (qty > 0),
  unit_price_paise bigint not null,
  currency       char(3) not null default 'INR',
  notes          text,
  created_at     timestamptz not null default now()
);
```

## 13. Guest passes, referrals, rewards

### 13.1 `guest_passes`

Single-use codes issued by members (per their tier allowance).

```sql
create table public.guest_passes (
  id                uuid primary key default gen_random_uuid(),
  member_id         uuid not null references public.members(id) on delete restrict,
  code              text not null unique,                    -- short, URL-safe
  status            text not null default 'issued' check (status in ('issued','sent','redeemed','revoked','expired')),
  issued_at         timestamptz not null default now(),
  expires_at        timestamptz not null,
  sent_to_name      text,
  sent_to_phone     text,
  redeemed_by_member_id uuid references public.members(id),
  redeemed_at       timestamptz,
  reservation_id    uuid references public.reservations(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  deleted_at        timestamptz
);

create index idx_guest_passes_member on public.guest_passes(member_id);
create index idx_guest_passes_status on public.guest_passes(status);
```

### 13.2 `referrals`

```sql
create table public.referrals (
  id                uuid primary key default gen_random_uuid(),
  referrer_id       uuid not null references public.members(id) on delete cascade,
  invitee_email     citext,
  invitee_phone     text,
  invitee_name      text,
  code              text not null unique,
  status            text not null default 'sent' check (status in ('sent','viewed','joined','expired','revoked')),
  sent_at           timestamptz not null default now(),
  joined_member_id  uuid references public.members(id),
  joined_at         timestamptz,
  reward_granted    boolean not null default false,
  reward_credit_id  uuid references public.membership_credits(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index idx_referrals_referrer on public.referrals(referrer_id);
create index idx_referrals_status on public.referrals(status);
```

### 13.3 `rewards_ledger`

Internal points accounting substrate. Vocabulary in-product is *status*, but points power challenges, referrals, and internal accounting.

```sql
create table public.rewards_ledger (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  event          text not null,                              -- 'attendance','challenge_complete','referral',...
  points_delta   integer not null,
  balance_after  integer not null,
  ref_kind       text,                                       -- 'reservation','challenge','referral'
  ref_id         uuid,
  notes          text,
  created_at     timestamptz not null default now()
);

create index idx_rewards_member_time on public.rewards_ledger(member_id, created_at desc);
```

## 14. Notifications

### 14.1 `notification_preferences`

One row per member. Per-category, per-channel toggles + DND window.

```sql
create table public.notification_preferences (
  member_id      uuid primary key references public.members(id) on delete cascade,
  channels       jsonb not null default jsonb_build_object(
                   'inapp', true, 'push', true, 'email', true, 'whatsapp', true, 'sms', false),
  categories     jsonb not null default '{}'::jsonb,          -- per-category channel maps
  dnd_start      time not null default '22:00',
  dnd_end        time not null default '07:00',
  timezone       text not null default 'Asia/Kolkata',
  updated_at     timestamptz not null default now()
);
```

### 14.2 `notifications`

Every message sent or queued. One row per (member, channel, event).

```sql
create table public.notifications (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  category       notification_category not null,
  channel        notification_channel not null,
  subject        text,
  body_md        text not null,
  template_key   text,                                       -- 'reservation.reminder.60m'
  ref_kind       text,                                       -- 'reservation','membership','payment','whisper'
  ref_id         uuid,
  scheduled_for  timestamptz not null default now(),
  sent_at        timestamptz,
  status         text not null default 'queued' check (status in ('queued','sending','sent','failed','skipped')),
  provider_message_id text,
  error          text,
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);

create index idx_notifications_member_time on public.notifications(member_id, scheduled_for desc);
create index idx_notifications_status on public.notifications(status);
create index idx_notifications_queue on public.notifications(scheduled_for) where status = 'queued';
```

### 14.3 `inapp_inbox`

Persistent in-app notification inbox (subset of notifications where `channel='inapp'`).

```sql
create table public.inapp_inbox (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  notification_id uuid references public.notifications(id) on delete set null,
  title          text not null,
  body_md        text,
  deep_link      text,
  read_at        timestamptz,
  created_at     timestamptz not null default now()
);

create index idx_inbox_member_unread on public.inapp_inbox(member_id, created_at desc) where read_at is null;
```

### 14.4 `push_subscriptions`

Web push endpoints.

```sql
create table public.push_subscriptions (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  endpoint       text not null unique,
  p256dh         text not null,
  auth           text not null,
  ua             text,
  active         boolean not null default true,
  created_at     timestamptz not null default now(),
  last_seen_at   timestamptz
);
```

## 15. Support

### 15.1 `support_tickets`

```sql
create table public.support_tickets (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete restrict,
  category       text not null check (category in ('booking','billing','technical','membership','other')),
  subject        text not null,
  status         ticket_status not null default 'open',
  priority       support_priority not null default 'normal',
  assigned_to    uuid references public.members(id),
  first_response_at timestamptz,
  resolved_at    timestamptz,
  closed_at      timestamptz,
  csat_rating    smallint check (csat_rating between 1 and 5),
  csat_comment   text,
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz
);

create index idx_tickets_member on public.support_tickets(member_id, created_at desc);
create index idx_tickets_status on public.support_tickets(status) where status in ('open','pending');
```

### 15.2 `support_messages`

```sql
create table public.support_messages (
  id             uuid primary key default gen_random_uuid(),
  ticket_id      uuid not null references public.support_tickets(id) on delete cascade,
  author_id      uuid not null references public.members(id),
  author_role    user_role not null,
  body_md        text not null,
  attachments    jsonb not null default '[]'::jsonb,         -- [{name, url, size}]
  is_internal    boolean not null default false,
  created_at     timestamptz not null default now()
);

create index idx_support_msg_ticket on public.support_messages(ticket_id, created_at);
```

## 16. Payments, invoices, ledger

Payments in India via Razorpay. Store enough locally to reconcile without depending on Razorpay for reads.

### 16.1 `payment_customers`

Razorpay customer mapping.

```sql
create table public.payment_customers (
  member_id       uuid primary key references public.members(id) on delete cascade,
  razorpay_customer_id text not null unique,
  gstin           text,
  billing_name    text,
  billing_address jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
```

### 16.2 `payment_mandates`

For auto-renew (eNACH / UPI Autopay). One primary per member.

```sql
create table public.payment_mandates (
  id                     uuid primary key default gen_random_uuid(),
  member_id              uuid not null references public.members(id) on delete restrict,
  provider               text not null default 'razorpay',
  provider_mandate_id    text not null,
  method                 text not null check (method in ('upi_autopay','enach_debit','card')),
  status                 text not null check (status in ('pending','active','paused','revoked','failed')),
  max_amount_paise       bigint not null,
  currency               char(3) not null default 'INR',
  first_charge_at        timestamptz,
  last_charge_at         timestamptz,
  next_charge_at         timestamptz,
  is_primary             boolean not null default false,
  metadata               jsonb not null default '{}'::jsonb,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now(),
  unique(provider, provider_mandate_id)
);

create unique index uq_primary_mandate on public.payment_mandates(member_id) where is_primary;
```

### 16.3 `payments`

Every charge attempt. One row per Razorpay payment object.

```sql
create table public.payments (
  id                     uuid primary key default gen_random_uuid(),
  member_id              uuid not null references public.members(id) on delete restrict,
  provider               text not null default 'razorpay',
  provider_order_id      text,
  provider_payment_id    text unique,
  status                 payment_status not null default 'created',
  amount_paise           bigint not null,
  currency               char(3) not null default 'INR',
  method                 text,                                -- 'upi','card','netbanking','wallet'
  purpose                text not null check (purpose in ('membership_new','membership_renew','membership_upgrade','ritual_addon','paradiso','event','other')),
  ref_kind               text,
  ref_id                 uuid,
  invoice_id             uuid,
  captured_at            timestamptz,
  failed_at              timestamptz,
  refunded_amount_paise  bigint not null default 0,
  provider_meta          jsonb not null default '{}'::jsonb,
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now()
);

create index idx_payments_member_time on public.payments(member_id, created_at desc);
create index idx_payments_status on public.payments(status);
```

### 16.4 `invoices`

GST-compliant invoices.

```sql
create table public.invoices (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete restrict,
  number         text not null unique,                       -- 'SW/2026-27/000123'
  status         invoice_status not null default 'draft',
  issued_at      date not null default current_date,
  due_at         date,
  subtotal_paise bigint not null,
  cgst_paise     bigint not null default 0,
  sgst_paise     bigint not null default 0,
  igst_paise     bigint not null default 0,
  discount_paise bigint not null default 0,
  total_paise    bigint not null,
  currency       char(3) not null default 'INR',
  place_of_supply text,
  gstin          text,
  pdf_url        text,
  metadata       jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  deleted_at     timestamptz
);

create index idx_invoices_member_time on public.invoices(member_id, issued_at desc);

create table public.invoice_line_items (
  id             uuid primary key default gen_random_uuid(),
  invoice_id     uuid not null references public.invoices(id) on delete cascade,
  description    text not null,
  qty            numeric(10,2) not null default 1,
  unit_price_paise bigint not null,
  amount_paise   bigint not null,
  hsn_sac_code   text,
  gst_rate       numeric(4,2) not null default 18.00,
  ref_kind       text,
  ref_id         uuid,
  created_at     timestamptz not null default now()
);
```

### 16.5 `refunds`

```sql
create table public.refunds (
  id             uuid primary key default gen_random_uuid(),
  payment_id     uuid not null references public.payments(id),
  amount_paise   bigint not null,
  reason         text,
  status         text not null default 'created' check (status in ('created','processed','failed')),
  provider_refund_id text unique,
  issued_by      uuid references public.members(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
```

### 16.6 `payment_events`

Webhook log — for reconciliation and debugging. Store raw.

```sql
create table public.payment_events (
  id             bigserial primary key,
  provider       text not null default 'razorpay',
  event          text not null,
  provider_event_id text unique,
  payload        jsonb not null,
  processed_at   timestamptz,
  error          text,
  received_at    timestamptz not null default now()
);

create index idx_payment_events_processing on public.payment_events(received_at) where processed_at is null;
```

## 17. Analytics, audit, feature flags

### 17.1 `analytics_events`

Server-side event stream mirror. PostHog is the source of truth for product analytics; this table is the durable, queryable copy.

```sql
create table public.analytics_events (
  id             bigserial primary key,
  member_id      uuid references public.members(id) on delete set null,
  anon_id        text,
  session_id     text,
  name           text not null,
  properties     jsonb not null default '{}'::jsonb,
  occurred_at    timestamptz not null default now(),
  received_at    timestamptz not null default now()
);

create index idx_events_name_time on public.analytics_events(name, occurred_at desc);
create index idx_events_member_time on public.analytics_events(member_id, occurred_at desc);
```

### 17.2 `audit_log`

Privileged actions. Immutable.

```sql
create table public.audit_log (
  id             bigserial primary key,
  actor_id       uuid references public.members(id),
  actor_role     user_role,
  action         text not null,                              -- 'refund.issue','tier.override','plan.change','flag.set',...
  target_kind    text,
  target_id      uuid,
  before         jsonb,
  after          jsonb,
  ip             inet,
  ua             text,
  occurred_at    timestamptz not null default now()
);

create index idx_audit_action_time on public.audit_log(action, occurred_at desc);
create index idx_audit_actor_time on public.audit_log(actor_id, occurred_at desc);
```

### 17.3 `feature_flags`

Read-heavy. Cached at the edge; DB is authoritative.

```sql
create table public.feature_flags (
  key            text primary key,
  description    text,
  environments   jsonb not null default '{}'::jsonb,         -- {'dev':true,'staging':false,'prod':false}
  rollout_pct    smallint,
  segments       jsonb not null default '[]'::jsonb,         -- [{'tier':'founder'}]
  updated_by     uuid references public.members(id),
  updated_at     timestamptz not null default now()
);
```

### 17.4 `consent_records`

Every consent event (marketing, health-share, terms). Compliance evidence.

```sql
create table public.consent_records (
  id             uuid primary key default gen_random_uuid(),
  member_id      uuid not null references public.members(id) on delete cascade,
  kind           text not null,                              -- 'terms','privacy','marketing','health_share','photo'
  version        text not null,
  granted        boolean not null,
  ip             inet,
  ua             text,
  occurred_at    timestamptz not null default now()
);

create index idx_consent_member on public.consent_records(member_id, kind, occurred_at desc);
```

### 17.5 `announcements`

Staff-composed, member-facing.

```sql
create table public.announcements (
  id             uuid primary key default gen_random_uuid(),
  title          text not null,
  body_md        text not null,
  audience_tier  tier_level,
  audience_location_id uuid references public.locations(id),
  publish_at     timestamptz not null default now(),
  expires_at     timestamptz,
  created_by     uuid references public.members(id),
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
```

## 18. Row-Level Security policies

RLS is enabled on every table in `public`. Policies rely on two helper functions:

```sql
-- Returns the member row for the calling auth.uid()
create or replace function public.current_member()
returns public.members
language sql stable security definer as $$
  select m.* from public.members m where m.auth_user_id = auth.uid() limit 1;
$$;

-- Coarse role check
create or replace function public.has_role(needed user_role[])
returns boolean
language sql stable security definer as $$
  select exists (
    select 1 from public.members m
    where m.auth_user_id = auth.uid() and m.role = any(needed)
  );
$$;

-- Is trainer rostered on this session?
create or replace function public.is_trainer_on_session(_session_id uuid)
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.sessions s
    join public.members me on me.auth_user_id = auth.uid()
    where s.id = _session_id and s.trainer_id = me.id
  );
$$;

-- Is trainer assigned to member?
create or replace function public.is_trainer_of(_member_id uuid)
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.trainer_assignments ta
    join public.members me on me.auth_user_id = auth.uid()
    where ta.trainer_id = me.id and ta.member_id = _member_id and ta.ended_at is null
  );
$$;
```

### 18.1 Policy templates

**Member-owned records** (Signature, health, reservations, feedback, self-reports, orders, tickets, notifications, timeline):

```sql
alter table public.<t> enable row level security;

create policy "<t>_owner_read" on public.<t>
  for select using (member_id = (select id from public.members where auth_user_id = auth.uid()));

create policy "<t>_owner_write" on public.<t>
  for insert with check (member_id = (select id from public.members where auth_user_id = auth.uid()));

create policy "<t>_owner_update" on public.<t>
  for update using (member_id = (select id from public.members where auth_user_id = auth.uid()));

-- Staff extension:
create policy "<t>_staff_read" on public.<t>
  for select using (public.has_role(array['manager','admin','owner']));
```

**Trainer scoping** (member card, health, reservations of assigned members):

```sql
create policy "<t>_trainer_read" on public.<t>
  for select using (
    public.has_role(array['trainer'])
    and public.is_trainer_of(member_id)
  );
```

**Catalogue tables** (services, rituals, plans, paradiso items, locations, badges, events):

```sql
alter table public.<t> enable row level security;
create policy "<t>_read_all" on public.<t> for select using (true);
create policy "<t>_admin_write" on public.<t> for all using (public.has_role(array['admin','owner']));
```

**Analytics / audit / payment events / logs**: read-only for owners; inserts by service role only.

**Concierge whispers**: read own; write by service role (AI) and trainer approvals scoped to attributed_trainer_id.

**Feature flags**: read by all; write by admin/owner.

### 18.2 Sensitive-column read-time gating

`member_health` is readable to a trainer **only if** `members.consent_health_share_with_trainer = true`:

```sql
create policy "member_health_trainer_conditional" on public.member_health
  for select using (
    public.has_role(array['trainer']) and public.is_trainer_of(member_id)
    and exists (select 1 from public.members m where m.id = member_health.member_id
                and m.consent_health_share_with_trainer = true)
  );
```

### 18.3 Storage buckets

- `signature-media/` (member-owned; RLS by member_id in path)
- `invoices/` (read: owner; write: service role)
- `paradiso/` (read: all authed; write: admin)
- `member-media/` (event photos, consent-gated)

## 19. Triggers & functions

### 19.1 `updated_at` auto-touch

Applied to every table with `updated_at`:

```sql
create or replace function public.tg_touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- example:
create trigger tg_members_touch before update on public.members
  for each row execute function public.tg_touch_updated_at();
```

### 19.2 Reservation lifecycle

**On reservation insert** — enforce capacity + one-hold-per-member-per-session:

```sql
create or replace function public.tg_reservation_slot_capacity()
returns trigger language plpgsql as $$
declare
  taken smallint;
  cap smallint;
  member_uuid uuid;
begin
  select capacity into cap from public.sessions where id = new.session_id;
  select member_id into member_uuid from public.reservations where id = new.reservation_id;

  -- reject duplicate hold by same member on same session
  if exists (
    select 1 from public.reservation_slots rs
    join public.reservations r on r.id = rs.reservation_id
    where rs.session_id = new.session_id and r.member_id = member_uuid and rs.id <> new.id
  ) then
    raise exception 'member already holds a slot on this session';
  end if;

  select count(*) into taken from public.reservation_slots rs
  join public.reservations r on r.id = rs.reservation_id
  where rs.session_id = new.session_id
    and rs.status in ('reserved','confirmed','checked_in','completed');

  if taken >= cap then
    -- push to waitlist instead of blocking; caller uses waitlist_holds
    raise exception 'session at capacity; use waitlist path';
  end if;

  return new;
end $$;

create trigger tg_reservation_slot_capacity_before_insert
  before insert on public.reservation_slots
  for each row execute function public.tg_reservation_slot_capacity();
```

### 19.3 Waitlist promotion

```sql
create or replace function public.promote_waitlist(_session_id uuid)
returns void language plpgsql security definer as $$
declare
  wl record;
begin
  select * into wl from public.waitlist_holds
    where session_id = _session_id and status = 'waiting'
    order by position asc limit 1;
  if not found then return; end if;

  update public.waitlist_holds
    set status = 'offered', offered_at = now(),
        confirm_deadline = now() + interval '15 minutes'
    where id = wl.id;

  update public.reservations
    set is_waitlisted = true, waitlist_offered_at = now(),
        waitlist_confirm_deadline = now() + interval '15 minutes'
    where id = wl.reservation_id;

  -- notification emission handled by outbound service
end $$;
```

Triggered whenever a `reservation_slot` transitions to `cancelled_member`, `cancelled_staff`, or `late_cancelled`.

### 19.4 Attendance → Recovery Index input

On attendance insert, emit a Recovery Index signal derived from the service:

```sql
create or replace function public.tg_attendance_to_ri_input()
returns trigger language plpgsql as $$
declare
  svc record;
begin
  select s.recovery_signal, s.recovery_weight, s.duration_min
    into svc
    from public.sessions se
    join public.services s on s.id = se.service_id
    where se.id = new.session_id;

  if svc.recovery_signal <> 'none' then
    insert into public.recovery_index_inputs
      (member_id, input_kind, signal, value_numeric, weight, reservation_id, session_id, observed_at)
    values
      (new.member_id, 'session', svc.recovery_signal, svc.duration_min, svc.recovery_weight, null, new.session_id, new.checked_in_at);
  end if;
  return new;
end $$;

create trigger tg_attendance_ri
  after insert on public.attendance
  for each row execute function public.tg_attendance_to_ri_input();
```

### 19.5 Timeline milestones (auto)

On first-ever attendance → `first_ritual`. Every 10th → `session_count`. Etc.

```sql
create or replace function public.tg_attendance_timeline()
returns trigger language plpgsql as $$
declare
  cnt integer;
begin
  select count(*) into cnt from public.attendance where member_id = new.member_id;
  if cnt = 1 then
    insert into public.timeline_milestones(member_id, kind, occurred_at, title, body_md)
    values (new.member_id, 'first_ritual', new.checked_in_at, 'Your first ritual', 'A quiet beginning.');
  elsif cnt % 10 = 0 then
    insert into public.timeline_milestones(member_id, kind, occurred_at, title, body_md, data)
    values (new.member_id, 'session_count', new.checked_in_at,
            cnt || 'th visit', 'Thank you for being here.', jsonb_build_object('count', cnt));
  end if;
  return new;
end $$;

create trigger tg_attendance_timeline
  after insert on public.attendance
  for each row execute function public.tg_attendance_timeline();
```

### 19.6 Tier evaluation

Runs nightly (scheduled) and after every attendance:

```sql
create or replace function public.evaluate_tier(_member_id uuid)
returns void language plpgsql security definer as $$
declare
  current_tier tier_level;
  next_tier tier_level;
  days_active integer;
  sessions integer;
begin
  select tier into current_tier from public.members where id = _member_id;
  if current_tier = 'founder' then return; end if;

  select coalesce(extract(day from (now() - min(occurred_at)))::int, 0) into days_active
    from public.timeline_milestones where member_id = _member_id and kind in ('joined','first_ritual');

  select count(*) into sessions from public.attendance where member_id = _member_id;

  select t.tier into next_tier from public.tier_definitions t
    where not t.invite_only
      and days_active >= t.min_days_active
      and sessions >= t.min_sessions
    order by t.min_sessions desc limit 1;

  if next_tier is not null and next_tier <> current_tier then
    insert into public.tier_transitions(member_id, from_tier, to_tier, reason)
    values (_member_id, current_tier, next_tier, 'system_criteria');

    update public.members set tier = next_tier where id = _member_id;

    insert into public.timeline_milestones(member_id, kind, title, body_md, data)
    values (_member_id, 'tier_elevation',
            'Elevated to ' || initcap(replace(next_tier::text,'_',' ')),
            'A quiet welcome to your next chapter.',
            jsonb_build_object('from', current_tier, 'to', next_tier));
  end if;
end $$;
```

### 19.7 Membership renewal

Scheduled Edge Function reads `memberships` where `renews_at < now() + interval '2 days'` and `is_auto_renew`; charges via Razorpay; writes `payments`, `invoices`, `membership_ledger`.

### 19.8 Referral conversion

On `members` insert where `invited_by is not null`, mark corresponding `referrals` row as `joined`; grant `membership_credits` + `rewards_ledger` for the referrer.

### 19.9 Recovery Index rollup

Nightly job computes `recovery_index_daily` per member using last 7 days of `recovery_index_inputs` + `self_reports`. Formula documented in Section 20.

### 19.10 Concierge safety scan

Any incoming `concierge_messages.role='member'` passes through a safety-scan function; on match, inserts `concierge_safety_events` and short-circuits the AI response with a human-escalation card.

## 20. Indices & performance

### 20.1 Hot paths and their indices (already in DDL)

| Query | Index |
|---|---|
| Member's upcoming reservations | `idx_reservations_member_time` |
| Session capacity check | `idx_reservation_slots_session` |
| Waitlist head-of-queue | `idx_waitlist_active` |
| Trainer's rostered members | `idx_trainer_assignments_trainer` |
| Concierge queue for approval | `idx_whispers_status` |
| Renewal queue | `idx_memberships_renews` |
| Inbox unread | `idx_inbox_member_unread` |
| Notification dispatch | `idx_notifications_queue` |

### 20.2 Materialized views (Phase 3.5)

For owner dashboard heavy reads. Refreshed on a schedule.

- `mv_utilization_by_service_hour` — booked seats / (capacity × slots) per service per hour-of-day
- `mv_member_activity_daily` — attendance count, ritual mix, feedback emotion per member per day
- `mv_cohort_retention` — cohort by joined month, retention curve
- `mv_referral_funnel` — sent → viewed → joined → activated
- `mv_mrr_snapshot` — MRR by day, ARR forecast

Never queried by hot paths.

### 20.3 Recovery Index computation (Section 9.3)

Score = weighted average of last-7-day signals against baselines:

```
components = {
  training_load:   f(strength + hyrox + mobility minutes, weighted by intensity),
  recovery_stack:  f(ice + sauna + steam + contrast + breath session count, weighted),
  mobility:        f(mobility_sessions + flexibility_self_report),
  sleep:           f(sleep_hours + sleep_quality),
  stress:          f(inverse stress + breathwork frequency),
  hydration:       f(hydration_l),
  mood:            f(mood)
}
score = clamp(0..100, sum(component_weight_i × component_value_i))
narrative = f(component deltas vs prior 7-day baseline)
```

Weights are stored in `settings.recovery_index_weights` (JSONB config table, owner-editable). Initial weights per Service Playbook Section 12.

### 20.4 Query hygiene rules

- No unbounded scans on `analytics_events`, `notifications`, or `recovery_index_inputs` — always paginate + time-window.
- Text search uses `pg_trgm` on `paradiso_items.name`, `services.name`, `rituals.name`.
- Timestamps only in indices; never boolean status alone.

## 21. Migration plan & seeds

### 21.1 Migration order

Migrations live in `supabase/migrations/` as timestamp-prefixed SQL files. Deploy order matters (FKs).

```
20260101_000_enable_extensions.sql          -- pgcrypto, citext, pg_trgm
20260101_010_enums.sql
20260101_020_identity.sql                   -- members, signature, health, trainer_profiles, trainer_assignments
20260101_030_locations_rooms.sql
20260101_040_catalogue.sql                  -- services, service_variants, rituals, ritual_steps
20260101_050_plans.sql
20260101_060_memberships.sql
20260101_070_sessions.sql
20260101_080_reservations.sql               -- reservations, reservation_slots, waitlist, attendance, feedback, strikes, policies
20260101_090_concierge.sql
20260101_100_progress.sql                   -- recovery_index_inputs, self_reports, recovery_index_daily, wellness_metrics
20260101_110_timeline_tiers.sql
20260101_120_community.sql                  -- challenges, badges, events, rsvps
20260101_130_paradiso.sql
20260101_140_guest_passes_referrals_rewards.sql
20260101_150_notifications.sql
20260101_160_support.sql
20260101_170_payments.sql                   -- customers, mandates, payments, invoices, refunds, events
20260101_180_analytics_audit_flags.sql
20260101_190_announcements.sql
20260101_200_functions_triggers.sql
20260101_210_rls_policies.sql
20260101_220_seeds.sql
```

### 21.2 Seeds (V1 launch data)

- **Location:** `DEL-01 Sanctuary Delhi`
- **Rooms:** Sauna Suite 1/2, Steam Room, Ice Pod 1/2, Contrast Bay, Breath Studio, Mobility Studio, Strength Floor, Yoga Studio
- **Services (11):** ice_bath, sauna, steam, contrast, breathwork, yoga, pilates, mobility, strength, hyrox_class, stretch — populated per Service Playbook
- **Rituals (6):** morning_reset, recovery_reset, evening_wind_down, weekend_recharge, athlete_prep, post_event_restore
- **Plans (initial):** Sanctuary Core Monthly, Sanctuary Core Annual, Sanctuary Founder Annual (invite-only)
- **Tier definitions:** as in Section 10.2
- **Cancellation policy (global):** as in Section 7.6 defaults
- **Feature flags:** as in Phase 2 Section 15

### 21.3 Data lifecycle

- Development: reset button; seeds only, no real member data.
- Staging: sanitized production snapshot weekly (PII masked).
- Production: point-in-time recovery (Supabase), 30-day retention; nightly logical backup to encrypted storage; 90-day retention for backups.

### 21.4 Backups & DR

- **RPO:** 5 minutes (PITR).
- **RTO:** 60 minutes (restore + smoke).
- Quarterly restore drills, results logged in `audit_log`.

## 22. Review checklist

Before Phase 4 (User Flows), please confirm:

- [ ] Table set covers PRD/IA needs; nothing important missing
- [ ] Money type (`bigint` paise) and currency handling
- [ ] Product/location scoping columns on operational tables (super-app-ready)
- [ ] RLS approach (member-owned + trainer scoping via `is_trainer_of` + admin overrides)
- [ ] Trainer visibility of `member_health` is gated by `consent_health_share_with_trainer`
- [ ] Ritual reservations modelled as parent + `reservation_slots` children
- [ ] Waitlist queue with 15-minute confirm window (Section 19.3)
- [ ] Recovery Index inputs/rollup with transparent components (Sections 9.1, 9.3, 20.3)
- [ ] Timeline milestone emissions from triggers (Section 19.5) match Doc B
- [ ] Payments: Razorpay-centric with mandates, GST invoices, refunds, webhook log
- [ ] Audit log covers privileged actions (refunds, tier overrides, plan changes, flag toggles)
- [ ] Feature flags catalog aligns with Phase 2
- [ ] Migration order compiles cleanly (FK order)
- [ ] Seeds match Service Playbook and Phase 2

On approval, I'll move to **Phase 4 — User Flows**, mapping every critical journey (auth, onboarding, ritual reservation, cancellation, waitlist, renewal, guest pass, off-boarding, Concierge, staff check-in) as sequence diagrams and step lists grounded in this schema.

