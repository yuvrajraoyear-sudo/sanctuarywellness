# Phase 9 — Integrations & Third-Party Services

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

Every third-party dependency is a promise the app cannot keep alone. This document names every vendor, why they are chosen, what data flows across the boundary, and what happens when they fail.

Sections:
1. Vendor map
2. Payments — Razorpay
3. Messaging — WhatsApp BSP
4. Email — Resend
5. Analytics — PostHog
6. Error tracking — Sentry
7. Wearable & metric integrations
8. Calendar, maps, weather
9. CMS
10. Design & product tooling
11. Failure isolation & vendor exit
12. Data-processing register (DPDP §11)
13. Review checklist

---

## 1. Vendor map

| Domain | Vendor | Region | Data shared | Contract |
|---|---|---|---|---|
| Payments | Razorpay | India | Name, email, phone, invoice items, amount | DPA + PCI SAQ-A |
| WhatsApp BSP | Gupshup or AiSensy | India | Name, phone, template variables | DPA + Meta BSP terms |
| Email | Resend | EU or India POP | Name, email, message | DPA |
| SMS OTP fallback | MSG91 or Twilio | India / global | Phone, OTP code | DPA |
| Product analytics | PostHog Cloud | EU (data-residency add-on) or self-host | Anonymised events, no health data | DPA + BAA-equivalent |
| Marketing analytics | Plausible | EU | Anonymous page views | DPA |
| Error tracking | Sentry | EU | Stack traces (PII scrubbed) | DPA |
| Feature flags | PostHog | (same) | — | (same) |
| CMS | Sanity or Payload | EU / self-host | Editorial content only | DPA |
| Object storage | Supabase Storage | India (Mumbai) | Photos, PDFs, avatars | Existing Supabase contract |
| Auth | Supabase Auth | India | Email, phone, session data | (same) |
| Realtime | Supabase Realtime | India | Channel messages | (same) |
| Search (later) | Meilisearch cloud | EU or self-host | Denormalised catalogue only | DPA |
| LLM (Concierge) | To be selected — OpenAI / Anthropic / Google | US / EU | Context block per Phase 6 §6.5 | DPA, no-training clause, no-retention where possible |
| Payments PDFs | (server-rendered) | — | — | — |
| Wearables | Apple Health, Google Fit, Whoop, Oura (Phase 2) | Various | Per-metric consent | Individual DPAs |
| Calendar | Apple / Google / Outlook via ICS | — | ICS files only, no OAuth at V1 | — |
| Maps | Mapbox or Google Maps | Global | Location coords for map tiles | DPA |
| Weather | Open-Meteo or OpenWeatherMap | Global | Coarse city, no user identity | — |

**Non-goals at V1:** Zoom / video calls, custom CRM, external booking mirrors (Cult.fit connect, ClassPass), physical hardware integrations (sauna dose readers), smart-lock APIs.

---

## 2. Payments — Razorpay

### 2.1 Why

Widest local coverage (UPI, cards, netbanking, wallets), RBI e-mandate support, GST-compliant invoicing hooks, strong developer surface.

### 2.2 Products used

- **Payment Gateway** — one-off charges (drop-in ritual, guest add-ons, Paradiso tabs)
- **Subscriptions with tokens** for recurring plans (Member, Resident, Inner Circle)
- **Smart Collect** — not used at V1
- **Payouts** — not used at V1

### 2.3 Flows

- **Checkout:** server creates order via Razorpay `orders.create`, returns order id to client, client opens Razorpay checkout SDK.
- **Verification:** server-side verification of payment signature on `payment.captured` webhook (Phase 6 §5.1). Only then is the reservation/membership marked confirmed.
- **Mandates:** server creates token via `tokens.create` after member consent to variable-amount mandate. Renewal charges via `subscriptions.charge`.
- **Refunds:** server-initiated, atomic with reservation status change.

### 2.4 GST

- Invoice PDF generated server-side from `invoices` and `invoice_line_items` (Phase 3 §16). Includes GSTIN, HSN/SAC, place-of-supply, invoice number.
- Razorpay's invoicing product is not the source of truth — our system is; Razorpay is only for payment collection.

### 2.5 Failure isolation

- **Razorpay down:** app stays up. Members are informed *"Payments are quiet right now — we've held your slot. We'll try the card in a moment."* Slot-hold TTL extended to 10 min. Manual card-entry as fallback.
- **Webhook delayed:** we do not rely on webhook alone. A poll job checks `payments` with `status = pending` older than 5 min via `payments.fetch`.

### 2.6 Testing

- Razorpay test keys in staging with test cards.
- Contract tests against Razorpay API weekly.

---

## 3. Messaging — WhatsApp BSP

### 3.1 Choice criteria

- Meta BSP approval status
- Template approval turnaround
- Media support (rich cards with buttons)
- Number pooling and quality-score handling
- Cost per template category
- Local support (India)

### 3.2 Candidates

- **Gupshup** — mature, wide template support, Bengaluru HQ
- **AiSensy** — startup-friendly, Delhi HQ, competitive pricing

Decision by end of Phase 13 planning. Contract is BSP-agnostic — sends and receives go through an adapter interface.

### 3.3 Template inventory (V1)

- `pre_arrival_note` — 24h before ritual
- `pre_arrival_reminder` — 2h before ritual
- `ritual_confirmed`
- `class_confirmed`
- `waitlist_offer`
- `payment_failed_soft`
- `plan_renewal_notice`
- `plan_renewed`
- `guest_pass_issued` (to member) / `guest_pass_received` (to guest)
- `milestone_congrats`
- `concierge_whisper` (with dynamic body — must be pre-approved as a variable template)
- `safety_ops_page` — to on-call

Templates are versioned; a new version is submitted to Meta before shipping; the old version continues until deprecation.

### 3.4 Session messaging

- Within a 24h session window (member last inbound), free-form messages allowed
- Outside that window, only approved templates
- Session windows tracked in Postgres; the app never assumes a window is open

### 3.5 Quality score

- Sanctuary's number quality score is tracked weekly
- If quality dips below "High", low-priority whispers are throttled and safety-critical messages take priority
- Members opting out is recorded and honoured immediately (opt-out lives in `notification_preferences`)

---

## 4. Email — Resend

### 4.1 Use

- Magic-link sign-in
- Invoice attachments
- Renewal reminders (parallel to WhatsApp; email is more archival)
- Monthly member letter (opt-in newsletter, signed by Rohan)
- Ops alerts and safety pages to internal accounts

### 4.2 Deliverability

- Custom sending domain: `mail.sanctuary.playhaus.club`
- SPF, DKIM, DMARC configured before send
- Bounce and complaint handling via webhook (Phase 6 §5.3)
- Suppression list respected across all templates

### 4.3 Fallback

If Resend is unavailable, magic-link emails fall over to Amazon SES (secondary sending domain warmed).

---

## 5. Analytics — PostHog

### 5.1 Why one tool

Product analytics + feature flags + session replay + surveys in one platform, single source of truth, single SDK.

### 5.2 What we track

Only what Phase 4 flows define (`analytics_events` taxonomy). Never health, payment amounts, or Concierge conversation content.

### 5.3 Session replay

- Enabled for member web with strict PII masking (all input fields, all `data-mask` elements, all conversation text redacted)
- Rate-limited to 10% of sessions
- 30-day retention
- Disabled on any page that shows health data

### 5.4 Consent

- Product-improvement analytics is bundled into Necessary consent (Phase 7 §6.1) — not opt-in.
- Session replay requires explicit opt-in during onboarding (default off).

---

## 6. Error tracking — Sentry

- Server-side errors and client crashes
- Source maps uploaded on every deploy
- PII scrubbing: no `email`, `phone`, `address`, `card_last4`, `member_id_in_url` in breadcrumbs
- Auto-linked to GitHub issues; ownership per code path
- Retention: 30 days

---

## 7. Wearable & metric integrations

### 7.1 V1 (manual)

- Members enter sleep, energy, mood, soreness via self-report (`self_reports`)
- Optional weight, water intake, step count from Apple Health / Google Fit via export upload (CSV) — batch, not real-time

### 7.2 V2 (post-launch)

- Apple HealthKit + Google Fit read-only for sleep, HRV, steps, workouts
- Whoop OAuth for recovery score and strain
- Oura ring for sleep and readiness

### 7.3 Data model

- All incoming metrics normalised into `wellness_metrics` (Phase 3 §11)
- Provenance stamped on every row (`source`, `device_model`, `imported_at`)
- Members can disconnect any provider at any time; a disconnect removes future syncs and offers a one-tap purge of past data

### 7.4 Recovery Index

- Recovery Index inputs weight wearable metrics equally with self-reports at V1
- If a member has no wearable connected, Recovery Index runs entirely on self-report + attendance load

---

## 8. Calendar, maps, weather

### 8.1 Calendar

- V1: reservations offer a downloadable `.ics` (RFC 5545) with the venue, time, host coach, and prep notes
- V2: OAuth to Google Calendar for full two-way sync

### 8.2 Maps

- Mapbox preferred (higher design control, better dark tiles)
- Google Maps fallback for last-mile directions in the app-side "How to reach us"
- Location coords loaded via server; never expose Mapbox key client-side (proxy via edge function or use scoped token)

### 8.3 Weather

- Open-Meteo (free, no key) as primary
- Cached at CDN for 15 minutes per city
- Used only for ambient copy on Arrival ("Delhi · 22°C · dry")

---

## 9. CMS

### 9.1 Choice

- **Sanity** (Studio + hosted content lake) or **Payload** (self-hosted, TypeScript-native)
- Decision by end of Phase 13 based on team ergonomics; both are TypeScript-native

### 9.2 What lives in the CMS

- Marketing site copy
- Ritual descriptions, prepare notes, contraindication copy
- Class descriptions
- Coach bios
- Programming calendar (special events, workshops)
- Legal (T&Cs, privacy policy) with version history

### 9.3 What does not

- Anything transactional (schedules, availability, prices) — that lives in Postgres
- Anything personalised (names, notes to member) — inline in code + i18n dictionary

### 9.4 Preview & publishing

- Drafts previewable on staging
- Publishing to prod requires editor role + review
- Legal documents require legal counsel sign-off before publish

---

## 10. Design & product tooling

| Purpose | Tool |
|---|---|
| Design source of truth | Figma (variables mirroring `packages/tokens`) |
| Design handoff | Figma Dev Mode |
| Roadmap & tasks | Linear |
| Docs | Notion (customer-visible: this doc set stays in repo) |
| PRD ↔ design cross-linking | Notion + Figma links |
| Slack | Team comms + ops on-call pager |
| PagerDuty (or Better Stack Uptime) | On-call rotations |

---

## 11. Failure isolation & vendor exit

### 11.1 Isolation principles

- Every third-party dependency wrapped by an internal adapter interface
- Adapters expose narrow, product-shaped methods (e.g. `messaging.sendPreArrivalNote(member, reservation)`), not vendor-shaped ones
- Retry, timeout, and circuit-breaker at the adapter layer
- Adapter tests + contract tests catch drift

### 11.2 Exit plan per vendor

| Vendor | Exit trigger | Exit path | Migration time |
|---|---|---|---|
| Razorpay | Price hike > 20%, quality issues, regulatory ban | Migrate to Cashfree or Juspay (both India-native) | 6 weeks |
| WhatsApp BSP | Approval revoked, price change, quality issues | Swap BSPs within 2 weeks (Meta relationship persists) | 2 weeks |
| Resend | Deliverability drop | Warm SES/Postmark to primary | 1 week |
| PostHog | Cost or data-residency concern | Self-host PostHog OR migrate to Mixpanel | 8 weeks |
| Sentry | Cost | GlitchTip (self-host) | 4 weeks |
| CMS | Vendor lock-in concern | Export → Payload | 4 weeks |
| LLM provider | Contract change, safety regression | Failover to secondary already wired | < 24h |

### 11.3 No lock-in on data

- All PII exportable at any time via a scripted extract
- Object storage compatible with S3 API (portable)
- Postgres via `pg_dump` — nothing proprietary in schema

---

## 12. Data-processing register (DPDP §11 requirement)

Living register maintained at `docs/registers/data-processing.md` (to be created in Phase 15) that records for every vendor:
- Categories of data
- Purposes of processing
- Legal basis
- Retention period
- Sub-processors
- Location of processing
- Contract references

Reviewed quarterly by the DPO.

---

## 13. Review checklist

- [ ] Vendor list is complete for V1
- [ ] Payments choice (Razorpay) and its role as *collection* — not the invoice source of truth — is agreed
- [ ] WhatsApp BSP decision path and template inventory are right
- [ ] Analytics data-shared list explicitly excludes health, payments, Concierge conversation content
- [ ] Wearable roadmap (manual V1, HealthKit/Whoop/Oura V2) matches business plan
- [ ] Adapter-interface + exit-plan pattern is committed
- [ ] DPDP data-processing register commitment accepted
