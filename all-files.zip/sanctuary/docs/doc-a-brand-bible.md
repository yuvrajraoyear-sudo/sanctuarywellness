# Doc A — Brand Bible
**Play Haus · Sanctuary · Paradiso · HYROX · Play Haus Sports**
**Version:** 1.0
**Owner:** Play Haus brand & product leadership

This document is the source of truth for how Sanctuary looks, sounds, and feels. Every screen, string, notification, poster, invoice, and welcome note is judged against it. When a decision is contested, the Brand Bible wins over the PRD.

---

## 1. Brand Architecture

```
PLAY HAUS
The parent lifestyle brand.
Move. Recover. Connect.

├── SANCTUARY          Recovery & Wellness Club
├── PARADISO           Café & Social Kitchen
├── HYROX              Official Training Centre
└── PLAY HAUS SPORTS   Football · Pickleball · Kids · Events
```

**Rule:** in the Sanctuary app, "Play Haus" appears only in the footer and legal surfaces. Sanctuary is the front-facing identity. In the future super-app, Play Haus becomes the top-level shell and Sanctuary is one destination inside it.

**Tagline hierarchy:**
- Play Haus tagline: *Move. Recover. Connect.*
- Sanctuary sub-tagline: *A place to feel yourself again.*

## 2. Brand Purpose

**Purpose.** To help people live longer, calmer, stronger lives — in a place that feels like it was built for them.

**Mission.** To become India's most trusted destination for recovery, longevity, and human performance, by pairing world-class protocols with genuine hospitality.

**Vision.** A country where recovery is understood as a discipline, not a luxury — and where Sanctuary is where that culture began.

## 3. Emotional Principles

These are the feelings a member should leave with, in order of importance:

1. **Known** — "They remembered."
2. **Restored** — "I feel better than when I arrived."
3. **Respected** — "Nothing was rushed, nothing was pushed."
4. **In good hands** — "Someone competent is looking after me."
5. **Belonging** — "This is my place."

If a feature can't produce any of these, it should be reconsidered.

## 4. Voice & Tone

**Voice adjectives (always true):**
- Warm
- Quiet
- Precise
- Confident
- Grown-up

**Voice adjectives (never true):**
- Hype-y
- Salesy
- Chirpy
- Emoji-laden
- Slangy
- Motivational-poster-y

**Tone examples**

| Situation | ❌ Wrong | ✅ Right |
|---|---|---|
| Booking confirmed | "🔥 You're locked in! Let's crush it!" | "Sunday, 8:30 AM. Sauna suite 2 is yours." |
| Missed a session | "You skipped again 😢" | "You missed Tuesday's Recovery Reset. If it's a bad week, we can move things later this week." |
| Renewal reminder | "URGENT: Renew now to keep your streak!" | "Your membership renews on the 24th. Nothing to do — we'll take care of it." |
| Empty state | "No bookings yet 🥲" | "Nothing on the calendar yet. Shall we start with a Recovery Reset?" |
| Error | "Oops! Something went wrong." | "Something didn't go through. We've noted it. Try once more?" |

**Grammatical choices:**
- Use full stops, not exclamation marks. One exclamation mark per app, if any.
- Second person, singular ("you"), never "you guys."
- Avoid gerunds where a noun is warmer ("Recovery" over "Recovering").
- Capitalise ritual and service names (Recovery Reset, Ice Bath, Founder's Club). Everything else is sentence case.
- Numerals in copy: use words for 1–9, numerals for 10+, unless it's a time or duration.
- No emoji in system copy. Handwritten notes from staff or founder may use one sparingly.

**Words we use:**
Ritual · Reset · Reserve · Whisper · Note · Signature · Steady · Restore · Balance · Presence · Journey · Care

**Words we avoid:**
Crush · Beast · Grind · Sweat · Burn · Blast · Ultimate · Insane · Level up · Gains · Rockstar · Hustle · Sesh · Buddy · Ninja

## 4A. Logos & Marks

The identity system uses two authoritative marks provided in `preview/brand/`.

### 4A.1 Play Haus master mark

An italic sans wordmark **PLAY / HAUS** set in two lines, paired with a stylised **shark-fin "P"** monogram on the left. This is the parent brand mark.

- File: `preview/brand/playhaus-master.jpeg`
- Usage: parent brand contexts, group communications, sports and events, physical signage at the parent level.
- Rule: never re-typeset. Only use the supplied artwork.

### 4A.2 Sanctuary lockup (primary)

A serif wordmark **SANCTUARY** with a candle-flame ligature replacing the **N**, a hairline divider beneath, **WELLNESS** in tracked caps, and an endorsement line **BY PLAY HAUS** rendered in the italic Play Haus wordmark.

- File: `preview/brand/sanctuary-lockup.png`
- Usage: this is the front-facing mark inside the Sanctuary app and all Sanctuary-owned surfaces.
- Rule: the "by Play Haus" endorsement is part of the lockup and cannot be removed at member surfaces. It may be dropped only in physical monogram treatments (embossed towels, cutlery, letterhead) at the request of Ops.

### 4A.3 Colour treatment

The mark is delivered black-on-transparent. Two authorised colour treatments:

- **Ink on sand** — `--ink` (#161311) on `--sand-50` / `--sand-100`. Default in-app on light surfaces (topbar).
- **Sand on ink** — `--sand-50` (#faf7f2) on `--bg-night` (#14100e). Used on sign-in, loading, and the Annual Wellness card. Achieved by inverting the artwork or requesting the light-on-dark master from brand ops.

Do not tint the mark maroon, sage, sunset, or dawn. Do not add gradients, glow, or drop-shadow.

### 4A.4 Clear space & minimum size

- Clear space around the full lockup: the height of the "S" cap on all four sides.
- Minimum sizes:
  - Digital: **120 px wide** for the full lockup; **80 px wide** if the endorsement is stacked below.
  - Print: **28 mm wide** for the full lockup.

Below these sizes, use the **flame monogram** (see §4A.6) instead of the wordmark.

### 4A.5 Placement rules inside the app

| Surface | Mark | Size | Position |
|---|---|---|---|
| Sign-in | Full lockup, light | ~220 px wide | Top-left of content column |
| Loading | Full lockup, light | ~200 px wide | Centered, above name greeting |
| Topbar (Arrival, all logged-in screens) | Full lockup, ink | 26 px tall | Left, aligned to safe area |
| Annual Wellness card | Full lockup, light | 140 px wide | Bottom-right, opacity .6 |
| Email header | Full lockup, ink | 180 px wide | Top-left, 24 px padding |
| WhatsApp templated messages | Text only — do not embed the mark | — | — |
| Physical letterhead | Full lockup, ink, foil-stamp permitted | 42 mm wide | Top-centre |

### 4A.6 Monogram (favicon, app icon, small surfaces)

For favicons, PWA app icons, avatar dots, and any surface below the minimum size, use the **candle-flame glyph** from the ligature, isolated. It reads as a single stylised flame between two vertical strokes.

- Provided sizes: 32, 64, 128, 256, 512, 1024 (to be exported from source).
- Background: `--ink` on `--sand-50` or reversed. Never on a photographic image.
- iOS app icon uses the standard 22 px inner-corner mask; do not manually round the artwork.

### 4A.7 Common misuses (forbidden)

- Do not stretch, skew, or rotate.
- Do not re-typeset "Sanctuary" in any other typeface.
- Do not replace the flame ligature with a plain "N".
- Do not remove the "WELLNESS" divider band from the primary lockup on member surfaces.
- Do not pair with unrelated icons or badges directly abutting the lockup.
- Do not place on busy photographic backgrounds without a scrim.

### 4A.8 File inventory (to be produced by brand ops)

Currently provided in `preview/brand/`:
- `sanctuary-lockup.png` — full lockup, black on transparent, raster
- `playhaus-master.jpeg` — Play Haus master mark, black on white, raster

Requested for production (Phase 6 hand-off):
- `sanctuary-lockup-dark.svg` — vector, black
- `sanctuary-lockup-light.svg` — vector, warm-white
- `sanctuary-monogram.svg` — flame glyph, vector
- `sanctuary-favicon.ico` and PWA icon set (16→1024)
- `playhaus-master.svg` — vector

## 5. Design Philosophy

### 5.1 First principles
- **Subtractive premium.** Remove until only what's needed remains.
- **Whitespace is the material.** Whitespace is not empty; it's what makes premium visible.
- **Typography is the brand.** Get the type right and 80% of the brand is right.
- **Motion is choreography.** Every animation eases in, eases out, and lasts under 400ms.
- **Photography is the emotion.** Real light, real people, real objects.

### 5.2 Colour system

| Token | Name | Hex | Use |
|---|---|---|---|
| `--ink` | Ink | `#161311` | Primary text, buttons |
| `--ink-2` | Softened Ink | `#3a3530` | Secondary text |
| `--sand-50` | Warm White | `#faf7f2` | Canvas / background |
| `--sand-100` | Bone | `#f3ede2` | Surfaces |
| `--sand-200` | Sand | `#e7dccb` | Cards, dividers |
| `--stone-400` | Stone | `#a89a86` | Muted text, icons |
| `--stone-600` | Dusk Stone | `#6c6055` | Body copy alt |
| `--maroon-500` | Muted Maroon | `#7a2f2b` | Accents, key CTA (used sparingly) |
| `--maroon-700` | Deep Maroon | `#4d1e1c` | Hover state on accent |
| `--sage-400` | Sage | `#8a9a82` | Positive / recovery |
| `--sunset-400` | Sunset | `#c88a5c` | Warm highlights only |

**Never used:** pure black, pure white, saturated blues/purples, neon greens, gradients across more than two of the tokens above.

**Palette rules:**
- 60% Warm White / Bone
- 25% Sand / Stone
- 10% Ink
- 5% Muted Maroon or Sage (accent — one accent per screen, ideally)

### 5.3 Typography

- **Display:** *Fraunces* (variable, opsz 24–72), weights 400–700. Used for hero moments, ritual titles, section heads.
- **Body:** *Inter*, weights 400 / 500 / 600. Used for everything else.
- **Numerals for data:** *Fraunces* tabular figures for scores and totals; *Inter* for interface numbers.

Type scale (mobile / desktop):
- Hero: 40 / 64 (Fraunces 600)
- H1: 30 / 44 (Fraunces 600)
- H2: 22 / 30 (Fraunces 600)
- H3: 17 / 20 (Inter 600)
- Body: 15 / 16 (Inter 400)
- Caption: 13 / 13 (Inter 500, tracked +0.02em, stone-600)

**Rules:**
- Never mix more than two typefaces.
- Line height 1.15 for display, 1.5 for body.
- Tracking is tighter on display (-0.02em), normal on body.
- All caps only for one-word labels (e.g. "MEMBER") — never for sentences.

### 5.4 Spacing & radius

- 4-point grid.
- Baseline touch target: 44px.
- Radius: 14px (cards), 999px (chips, buttons), 22px (modals), 10px (inputs).
- Shadows are almost invisible — use them for elevation, never for drama.

### 5.5 Imagery

- Warm, natural light. Golden hour, morning haze.
- Human skin, real breath. No stock-hero grins.
- Objects: wood, linen, stone, ceramic. Never plastic, chrome, or neon.
- People shown mid-ritual — eyes closed, mid-breath, mid-stretch. Never staring at the camera.
- No motion blur, no lens flares, no filters that scream Instagram.
- Reference world: Aman resorts photography, Kinfolk, Cereal magazine, Loewe campaigns, Aesop's product world.

### 5.6 Iconography

- Line icons, 1.5px stroke, rounded caps.
- Same visual weight as body text.
- Never coloured — inherit `currentColor`.

### 5.7 Motion

- Duration: 200–400ms typical, 600ms for the Arrival page load choreography.
- Easing: `cubic-bezier(0.22, 1, 0.36, 1)` for entrances (an easeOutExpo variant).
- Micro-motion on interaction (scale 0.98 on press, subtle shift on hover).
- `prefers-reduced-motion` respected — swap motion for cross-fade.

## 6. Copywriting Guidelines

### 6.1 Structural rules
- **Under 12 words per line** on cards and above-the-fold copy.
- **Never lead with a verb + exclamation** ("Book now!"). Lead with the object of desire ("Sauna suite 2 is open at 8 AM.").
- **Every notification names a person or place**, not a status ("Ritika added a note to your file" beats "New note received").
- **Numbers earn their space.** If a number is on-screen, it must be readable and it must matter.

### 6.2 Common patterns

**Booking confirmation:**
> Sunday, 8:30 AM.
> Sauna suite 2 is yours.
> Ritika will meet you at reception.

**Renewal notice:**
> Your membership renews on the 24th of this month.
> Nothing to do — we'll take care of it.
> Any changes? A quick word here.

**Concierge whisper:**
> You've had three intense sessions this week.
> Ritika has prepared a Recovery Reset for tomorrow evening.
> Shall I hold it for you?

**Milestone (Timeline):**
> One hundred hours of recovery.
> A quiet milestone. Thank you for being here.

**Empty state:**
> Nothing yet on the calendar.
> When you're ready, we can begin with a Recovery Reset.

## 7. Hospitality Standards

Software cannot be more hospitable than the club. But it must not be less.

**Standards the app must honour:**

1. **First name always, last name never in-app.** ("Good evening, Yuvraj." Never "Mr. Singh.") Reserved formality is for physical letters and legal surfaces only.
2. **No push before 7 AM or after 10 PM,** ever, unless the member changed the DND window themselves.
3. **Never surprise the member with a bill.** Every charge preceded by a soft reminder.
4. **Missed sessions are met with concern, not scolding.** "Everything alright?" not "You lost your streak."
5. **Birthdays are recognised, quietly**, according to Signature preference (celebrate / quietly / not at all).
6. **On the second visit, the app should already feel like it knows the member** (via Signature).
7. **Cancellations are frictionless** — one tap, no guilt copy, policy stated once, not repeated.
8. **Waitlists are honoured within 15 minutes** of a spot opening. No public "you're #7."
9. **Trainer names appear on Concierge recommendations** when a trainer authored the protocol.
10. **Refunds and disputes go through a human,** not a chatbot. AI can assist the staff, not the member, in these flows.

## 8. Photography & Content Direction

**Sanctuary shoot brief (for reference photography):**
- 6–8 AM or 4–6 PM only.
- Locations: sauna interior, ice bath, mobility studio, breath studio, reception.
- People: real members (with consent), diverse ages, calm expressions.
- No brand logos in-frame.
- Colour grade: warm shadows, low contrast, film-like grain.

**Content pillars for social + email:**
1. Protocol education (why contrast therapy works)
2. Member stories (with consent, quiet, unposed)
3. Trainer profiles (craft, philosophy)
4. Rituals of the season
5. Behind-the-scenes of the club

## 9. Legal, Privacy, Trust

**Trust copy patterns:**
- Health metrics: "Only your trainer and you will see this."
- Notifications: "You can adjust when we reach out in Settings → Notifications."
- Data export: "Your data belongs to you. Download it any time."
- Cancellation: "Cancel any time. We'll refund what's fair."

**Never:** dark patterns, forced upsells, hidden auto-renewal, confirm-shame ("No thanks, I don't want to feel better").

## 10. Governance

**Copy review gate.** Every new string on a member-facing surface passes a two-person copy review before release. One reviewer is not from engineering.

**Brand review cadence.** Monthly, until launch. Quarterly after.

**Version.** Any change to the tokens (colour, type, radius, motion) requires a bumped version and a changelog entry.

---

## Appendix — Quick Card

Print this and put it above the design/product team's desks.

> **Sanctuary is a private club, not an app.**
> - Whisper, never shout.
> - One recommendation beats ten cards.
> - Status over points.
> - Known, not tracked.
> - The AI advises, the human decides.
> - When in doubt: warmer, quieter, fewer words.
