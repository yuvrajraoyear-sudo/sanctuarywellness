# Phase 1 — Product Requirements Document
**Project:** Sanctuary Wellness (a Play Haus experience)
**Version:** 1.1 — Hospitality-first revision
**Owner:** Play Haus / Sanctuary product team
**Status:** Draft for review

> **Read alongside:** Brand Bible · Member Experience Blueprint · Service Playbook.
> The PRD tells the software team *what* to build. Those three documents tell them *how it should feel*. All four are required to build Sanctuary correctly.

---

## 0. Brand Hierarchy

**PLAY HAUS** — the parent lifestyle brand. *Move. Recover. Connect.*

Under Play Haus:

- **Sanctuary** — Recovery & Wellness Club (the subject of this PRD)
- **Paradiso** — Café & Social Kitchen
- **HYROX** — Official Training Centre
- **Play Haus Sports** — Football, Pickleball, Events, Kids

Sanctuary's app in V1 is members-only for Sanctuary. Architecturally it is the first module of the Play Haus super-app; nothing built here should have to be undone to add Sports, Paradiso ordering at scale, or Kids in Phase 2/3.

---

## 1. Vision

> **Sanctuary exists to become Delhi's most trusted destination for recovery, longevity, and human performance. We do not sell access to equipment — we provide an environment where members consistently feel healthier, calmer, and stronger. Every digital interaction must reinforce that in-person experience, never compete with it.**

This vision is the tie-breaker for every product decision. If a feature makes the app louder, busier, or more transactional, it fails this test even if it's technically sound.

### What this means concretely

- The app **whispers**. Nothing shouts.
- The app is **subordinate to the physical experience**. It exists to reduce friction around visits, not to become the visit.
- The app is **hospitality software**, not fitness software. Its closest analogues are Aman, Four Seasons private-guest apps, and Apple's concierge experiences — not Cult, not Whoop, not a gym-management SaaS.

## 2. Success Metrics

**North-star:** Verified in-club wellness sessions per active member per month.
Bookings without check-in don't count. Consumption is the point, not conversion.

**Business KPIs (12-month targets, first location):**
- Active member base ≥ 400
- MRR growth ≥ 8% MoM in months 1–6
- Monthly churn ≤ 3.0% (revised down from v1.0 — luxury retention is the moat)
- Booking utilization ≥ 55% at peak
- Founder's Club NPS ≥ 70

**Product KPIs:**
- 7-day active member rate ≥ 60%
- Median time to complete a *ritual* booking ≤ 25 seconds
- Concierge AI weekly engagement ≥ 40%
- Ritual completion rate (booked → checked-in) ≥ 85%
- Member Signature completeness ≥ 80% within 30 days of joining

## 3. Personas

| Persona | Emotional job | Rational job |
|---|---|---|
| **The Executive** (40) | Feel in control amid chaos | Predictable recovery slots, discreet arrival |
| **The HYROX Athlete** (32) | Feel prepared, not fragile | Programmed recovery before events |
| **The Runner** (28) | Feel resilient | Mobility, breathwork, recovery scoring |
| **The Rehab Member** (48) | Feel safe, dignified | Trainer supervision, gentle programming |
| **The Wellness Seeker** (34) | Feel calm | Breathwork, sauna, mindfulness, community |
| **The Founder's Club Member** | Feel known | Anticipated preferences, private routing |

The emotional job is the design brief. The rational job is the feature list. Design for the first, ship the second.

## 4. In / Out of Scope (V1)

### In scope
- Sanctuary member authentication (email OTP + Google; phone OTP later)
- **Ritual-first** dashboard (see 6.2)
- Booking engine for recovery + movement services + rituals (6.3)
- Membership: view, renew, freeze, pause, guest passes, referrals, invoices (6.4)
- **Sanctuary Concierge** (AI + human-in-the-loop) (6.5)
- **Recovery Index** with transparent inputs and narrative (6.6)
- Progress & **Member Timeline** (6.7)
- Community: challenges, badges, opt-in leaderboards (6.8)
- **Paradiso café** — menu, order-ahead, member pricing, ritual-linked suggestions (6.9)
- **Status ladder** (Explorer → Member → Resident → Inner Circle → Founder) — replaces points-only rewards (6.10)
- **Member Signature** (personal preferences held on file) (6.11)
- Notifications: in-app, push, email, WhatsApp (6.12)
- Staff panel (managers, trainers) (6.13)
- Owner dashboard (6.14)
- Support / concierge escalation (6.15)
- Payments (Razorpay: memberships, packs, café, add-ons) (6.16)

### Out of scope (V1)
- Football / pickleball / kids booking (Phase 2)
- Public membership sales funnel (managed off-app in V1)
- Retail e-commerce beyond café pickup
- Native iOS / Android — V1 is a premium PWA
- Wearable integrations (Phase 2 — Apple Health, Whoop, Garmin, Oura)
- Video-on-demand programs (Phase 3 — Digital Coaching)

## 5. Product Principles

1. **Whisper, never shout.** No red badges, no marketing banners, no growth-hack UI on core surfaces.
2. **One recommendation beats ten cards.** Every screen has a single primary action.
3. **Ritual over booking.** Members don't book slots; they enter a ritual. The slot is a mechanical detail.
4. **Concierge, not chatbot.** Sanctuary speaks first, with knowledge of the member; it doesn't wait to be prompted.
5. **Status over points.** Belonging is the reward. Points may exist internally but never as the vocabulary.
6. **Known, not tracked.** Preferences are honoured, not surveilled. Members opt in to health data.
7. **The AI advises, the human decides.** Every AI recommendation can carry a trainer's approval or attribution.
8. **Every feature must survive Phase 3.** Multi-vertical super-app compatibility is table stakes.

## 6. Feature Requirements

### 6.1 Authentication
- Email OTP (primary), Google sign-in (secondary), phone OTP (Phase 1.5)
- Members are staff-provisioned. Non-members hitting the login screen see an elegant "Sanctuary is a private club — request an introduction" card, not a signup form.
- Session persistence 90 days, biometric unlock on supported devices
- Roles: member / trainer / manager / admin / owner

### 6.2 Dashboard — "The Arrival"

The dashboard is styled and named internally as **The Arrival**. It replaces the multi-card gym dashboard with a single, calm, cinematic surface.

**Above the fold (single screen, mobile-first):**

```
Good Evening, Yuvraj.
Welcome back.

You've recovered well since Tuesday.

Today's ritual
Evening Wind Down · ~42 minutes
  15 min Sauna
  3 min Ice Bath
  Turmeric Latte at Paradiso

[ Begin ritual ]        [ Prefer something else ]
```

**Below the fold (revealed on gentle scroll, never above the fold):**
- Upcoming reservations (max 2)
- Recovery Index summary (one line: *"Steady. Sleep down slightly this week."*)
- Latest whisper from the Concierge (one line, dismissible)
- Weather + hydration nudge (single, footer-tone)
- Member Timeline highlights (only when there's a new milestone)

**Rules:**
- No red dots, no counters on the tab bar unless there is a booking within 60 minutes.
- The Arrival re-computes at time-of-day boundaries: morning (5–11), midday (11–16), evening (16–22), late (22–5). Each carries different visuals and copy.
- The single ritual card is the *only* primary action above the fold. Everything else is discovery.

### 6.3 Booking as Ritual

Members do not primarily "book a sauna." They enter one of six **Rituals** (extensible):

| Ritual | Sequence (example) | Typical duration |
|---|---|---|
| **Morning Reset** | Breathwork → Mobility → Coffee at Paradiso | 45 min |
| **Recovery Reset** | Sauna → Ice Bath → Contrast → Herbal Tea | 50 min |
| **Evening Wind Down** | Steam → Stretch → Turmeric Latte | 40 min |
| **Weekend Recharge** | Yoga → Sauna → Ice Bath → Nutrition Bowl | 90 min |
| **Athlete Prep** (HYROX / event) | Mobility → Contrast → Coach note | 60 min |
| **Post-Event Restore** | Ice Bath → Breathwork → Stretch → Recovery Smoothie | 55 min |

Each Ritual is a **composed booking**: one flow, one confirmation, one arrival. Behind the scenes it holds N slot reservations; to the member it is one experience.

Individual service booking (Ice Bath, Sauna, etc.) is still available as **À la carte**, one tap deeper. This preserves flexibility while making rituals the default.

**Per booking (ritual or à la carte):**
- Capacity, waitlist auto-promote with 15-minute confirm
- Cancellation policy: free ≥ 4h; late = 1 credit; no-show = 1 credit + strike
- Reschedule once per booking, ≥ 4h prior
- Preparation notes (contraindications, hydration, arrival time)
- Arrival reminder push 60 min prior; WhatsApp 30 min prior
- Post-ritual micro-feedback (one-tap emotion + optional note) — feeds Recovery Index & Concierge

### 6.4 Membership
- View current plan, benefits, renewal, remaining credits
- Renew / upgrade / downgrade (proration handled)
- **Freeze** — 30 days/year self-serve, longer requires staff
- **Pause** — billing halted, access revoked, resumable
- Billing history, GST invoices
- Guest passes (issue, expire, redeem)
- Referral credits ledger
- **Status ladder** display (Explorer → Member → Resident → Inner Circle → Founder — see 6.10)

### 6.5 Sanctuary Concierge

This is not a chatbot. This is not "How can I help?" It is a **concierge that speaks first**, with awareness of the member's recent behaviour, upcoming plans, and stated preferences.

**Voice examples (must pass copy review):**

- *"Looks like you've had three intense sessions this week. Ritika has prepared a Recovery Reset for tomorrow evening — shall I hold it for you?"*
- *"Your membership includes one guest pass this month. Friday evening still has availability if you'd like to bring someone."*
- *"You mentioned sleep has been light. A 12-minute breathwork session tonight before bed tends to help. It's available at 21:30."*
- *"You've missed contrast therapy for 10 days. Nothing wrong — just a whisper."*

**How it works:**
- Signals: attendance, booking mix, self-reported mood/sleep/hydration/stress, Recovery Index, upcoming schedule, Member Signature preferences.
- Outputs: structured recommendation objects with `title`, `rationale`, `action`, `optional_trainer_attribution`. Rendered as short prose in-app.
- **Human-in-the-loop:** every recommendation can be tagged with a trainer's name if a trainer reviewed or authored the underlying protocol ("Ritika recommends…"). AI drafts; trainer approves; member sees the trainer.
- **Safety guardrails:** no medical diagnosis, no medication advice; injury / mental-health red flags route to a human-help card immediately.
- **Cadence:** at most one proactive Concierge message per day. Members can open a Concierge tab at any time; even then the surface opens with a contextual observation, not a blinking cursor.
- Every AI response logged with model version, prompt hash, member consent state.

### 6.6 Recovery Index

Not a mystery number. A composite with a **narrative**.

**Inputs (each shown to the member, transparent weights):**
- Sleep (self-reported, wearable when available)
- Stress (weekly self-report + variance)
- Training load (recent session intensity mix)
- Mobility (self-rated flexibility + mobility-class attendance)
- Recovery sessions (frequency, recency)
- Hydration (self-reported)
- Mood (weekly self-report)

**Presentation:**
- One-line summary: *"Steady. Sleep dipped Tuesday–Thursday."*
- Trend arrow across 7 / 30 days
- Tap for the breakdown: each input with its own line and delta
- Concierge references the Index in recommendations ("Your training load is elevated; a Recovery Reset would balance the week.")

**Explicitly not:** a single opaque number labelled "your recovery is 72."

### 6.7 Progress & Member Timeline

**Progress:**
- Metrics (self-reported, optional): weight, body fat %, muscle mass, mood, stress, sleep
- Derived: attendance, session mix, wellness score, mobility score
- Trends: 7 / 30 / 90 day
- Export: PDF + JSON

**Member Timeline** — a cinematic, single-column narrative of the member's journey:

```
Joined Sanctuary — 12 Feb
First Recovery Reset — 15 Feb
10th visit — 04 Mar
Completed 30-Day Mobility Challenge — 14 Apr
Elevated to Resident — 01 May
100 Recovery Hours — 22 Jun
Founder Dinner invitation — 12 Jul
Annual Wellness Review scheduled — 08 Feb (next year)
```

Milestones auto-emit push + WhatsApp notes styled as private notes, not marketing.

### 6.8 Community
- One featured challenge per month, always tied to wellness (Recovery Streak, 30-Day Mobility, Breath 21). No leaderboard-only vanity events.
- Opt-in leaderboards (display name only, no PII)
- Achievement badges (attendance, streaks, milestones, ritual variety)
- Members-only events calendar (workshops, socials, Founder dinners)
- No member-to-member DMs in V1 — reduces moderation burden and keeps the tone clean

### 6.9 Paradiso Café
- Menu with member pricing shown alongside guest pricing
- Nutrition tags (protein, kcal, dietary flags)
- Order ahead with pickup window
- Purchase history + reorder
- **Ritual-linked suggestions:** every ritual ends with a Paradiso item recommendation (turmeric latte after sauna, protein bowl after HYROX prep). One tap adds it to the ritual.
- Café bill can be included on the member's monthly statement (opt-in)

### 6.10 Status Ladder (replaces points-first rewards)

The vocabulary is **status**, not points. Members progress through:

| Tier | Reached by | Signal |
|---|---|---|
| **Explorer** | Joined | Learning the club |
| **Member** | 30 days active + 12 sessions | Fully integrated |
| **Resident** | 90 days + consistent attendance | Recognised regular |
| **Inner Circle** | 180 days + high engagement, referrals | Priority booking, extra guest passes |
| **Founder** | Invitation only | Founding cohort; permanent recognition; Founder dinners; anniversary gifts |

**Rules:**
- No public leaderboard of tiers.
- Progression is celebrated privately (Timeline milestone + a handwritten-style note from the founder for Resident+).
- Points exist as an internal accounting substrate for challenges and referral credits — but the member vocabulary is status, tenure, and belonging.

### 6.11 Member Signature — Preferences on File

A short, curated set of preferences the club uses to know the member without asking twice:

- Favourite locker number
- Preferred sauna temperature
- Preferred herbal tea
- Preferred trainer
- Preferred time slot
- Preferred recovery music / soundscape
- Coffee preference (Paradiso)
- Birthday & anniversary preferences (celebrate quietly / not at all / with a note)
- Contraindications & injuries (private, only visible to trainers & concierge)

Filled during onboarding, editable anytime. Sanctuary staff see a **Member Signature card** on the member's profile at check-in — so the human experience matches the digital one.

### 6.12 Notifications
- Channels: in-app inbox, web push, email (Resend), WhatsApp (BSP TBD)
- Preferences per category, per channel
- Do-not-disturb window (default 22:00–07:00, member-configurable)
- Hard cap: 1 non-transactional push per day. Transactional (booking confirm, reminder within 1h) allowed always.
- Copy tone matches Concierge — private note, not marketing.

### 6.13 Staff Panel
- **Manager:** today's roster, capacity live view, walk-in check-in, member lookup, announcements, refunds
- **Trainer:** own schedule, class rosters, mark attendance, add session notes, approve Concierge recommendations that carry their name
- **Both roles:** view Member Signature at check-in (locker, tea, temp, injuries)
- Tablet-optimised layout; QR check-in as fallback

### 6.14 Owner Dashboard
- Revenue, MRR, ARR, new / churned / net members
- Utilization by service and hour, peak heatmap
- Trainer performance (attendance, ratings, retention)
- CSAT via post-ritual feedback
- Referral funnel
- Membership growth cohorts
- Daily check-ins
- Forecast (linear + seasonal in V1; refined later)
- **Ritual analytics:** which rituals convert, complete, and correlate with retention

### 6.15 Support / Concierge Escalation
- Ticketing categorised (booking, billing, technical, membership, other)
- SLA: replies in under 2 hours during club hours
- WhatsApp escalation
- Contextual FAQ surfaced on the surface the member was on

### 6.16 Payments
- Razorpay only in V1 (UPI, cards, netbanking, wallets)
- Recurring mandates (eNACH / UPI Autopay) for memberships
- Retry ladder for failed renewals (3h, 6h, 12h), then dunning WhatsApp
- GST invoices, TDS handling where applicable
- Refund workflow through staff panel

## 7. Non-Functional Requirements

| Area | Requirement |
|---|---|
| Performance | P95 initial load ≤ 2.5s on 4G; TTI dashboard ≤ 1.5s after auth |
| Availability | 99.9% monthly; maintenance 03:00–05:00 IST |
| Accessibility | WCAG 2.1 AA; keyboard, screen reader, reduced-motion |
| Security | RLS on every table, encryption at rest/in transit, secrets in Vercel env only, audit logs on privileged actions |
| Privacy | GDPR-style principles; explicit consent for health metrics; member export + delete |
| Localisation | English V1; Hindi V1.5 |
| Offline | PWA shell caches Arrival + next 2 bookings for offline read |
| Observability | Structured logs, Sentry, PostHog, payment reconciliation reports |

## 8. Constraints & Assumptions

- Single location at launch (Delhi NCR), multi-location schema-ready behind a flag
- Payments: Razorpay only in V1
- WhatsApp BSP required before launch
- Trainers on tablet, not native app in V1
- All timestamps UTC in DB, IST in UI

## 9. Risks & Mitigations

| Risk | Mitigation |
|---|---|
| App drifts into "gym software" tone | Brand Bible + copy review gate on every string, ritual-first IA |
| Concierge sounds like a chatbot | Voice guidelines in Brand Bible + trainer attribution rule |
| No-shows destroying utilization | Late-cancel credit + strike + transparent policy |
| Overbooking recovery pods | Hard capacity + waitlist + 15-min confirm |
| Payment failures on renewal | Retry + WhatsApp dunning |
| Feature creep from Sports vertical | Firm V1 scope; schema-ready; feature-flagged |
| Founder's Club feels arbitrary | Codified criteria + private celebration ritual, not automated |

## 10. Release Plan

- **M0 — Foundations:** PRD 1.1, Brand Bible, MX Blueprint, Service Playbook, IA, schema (Phases 1–3)
- **M1 — Design:** Flows, wireframes, hi-fi UI (Phases 4–6)
- **M2 — Core build:** Auth, Arrival, booking engine, Rituals, membership viewing (Phases 7–10)
- **M3 — Commerce:** Renewal, payments, guest passes, café (Phases 11–12)
- **M4 — Intelligence:** Concierge (AI + trainer-in-the-loop), Recovery Index, Timeline, community (Phase 13)
- **M5 — Polish & launch:** Staff panel, owner dashboard, QA (Phases 14–15)
- **Soft launch:** Founder's Club (~30 members), then general member rollout

## 11. Open Questions

1. WhatsApp BSP — Gupshup / AiSensy / other?
2. Founder's Club criteria — invite-only, fixed to launch cohort, or evergreen?
3. GST invoice format — Play Haus finance template available?
4. Trainer employment model — affects owner dashboard payout view
5. Café — do member statements roll up café to the monthly bill by default or opt-in?
6. Data residency — Supabase Mumbai region confirmed?
7. Human-in-the-loop cadence — how often will trainers review AI Concierge drafts? (Once daily / on-demand / weekly?)
8. Founder's Club dinner ops — is there a real hospitality budget for milestone gifting?

---

## Phase 1 (v1.1) Review Checklist

Before proceeding to Phase 2, please confirm:

- [ ] Brand hierarchy (Section 0) — Play Haus parent, Sanctuary sub-brand — is correct
- [ ] Vision (Section 1) is the tie-breaker you want the team to use
- [ ] Ritual-first framing (Section 6.2, 6.3) is the direction, à la carte remains available
- [ ] Concierge voice (Section 6.5) matches the tone you want
- [ ] Status ladder (Section 6.10) replaces points-first rewards
- [ ] Member Signature (Section 6.11) is the right "known, not tracked" set
- [ ] Recovery Index (Section 6.6) with transparent inputs is acceptable
- [ ] Member Timeline (Section 6.7) is scoped correctly
- [ ] Open questions (Section 11) have clear owners

Sign off, or edit, and I'll move on to the three foundational documents (**Brand Bible → Member Experience Blueprint → Service Playbook**) before Phase 2 (Information Architecture).
