# Phase 14 — Post-Launch Roadmap

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

Everything committed here happens *after* Vasant Kunj is a real, healthy club with a repeatable rhythm. The Year-2 and Year-3 horizons are directional; they should be re-plotted quarterly against actual member behaviour and business context.

Sections:
1. Roadmap horizons
2. Year-1 quarterly plan
3. Year-2 themes
4. Year-3 themes
5. Product bets (ranked)
6. Physical expansion
7. Super-app evolution
8. Native app decision
9. Deprecation & simplification budget
10. How we decide what to build next
11. Review checklist

---

## 1. Roadmap horizons

- **H0 — Now (launch quarter, months 1–3):** stabilise, listen, protect the brand.
- **H1 — Year-1 (months 4–12):** compound member value; harden multi-cohort dynamics; measured product depth.
- **H2 — Year-2:** second location; corporate wellness pilot; native app decision; wearables full integration.
- **H3 — Year-3:** super-app shell (Play Haus umbrella); Bangalore; Kids programming in-app; retreat product.

Ratios of engineering effort:
- H0 — 70% reliability + polish, 20% content ops tooling, 10% new features
- H1 — 45% new features, 30% reliability, 15% analytics/insights, 10% experiments
- H2 — 55% new features (multi-location, wearables), 25% platform work, 20% reliability
- H3 — 60% platform (super-app), 30% new destinations (Kids, Sports), 10% reliability

---

## 2. Year-1 quarterly plan

### 2.1 Q1 (launch quarter — H0)

- Ship it. Nothing new that isn't a bug-fix or a runbook improvement.
- One planned polish release per month.
- Concierge stays in Alpha; ops reviews all whispers.
- Weekly member listening: three members interviewed by product every week for 30 min.
- End of Q1: full retrospective, brand review, and honest ship-list revision.

### 2.2 Q2

- Concierge moves to Beta.
- Wearables V2 begins: Apple Health + Google Fit read-only integration.
- Member Signature v2: seasonal preferences (winter vs. summer defaults).
- Recovery Index v2: adds HRV and sleep from wearables where present.
- Payment reliability: full mandate coverage, invoice PDF v2.

### 2.3 Q3

- Concierge Beta → GA.
- Whoop + Oura integrations.
- Small-group training scheduling (in-app, was manual before).
- Programming automation for coaches (auto-suggest weekly schedule based on demand).
- Physiotherapist track surfaced in-app (currently manual).

### 2.4 Q4

- Second location scouting complete; open by month 15 (Year-2 Q1).
- Multi-location plumbing (Phase 6/7 §sharding): `location_id` scoping tested on staging with synthetic data.
- Native app decision point (see §8).
- Founding-year retrospective published as an editorial piece.

---

## 3. Year-2 themes

- **Second location.** Likely Gurugram (Cyber City / Golf Course Rd) or south-Delhi second location. Different tier balance, higher weekday-lunch traffic.
- **Corporate wellness pilot.** 2–3 anchor tenants, 30–50 seats each. Requires: SOC 2 Type 1, admin console for HR contacts, invoicing at company level, engagement reporting (aggregate only).
- **Kids in-app.** Play Haus Kids programming exposed under `/kids/` namespace. Guardian consent, minor privacy, family plan.
- **Wearables full integration.** Real-time from HealthKit, Google Fit, Whoop, Oura. Recovery Index v3.
- **Native app decision** (see §8).
- **Physical retail v1.** Small, curated shelf at reception — recovery essentials, teas, a book or two. Low-margin, on-brand.
- **The Retreat product.** First off-site retreat run in Q1 Year-2.
- **Hindi content.** Marketing site + selected app copy in Hindi.

---

## 4. Year-3 themes

- **Super-app shell.** Play Haus becomes the parent, Sanctuary is one of the tiles alongside Sports, Kids, Paradiso, HYROX. See §7.
- **Bangalore.** Third city; distinct programming for tech-heavy weekday-focused member base.
- **Public search.** Discovery of the brand needs polish once we can absorb the traffic.
- **Membership tiers refined.** New Family plan; possibly a Weekday-only mid-tier.
- **B2B wellness partnerships mature.** 10–15 corporate accounts; dedicated CS.
- **Founder Circle scaled.** Twice-yearly private evenings; possibly a founder-hosted podcast (low-key, quarterly).

---

## 5. Product bets (ranked)

Not every idea will ship. This is the current shortlist, ordered by expected impact against effort.

1. **Concierge personalisation depth.** Signature-aware whispers, seasonal shifts, coach-voice fidelity. Small deltas, huge cumulative feel.
2. **Wearables → Recovery Index.** Removes friction in self-reporting; makes RI feel more magical.
3. **Programming automation for coaches.** Frees coach time for members; reduces schedule friction.
4. **In-app rebooking flow after cancellation.** Currently a soft suggestion; make it one-tap.
5. **Multi-location scheduling.** Members traveling between locations, guest passes cross-location.
6. **Passkeys for sign-in.** Faster daily entry.
7. **Family plan.** Requires member-linking and shared credits.
8. **Physiotherapist in-app booking.** Currently ops-mediated.
9. **Retreat product.** Requires payments-for-events, comms, and logistics tooling.
10. **Small retail.** Paradiso menu already handles items; retail is menu-lite.
11. **Corporate admin console.** HR contact view, invoicing, aggregate engagement.
12. **Kids in-app.** Full guardian consent, minor safeguards.
13. **Hindi + Marathi localisation.** Content ops effort dominates.
14. **Native apps.** See §8.
15. **Search across catalogue.** Later; filters + sort suffice initially.

---

## 6. Physical expansion

### 6.1 Second location criteria

- 8,000–12,000 sqft
- Ground-floor accessibility
- Sauna, plunge, steam plumbing feasibility
- Parking / cabs proximity
- Anchor demand from existing member density (Gurugram vs. south Delhi debate resolved by member zip-code analysis at end of Q3)

### 6.2 Site opening playbook

- 4 months of construction and fit-out
- 2 months of pre-launch staffing and drills
- 30 Founding Members per new location (repeat of P1 formula)

### 6.3 Non-metro pilots

- Consider Kasauli, Rishikesh, Coonoor for pop-up recovery retreats (2–4 week runs)
- Requires portable protocols; permanent presence not before Year-4

---

## 7. Super-app evolution

Play Haus becomes the parent shell. Sanctuary, Sports, HYROX, Paradiso, Kids are destinations inside.

Technical plan:
- Product namespacing already in Phase 2 (`/sanctuary/`, `/sports/`, `/paradiso/`, `/kids/`)
- Shared identity, membership ledger, and payment surface (already Phase 3 design)
- Feature-flag driven visibility per destination
- Concierge is Sanctuary-only at V1; extends to Sports (matches, tournaments) in H2 with domain-specific attribution

Brand:
- Play Haus lockup used at parent surfaces (marketing site super-app, super-app home)
- Sanctuary lockup retained inside `/sanctuary/`
- Cross-brand navigation subtle, tab-bar-level at most

Governance:
- Cross-brand feature reviews at monthly product forum
- Each destination retains its own voice; Concierge does not roleplay
- Shared services (auth, payments, notifications) governed by platform team

---

## 8. Native app decision

We defer the native app until Q4 Year-1, decided on evidence.

### 8.1 Signals to build native

- PWA install rate < 40% among monthly-active members
- Push notification delivery reliability < 85% on iOS
- Meaningful integrations that require native (background HealthKit sync, Live Activities for ongoing rituals)

### 8.2 If we build

- React Native + Expo, sharing `packages/ui` and `packages/api-client`
- iOS first (member demographic skews iOS in Delhi metro)
- Android within 90 days of iOS
- Not a wrapper; native-feeling navigation and gestures

### 8.3 If we don't

- Double down on PWA install prompts, iOS home-screen guidance, and richer web push where supported

---

## 9. Deprecation & simplification budget

For every quarter, we allocate 5% engineering time to *removal*:
- Retire flags that have been at 100% for > 60 days
- Remove features with < 2% adoption after 90 days of full rollout
- Consolidate duplicated components
- Retire tables and columns that no longer serve

The removal budget prevents the same erosion that hurts every mature product. Removed features are documented in `docs/changelog/removed.md` with reason.

---

## 10. How we decide what to build next

At quarterly planning, every candidate is scored on four axes:

1. **Member value** (1..5): does this help a member feel known, restored, respected, in good hands, or that they belong?
2. **Ops relief or ops burden** (1..5): does this free coach time, or add to it?
3. **Brand alignment** (0/1 gate): does this cohere with the Brand Bible?
4. **Effort** (weeks of engineering).

Candidates are then plotted on impact-vs-effort. Anything that fails the brand gate is out regardless of score. Anything that helps ops but does not touch member value is downgraded.

Discovery inputs:
- Weekly member interviews (Product owns)
- Whisper audit + Concierge queue observations (Coach lead + Product)
- Ops retrospective monthly (Ops lead)
- Data (PostHog cohorts, funnel diagnostics)
- Founder intuition — used, but tested against the above

---

## 11. Review checklist

- [ ] Horizon ratios (70/20/10 at H0, 60/30/10 at H3) are the right split
- [ ] Year-1 quarterly plan is realistic given team size (~4 engineering, 1 product, 1 design)
- [ ] Year-2 themes align with business strategy and financial plan
- [ ] Year-3 super-app timing is right (not earlier, not later)
- [ ] Native-app decision gate at Q4 Year-1 is committed
- [ ] Deprecation budget of 5% every quarter accepted
- [ ] Decision framework (Member value + Ops + Brand gate + Effort) is used at every planning cycle
