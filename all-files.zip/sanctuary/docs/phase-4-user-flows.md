# Phase 4 — User Flows

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

This document specifies the ten flows that carry the majority of member value. Each flow is written as a state machine: entry conditions, screens, decisions, states, exits, edge cases, notifications, analytics events, and data tables touched (from Phase 3).

Voice guardrails from **doc-a Brand Bible** apply to every string. When the copy shown here isn't warm enough, the copy is wrong, not the flow.

---

## Reading key

- **Actor** — Member, Concierge (LLM), Trainer, Front-desk, Ops, System
- **State** — machine state persisted in the DB or client
- **Screen** — a route in Phase 2 IA (`/sanctuary/...`)
- **Event** — analytics event from `analytics_events` (Phase 3 §17)
- **Notification** — from Phase 2 notification IA
- **Table** — write target from Phase 3

## Flow index

| # | Flow | Owner |
|---|------|-------|
| 1 | Introduction → First visit (onboarding) | Product |
| 2 | Sign-in (returning member) | Product |
| 3 | Ritual reservation | Product |
| 4 | Class reservation (movement / performance) | Product |
| 5 | Cancellation & no-show | Product + Ops |
| 6 | Waitlist & release | Product |
| 7 | Concierge conversation | Product + AI |
| 8 | Membership plan purchase & renewal | Growth + Finance |
| 9 | Guest pass & referral | Growth |
| 10 | Off-boarding (pause, cancel, farewell) | CX |

Ancillary flows (short specs at the end): staff check-in, Paradiso order, health-form update, Recovery Index recompute, incident/safety event.

---

## 1. Introduction → First visit

**Intent.** Turn a curious inquirer into a member who has completed their first ritual and left feeling seen.

**Not a signup form.** This is a hospitality intake, not a SaaS onboarding.

### 1.1 Preconditions
- Public marketing site drives to `/join` (Phase 2)
- Inquirer arrives on the app with no session

### 1.2 States
`inquiry_received → intro_scheduled → intro_completed → health_intake_completed → tour_completed → first_ritual_booked → first_ritual_attended → member_active`

### 1.3 Screens
1. `/join` — "Request an introduction." Fields: name, phone, email, city, one sentence: *"What brought you to Sanctuary?"* No password. No plan picker.
2. Confirmation screen: *"We'll be in touch within a day."* Not "Thanks for signing up!"
3. **Off-app**: Concierge Ops (human) reaches out within 24h — WhatsApp preferred, phone if requested. Introduction call is booked.
4. `/join/intro/:token` — magic-link screen shown after the intro call. Confirms slot for tour + health intake at the location.
5. `/onboarding/health` — health intake (in-person on iPad or completed on their phone before arrival). Consent for contraindications and photography.
6. `/onboarding/preferences` — Member Signature seed: sauna temp default, tea preference, music, coach match, locker side. Optional; skippable.
7. `/onboarding/first-ritual` — first ritual is *proposed*, not selected. Concierge (human) has pre-selected a **Welcome Reset** ritual based on the intro call. Member confirms or asks for another.
8. `/rituals/:id/confirmation` — the pre-arrival note (see §3.6).

### 1.4 Copy — first-ritual proposal
> **A first ritual, chosen for you.**
> Rohan spoke to you about sleep. He's suggested a gentle *Recovery Reset* — sauna, a short cold, and a warm tea at Paradiso. Saturday, 10:00 AM. If another time works better, we'll move it.

Two buttons: *"Yes, Saturday works"* / *"Suggest another time"*.

### 1.5 Decisions
- **Health flag** — if intake reveals a contraindication (uncontrolled BP, pregnancy, recent cardiac event), the proposed ritual is downshifted; Concierge Ops is paged.
- **No response to intro outreach** — after 2 attempts across 3 days, inquiry moves to `nurture` (marketing) and out of active pipeline.

### 1.6 Events
`inquiry_submitted`, `intro_scheduled`, `intro_completed`, `health_intake_completed`, `signature_seeded`, `first_ritual_proposed`, `first_ritual_confirmed`, `first_visit_arrived`, `first_ritual_attended`

### 1.7 Tables
`members` (status: `inquirer` → `guest` → `member`), `member_signature`, `member_health`, `reservations`, `reservation_slots`, `timeline_milestones` (auto-inserts `Joined Sanctuary`), `audit_log`

### 1.8 Notifications
- 24h before first visit — WhatsApp: *"Ritika will meet you at reception at 9:55."*
- 2h before — WhatsApp with map + parking + what to bring
- Post-visit +2h — Concierge whisper: *"How did that feel?"* (opens post-ritual feedback)

### 1.9 Edge cases
- Inquirer books online without a call — flow forks to a lightweight *Guest visit* (§9 guest pass), and Concierge Ops calls before the visit rather than after.
- Existing Play Haus Sports member joining Sanctuary — pre-populate identity, skip intro call, still run health intake and Signature.

---

## 2. Sign-in (returning member)

**Intent.** Get the member into the app with the fewest actions and no friction. Prefer passwordless.

### 2.1 States
`signed_out → challenge_sent → verifying → signed_in`
Failure fork: `signed_out → challenge_sent → challenge_expired → signed_out`

### 2.2 Screens & steps
1. `/signin` — brand + video, single primary action **Continue with email**, secondary **Continue with Google**, tertiary **Continue with Apple** (iOS), tertiary link *Request an introduction* for non-members.
2. Email entry — inline field; send magic link on submit.
3. `/signin/sent` — *"A sign-in link is on its way to yuvraj@…"* Resend after 45s.
4. Deep link `/auth/callback?token=…` — validates token. If session established, route to `/loading`.
5. `/loading` — cinematic loop (2.4–3.0s) with *"Welcome back, Yuvraj. A moment, while we prepare your evening."*
6. `/sanctuary/arrival` — Arrival screen with day-part greeting and today's ritual.

### 2.3 Rules
- Magic-link lifetime: 15 min, single-use.
- On unknown email: do not reveal that the account is unknown. Show the same "link sent" screen. Concierge Ops sees an alert; may reach out.
- Session lifetime: 30 days on trusted devices; 24h on new device; step-up required for payment changes and health-record edits.
- Biometric unlock (WebAuthn / passkey) offered on 3rd successful sign-in.

### 2.4 Loading screen — content matrix

| Day-part | Copy |
|---|---|
| Morning (05–11) | *"Welcome back, {name}. A moment, while we prepare your morning."* |
| Midday (11–16) | *"Welcome back, {name}. A moment, while we open the doors."* |
| Evening (16–22) | *"Welcome back, {name}. A moment, while we prepare your evening."* |
| Night (22–05) | *"Welcome back, {name}. It's late — we'll keep this brief."* |

If member missed 3+ days, secondary line: *"We noticed you were away. Nothing to catch up on."*

### 2.5 Events
`signin_challenge_requested`, `signin_challenge_delivered`, `signin_completed`, `signin_failed`, `passkey_registered`

### 2.6 Tables
`auth_sessions` (implicit in Supabase auth), `analytics_events`, `audit_log` on new device or step-up.

---

## 3. Ritual reservation

**The primary booking flow.** A ritual is a composed sequence of services with parent reservation + child slots (Phase 3 §7).

### 3.1 Preconditions
- Member is active with valid membership OR has drop-in credits.
- Ritual is available at chosen location + date.

### 3.2 States
`browsing → composing → slot_holding → payment_or_credit → confirmed → reminded → checked_in → in_progress → completed → reviewed`
Failure forks: `slot_hold_expired`, `payment_failed`, `no_show`, `late_cancel`

### 3.3 Screens
1. `/sanctuary/rituals` — list of composed rituals (Morning Reset, Recovery Reset, Evening Wind Down, Weekend Recharge, Longevity Reset)
2. `/sanctuary/rituals/:id` — ritual detail (see preview) with composition, prepare notes, contraindications, Paradiso pairing
3. `/sanctuary/rituals/:id/reserve` — evening/time picker. Rooms not shown; the room is chosen for the member.
4. **Slot-hold interstitial** — for high-demand rituals, a 3-minute hold displayed as *"Held for you until 6:47."*
5. `/sanctuary/rituals/:id/confirm` — final review with policy line and, if needed, upgrade CTA
6. `/sanctuary/reservations/:id` — post-booking confirmation with pre-arrival note, add-to-calendar, cancel link.

### 3.4 Decision points
- **Membership eligibility** — free with plan, extra credit needed, or add-on required
- **Trainer preference** — Signature default coach; ability to say *"anyone"* or select a specific coach
- **Contraindication trigger** — if health record shows a flag against a component (e.g. ice bath + cardiac history), the ritual is offered with the component removed or with a Concierge intervention
- **Recovery Index gate** — if the member's Recovery Index is red for 2+ days and they're booking an intense ritual, show a *"Ritika suggests you consider…"* soft nudge (never a hard block)

### 3.5 Slot-hold behaviour
- Held on `waitlist_holds` with `expires_at = now() + 3 min`, `hold_kind = 'reservation'`
- Countdown visible in UI
- Expiry: release slot, notify member gently: *"The room opened back up. Would you like to try again?"*

### 3.6 Pre-arrival note (24h before)

> **Tomorrow at 6:45.**
> Ritika will meet you at reception. Locker 12, as you like it. Sauna at 78°C. A ginger tea will be warm and waiting after.
>
> — a note from Sanctuary

Delivered as: WhatsApp (primary) + in-app inbox + optional email.

### 3.7 Check-in (day-of)
- 30 min before, in-app card *"Ready when you are."* with a check-in button
- On arrival, front-desk scans the member's face on tablet OR taps *"Check in Yuvraj"* on the tablet's day-view.
- Also supports self check-in via QR at reception if the front-desk is with another member.

### 3.8 Completion & feedback
- After ritual end-time + 15 min, in-app whisper: *"How did that feel?"*
- 3 options: *Restored / Steady / Off* + optional 1-line note. Non-mandatory; never blocks the app.
- Feeds `post_ritual_feedback`, contributes to Recovery Index self-report and to Concierge memory.

### 3.9 Events
`ritual_viewed`, `ritual_slot_held`, `ritual_slot_expired`, `ritual_reserved`, `ritual_reminder_sent`, `ritual_checked_in`, `ritual_started`, `ritual_completed`, `ritual_feedback_submitted`

### 3.10 Tables
`reservations`, `reservation_slots`, `waitlist_holds`, `sessions` (child slots linked), `attendance`, `post_ritual_feedback`, `payments` (if paid outside membership), `timeline_milestones` (10th visit etc.), `analytics_events`

### 3.11 Edge cases
- **Room reassignment** — Ops can move the reservation to a different room; member gets a whisper if the room number changes (never a red banner)
- **Trainer sickness** — if the assigned coach cancels < 4h before, Concierge offers alternatives; if none acceptable, ritual is refunded to credit plus a Paradiso gesture
- **Location closed (extreme weather)** — mass cancellation flow; refund to credit + priority rebook window

---

## 4. Class reservation

**Class ≠ ritual.** A class is a single-session group offering (yoga, pilates, HIIT, strength, boxing, HYROX, cardio, meditation, breathwork). It uses the same reservation primitives but a simpler UI.

### 4.1 Preconditions
- Session exists in `sessions` with `starts_at` in the future and `capacity > booked`
- Member has plan entitlement or drop-in credit
- Health flags checked against class contraindications

### 4.2 States
`browsing → booking → confirmed → reminded → checked_in → attended → reviewed`
Failure: `waitlisted`, `late_cancel`, `no_show`

### 4.3 Screens
1. `/sanctuary/classes` — day-first schedule. Filters: pillar (Movement / Performance / Recovery / Mindfulness), modality, coach, intensity, time.
2. `/sanctuary/classes/:id` — session detail with coach bio, intensity, what-to-bring, contraindications
3. Bottom-sheet *"Reserve"* — one tap on the tile also works
4. Confirmation card in inbox

### 4.4 Class taxonomy (V1)

- **Movement** — Yoga (Vinyasa, Yin, Restorative), Pilates (Mat, Reformer), Barre, Mobility
- **Performance** — Strength & Conditioning, HYROX Prep, Functional, Boxing, Kickboxing, Cardio (spin, row)
- **Recovery** — Recovery Yoga, Mobility Reset, Stretch (assisted / open)
- **Mindfulness** — Breathwork (Coherent, Wim Hof, Box), Meditation, Sound bath
- **Aqua & Kids** — Aqua fit, Kids movement (namespaced under `/kids/`)

Each class links to a `service` and `service_variant` (Phase 3 §5).

### 4.5 Decisions
- **Full → Waitlist** — if `capacity` reached, offer waitlist join (see §6)
- **Intensity mismatch** — if class intensity ≥ Hard and member's 7-day recovery is red, show soft nudge with alternatives
- **Contraindication** — pregnancy vs. hot yoga, cardiac vs. HIIT — hard warning + coach note before allowing booking; requires member acknowledgement

### 4.6 Events
`class_viewed`, `class_reserved`, `class_waitlisted`, `class_checked_in`, `class_attended`, `class_missed`

### 4.7 Tables
Same as §3 with `sessions.service_id` pointing to a class variant, no parent-ritual grouping.

### 4.8 Copy — full class
> *"This class is full. Would you like to be next in line? We'll let you know within an hour if a spot opens."*

Two options: *"Yes, add me"* / *"Show similar classes today"*.

---

## 5. Cancellation & no-show

**Intent.** Give members grace when life gets in the way, protect capacity for others, deter no-shows without punishing.

### 5.1 Cancellation windows (default policy)

| Product | Free cancel until | Late cancel window | No-show |
|---|---|---|---|
| Ritual | −4h from start | −4h to −1h | after start |
| Class | −2h from start | −2h to start | after start |
| PT / small-group | −12h from start | −12h to −2h | after start |
| Event / workshop | −48h from start | −48h to −24h | after start |

Overridable per `cancellation_policies` row (Phase 3 §7).

### 5.2 States
`confirmed → cancelled_free` | `confirmed → cancelled_late → strike_applied` | `confirmed → no_show → strike_applied → penalty_charged`

### 5.3 Screens
- Cancel confirmation modal — shows what happens: refund to credit, or strike, or partial fee
- Post-cancel screen — *"The room is back in circulation. See you soon."* Never guilt-inducing.

### 5.4 Strike ladder (`strikes` table)
- 1st late/no-show in a rolling 60 days — soft note from Concierge, no penalty
- 2nd — booking window narrowed to 7 days out for 14 days
- 3rd — booking capability for peak hours limited to −24h window; Concierge Ops reaches out to see if something's off
- Founder / Inner Circle: no automated strikes; Ops reviews

### 5.5 Copy — late cancel
> *"We'll let the room breathe. This one's on us — but if it becomes a rhythm, we'll check in."*

### 5.6 Events
`ritual_cancelled_free`, `ritual_cancelled_late`, `ritual_no_show`, `strike_incremented`, `strike_forgiven`

### 5.7 Tables
`reservations` (status → `cancelled` / `no_show`), `strikes`, `payments` (if late-cancel fee), `notifications`, `audit_log`

---

## 6. Waitlist & release

**Intent.** When a ritual or class fills, honor demand transparently and fairly.

### 6.1 States
`waitlist_joined → held → offered → accepted → confirmed` | `offered → declined → next_in_line` | `offered → expired`

### 6.2 Rules
- Waitlist joined on `waitlist_holds` with `hold_kind = 'waitlist'`, `position` assigned
- When a slot opens, top position is offered
- Offer TTL: 15 min for classes (< 2h from start: 5 min), 30 min for rituals; if unacknowledged, next in line
- Member sees position: *"Third in line. We usually reach the third spot."* Never a raw number without context.

### 6.3 Screens
- Class detail shows waitlist CTA with plain-language chance
- Whisper on offer: *"A spot opened for Pilates Core at 10. Would you like it? Reply within 15 minutes."*
- Push + WhatsApp for offers

### 6.4 Events
`waitlist_joined`, `waitlist_offered`, `waitlist_accepted`, `waitlist_declined`, `waitlist_expired`

### 6.5 Tables
`waitlist_holds`, `reservations` (on accept), `notifications`

### 6.6 Edge cases
- Member is signed into multiple devices — offer visible on all, first accept wins, others show *"We just booked this on another device."*
- Member is currently in a conflicting session at offer time — offer suppressed

---

## 7. Concierge conversation

**Concierge speaks first.** It is a hospitality voice attributed to a human coach (or "Sanctuary Concierge" for unattributed system whispers). It is not a chatbot.

### 7.1 Two modes
- **Whisper** — proactive, one-way, in-app card or WhatsApp; often ends with a soft question that opens the conversation
- **Conversation** — two-way, initiated from the whisper or from the floating Concierge button

### 7.2 Preconditions
- Member is signed in
- Content-safety and safety-guardrail model is available
- Trainer of record (`trainer_assignments`) is known for attribution

### 7.3 States
`idle → whisper_composed → whisper_delivered → member_engaged → drafting_reply → reply_delivered → session_ended`
Safety fork: `safety_event → escalated_to_ops → member_contacted_human`

### 7.4 Whisper composer (system)
1. Trigger fires (post-ritual, recovery-index change, streak, missed day, health-form due, etc.)
2. Compose prompt is assembled with:
   - Member context (age band, tenure, tier, recent visits, Recovery Index, Signature)
   - Attribution (trainer of record)
   - Voice constraints from Brand Bible
   - Safety constraints
3. LLM drafts whisper; a light validator checks for banned words, medical claims, prescriptions
4. Result stored on `concierge_whispers` with `status = 'ready'`
5. Delivery worker sends via preferred channel, respecting notification prefs and quiet hours

### 7.5 Sample whispers

*Post-ritual*
> **A note from Ritika.** You've had three intense sessions this week. A slower evening tonight will do more than another cold plunge would.
> *"How does that sit?"* [Open Concierge]

*Recovery red*
> **A quiet suggestion.** Your Recovery Index has been below your usual for three days. Rohan wonders if a Recovery Reset before your Saturday match makes sense.
> *"Would you like me to hold Friday 7:30?"* [Yes, hold it / Not this week]

*Streak*
> **Twenty visits in.** Not a milestone — just something we noticed. Thank you for being here.

### 7.6 Conversation
- Structured recommendations: LLM returns text plus zero or more `action` payloads (e.g. `{kind: 'hold_reservation', ritual_id, slot_at}`)
- The app renders actions as taps, never as raw JSON
- Reservations, cancellations, and payment-related actions require a member confirmation tap even if the LLM proposes them
- Conversation is stored on `concierge_conversations` + `concierge_messages`

### 7.7 Safety guardrails
Trigger a `concierge_safety_event` when member text contains:
- Medical urgency (chest pain, shortness of breath, injury with swelling, fainting)
- Mental-health distress markers
- Third-party health claims
- Pregnancy-related contraindications

On safety event:
- Bot **stops** its own answer immediately
- A single scripted response is shown: *"Let's have a person help with this. Rohan is being paged now — you'll hear from him in a few minutes. If this is urgent, please call {emergency contact} or your doctor."*
- Ops is paged (Slack + SMS to on-call)
- Human takeover: subsequent messages route to a coach, not the LLM

### 7.8 Events
`concierge_whisper_composed`, `concierge_whisper_delivered`, `concierge_whisper_opened`, `concierge_conversation_started`, `concierge_action_proposed`, `concierge_action_confirmed`, `concierge_safety_event`, `concierge_ops_takeover`

### 7.9 Tables
`concierge_whispers`, `concierge_conversations`, `concierge_messages`, `concierge_safety_events`, `notifications`

---

## 8. Membership plan purchase & renewal

**Intent.** Convert intent to plan without ever feeling like a checkout.

### 8.1 Plans (V1)

| Tier | Cadence | Includes | Idea |
|---|---|---|---|
| Explorer | 30 days | 6 classes or 3 rituals | Trial |
| Member | Monthly | Unlimited classes, 8 rituals, 1 guest pass/mo | Core |
| Resident | Annual | Everything + priority + 4 guest passes + 1 review | Regulars |
| Inner Circle | Annual, invite | Resident + personal coach hours + concierge suite | High-touch |
| Founder | Annual, invite | Bespoke | Whitelist |

`plans` + `memberships` from Phase 3 §6.

### 8.2 Purchase flow (new member)

1. Ops walks the member through the plan verbally (post-first-ritual, ideally in person)
2. In app, `/membership/proposed` shows the plan Ops selected with the price and inclusions
3. `/membership/setup` — Razorpay checkout for card / UPI / netbanking; auto-mandate for renewals (RBI e-mandate for cards)
4. `/membership/setup/success` — quiet confirmation, no confetti
5. Member Timeline gets a *"Membership begins"* milestone (attribution)

### 8.3 Renewal (existing)

- 14 days before expiry — Concierge whisper: *"Your year with us renews on {date}. Same rhythm, same rate."*
- 3 days before — WhatsApp + email
- Day-of — automatic charge via mandate
- Success → in-app whisper of thanks, milestone written to timeline
- Failure → grace period 5 days, then plan → `past_due`; member kept in `member` status; retry twice, then Ops contacted

### 8.4 Change of plan

- Upgrade (Explorer → Member, Member → Resident) — pro-rated; effective immediately; welcome note
- Downgrade — effective at next cycle; no penalty; short *"we're here when you're ready to come back"* note
- Pause (Member+, up to 30 days/year) — self-serve; billing paused; a warm *"see you soon"*

### 8.5 Payment failure
- Immediate retry in 24h
- WhatsApp + email + in-app whisper
- Never expose the raw gateway error; translate to: *"Your bank didn't clear the charge. We'll try again tomorrow — or you can update the card whenever it's convenient."*
- Second failure → Ops pages the member to update the card during a soft conversation

### 8.6 Events
`plan_viewed`, `plan_proposed`, `plan_purchased`, `plan_renewed`, `plan_renewal_reminder_sent`, `plan_upgraded`, `plan_downgraded`, `plan_paused`, `plan_cancelled`, `plan_payment_failed`

### 8.7 Tables
`plans`, `memberships`, `membership_ledger`, `payment_mandates`, `payments`, `invoices`, `invoice_line_items`, `refunds`, `payment_events`, `timeline_milestones`, `notifications`

---

## 9. Guest pass & referral

**Intent.** Let members bring the people they love. Reward without transactional-feeling incentives.

### 9.1 Guest pass

- Included with plan: 1/mo (Member), 4/yr (Resident+)
- Additional passes purchasable
- Guest fills a short intake at `/guest/:token` — same health intake as a full member, fewer questions
- Guest attends up to 2 rituals or 3 classes under a single pass, within 30 days

**States**: `pass_issued → pass_claimed → guest_intake_done → visit_booked → visit_attended → pass_closed | pass_expired`

**Table**: `guest_passes`, `members` (guest record with `status = 'guest'`)

### 9.2 Referral

- Every member has a permanent referral link
- If a referred person joins within 60 days:
  - Referrer earns a *quiet* recognition — an experience credit (a free Recovery Reset, or a Paradiso credit), not a discount. Reason: money doesn't fit the brand.
  - Referred member gets a small warm gesture on their first visit (a note, a tea)
- Beyond 5 referrals in a year: a private thank-you from the founder + a personal invite to a member evening

**Copy**
> *"You brought someone home. Ritika is holding a Recovery Reset for you — pick a time when it suits."*

**Events**: `guest_pass_issued`, `guest_pass_claimed`, `guest_visit_attended`, `referral_link_shared`, `referral_signup_completed`, `referral_reward_issued`

**Tables**: `guest_passes`, `referrals`, `rewards_ledger`, `notifications`

---

## 10. Off-boarding (pause, cancel, farewell)

**Intent.** People leave. Make it easy, dignified, and reversible. A great off-boarding is a great on-boarding for future returns.

### 10.1 Pause (self-serve)

- Up to 30 days per calendar year
- One tap in `/account/membership/pause`
- Immediate; billing pauses; access continues until pause start
- Copy: *"See you soon, Yuvraj. Your seat is here whenever you're back."*

### 10.2 Cancel (self-serve with a soft door)

1. `/account/membership/cancel` — one question: *"Would you like to tell us why?"* Options: schedule, cost, injury, moved, no reason.
2. Based on answer, offer a tailored alternative — never twice, never manipulative
   - Schedule → pause up to 30 days
   - Cost → downgrade to Explorer
   - Injury → Concierge outreach with a recovery-only plan
   - Moved → export of timeline as a keepsake PDF
   - No reason → straight to confirmation
3. Confirm — cancel is effective at end of current cycle
4. `/account/membership/goodbye` — a real note (not a survey), signed by Rohan

### 10.3 Farewell letter (physical)

- If the member was Resident+ or > 12 months tenure, a printed card is queued to Ops
- Written by the assigned trainer, not a template

### 10.4 Reactivation
- Ex-member can return at any time via `/return` — a single tap re-opens the plan they had at cancellation, or lets them pick anew
- Their Timeline persists; a *"Welcome back"* milestone is written on reactivation

### 10.5 Events
`membership_pause_started`, `membership_pause_ended`, `membership_cancel_reason_selected`, `membership_cancel_alternative_shown`, `membership_cancel_alternative_accepted`, `membership_cancelled`, `membership_reactivated`

### 10.6 Tables
`memberships` (status → `paused` / `cancelled` / `active`), `membership_ledger`, `off_boarding_notes` (Ops queue), `timeline_milestones`, `notifications`, `audit_log`

---

## Ancillary flows (short specs)

### A. Staff check-in
- Front-desk tablet at each location shows the day-view sorted by upcoming
- Tap member → mark checked-in → `attendance.status = 'in'`
- If member is late, tablet highlights row amber; if 15 min past start, ops decides: check in with grace or mark late
- Face-scan optional (opt-in in Signature)

### B. Paradiso order
- Menu at `/paradiso`; member's usual pinned at top
- Order attached to a reservation → delivered to seating post-ritual
- Payment: charged to Paradiso tab, reconciled monthly, appears on invoice
- Events: `paradiso_order_placed`, `paradiso_order_fulfilled`

### C. Health-form update
- Every 6 months, or on trigger (injury reported, pregnancy declared, medication change)
- Rendered as a friendly form: *"A few things to keep us safe. Rohan will read this."*
- Never blocks the app; contraindication warnings apply per-flow

### D. Recovery Index recompute
- Nightly job reads `recovery_index_inputs`, `self_reports`, `wellness_metrics`
- Writes `recovery_index_daily` with narrative + component scores
- If today's Recovery Index moves > 1 band vs. rolling median, emit whisper trigger
- Never surfaces raw numbers without narrative context

### E. Incident / safety event
- Staff-initiated from tablet: incident type, member, timestamp, notes
- If member-facing action needed (medical hold, waiver flag), Concierge is notified to route future flows accordingly
- Member view: nothing changes visibly; only affected flows show contextual warnings when relevant

---

## State machine summary (compact)

```
Ritual reservation
─────────────────────────────────────────────────────
browsing → composing → slot_holding ─┬─> payment_or_credit ─> confirmed
                                     │
                                     └─(expire)─> browsing
confirmed → reminded → checked_in → in_progress → completed → reviewed
              │            │
              │            └─(no-show)─> no_show → strike
              └─(cancel)─┬─> cancelled_free
                         └─> cancelled_late → strike
```

```
Concierge
─────────────────────────────────────────────────────
trigger → composed → validated ─┬─> delivered ─> opened ─> engaged
                                │                                │
                                └─(banned)─> discarded          ├─> action_confirmed
                                                                 └─> safety_event ─> ops_takeover
```

```
Membership
─────────────────────────────────────────────────────
proposed ─> checkout ─> active ─┬─> paused ─> active
                                ├─> upgraded / downgraded
                                ├─> past_due ─> active | cancelled
                                └─> cancel_intent ─> alternative_offered ─> cancelled
                                                        │
                                                        └─> retained
```

---

## Notifications matrix (indicative)

| Trigger | Channel(s) | Timing | Quiet hours honored? |
|---|---|---|---|
| First-visit pre-arrival | WhatsApp, email | −24h, −2h | Yes |
| Ritual reminder | WhatsApp, push | −24h, −2h | Yes |
| Slot-hold expiring | Push | −60s | No |
| Waitlist offer | WhatsApp, push | on-open | No |
| Late-cancel note | In-app whisper | on-cancel | Yes |
| Concierge whisper (recovery) | Push, in-app | anytime (respect quiet hours) | Yes |
| Concierge safety event | WhatsApp (Ops) + SMS + in-app | immediate | No |
| Plan renewal | Email, in-app | −14d, −3d, day-of | Yes |
| Payment failed | Email, WhatsApp | on-fail, +24h | Yes |
| Guest pass claimed | In-app to referrer | on-claim | Yes |
| Milestone (tenure, tier) | In-app | day-of | Yes |

Quiet hours default: 22:00–07:00 IST, overridable in Signature.

---

## Instrumentation coverage

Every flow above must emit at minimum:
- one `*_started` event
- one `*_completed` or terminal event
- error / failure events for each named failure fork

Analytics team owns the `analytics_events` schema and consumers.

---

## Copy do / don't (flow-wide)

**Do**
- Attribute to a person (Ritika, Rohan, Meera) whenever possible
- Use "note from …" for whispers, "moment" for loading, "held for you" for slot-holds
- Assume the member is capable and busy

**Don't**
- "Congrats! You unlocked…" (points-speak)
- "Are you sure?" without reason (nagging)
- "Oops, something went wrong" (unearned casualness)
- Any exclamation marks unless the member has actually earned a genuine celebration
- Any emoji in system copy

---

## Review checklist — Phase 4

Please confirm the following before we move to Phase 5 (Design System & Component Library).

- [ ] The **ten primary flows** cover the value we intend for V1
- [ ] The **cancellation policy** windows and strike ladder feel appropriately generous
- [ ] The **Concierge safety guardrail** (auto-stop + human takeover) is acceptable to Ops
- [ ] The **class taxonomy** (Movement / Performance / Recovery / Mindfulness + Aqua & Kids) is right for launch, or we should expand/reduce
- [ ] The **membership tiers** (Explorer / Member / Resident / Inner Circle / Founder) map correctly to the status ladder in the PRD
- [ ] **Referral rewards** as *experience credits* (not discounts) is on-brand
- [ ] The **off-boarding tone** — real note, no manipulation — is what we want
- [ ] Ancillary flows (staff check-in, Paradiso, health, Recovery Index, incident) are complete enough for V1
- [ ] **Notification channels & timings** are agreed with Ops (WhatsApp BSP capacity, quiet hours, opt-outs)

## Open questions

1. **Waitlist offer channel** — WhatsApp is fastest but noisy for classes filling and releasing within an hour. Should waitlist offers for classes < 2h out use push-only?
2. **Auto-mandate coverage** — Do we require e-mandate for all recurring plans, or allow monthly-manual for members who prefer it?
3. **Guest intake depth** — Guests get a lighter health form. Should guests attending high-intensity classes (HIIT, HYROX) fill the full form?
4. **Strike ladder for premium tiers** — Founder/Inner Circle are hand-managed. Should Resident also be excluded from automated strikes, or kept in the system?
5. **Multi-location transfer** — Do we assume single-location membership at launch, or is cross-location built into plan pricing from day one?

## Hand-off to Phase 5

Once approved, Phase 5 (Design System & Component Library) will define:
- Token schema (colors, type, spacing, motion) from doc-a
- Component inventory: buttons, cards, whispers, class card, ritual card, service tile, comp step, timeline dot, tab bar, sheet, modal, form fields, empty states, error states
- Interaction specs: press states, focus, disabled, loading, skeletons
- Accessibility: contrast ratios, keyboard, screen-reader labels, motion-reduced variants
- Component API contract (props, slots, events) for the Next.js build
