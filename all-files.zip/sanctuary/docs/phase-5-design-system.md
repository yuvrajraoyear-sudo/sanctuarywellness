# Phase 5 — Design System & Component Library

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

The visual and interaction system that carries every screen in the app, marketing site, and staff tablet. Tokens are the source of truth; components are compositions of tokens; screens are compositions of components. Nothing on a screen may hard-code a value that could live in a token.

Voice from **doc-a Brand Bible** and behaviour from **Phase 4 Flows** are assumed. This document specifies the *how*.

Sections:
1. Principles
2. Tokens (color, type, space, radius, shadow, motion, z-index)
3. Grid & layout
4. Iconography & imagery
5. Component inventory (V1)
6. Component specs (18 components)
7. Interaction states (base contract)
8. Accessibility contract
9. Motion contract
10. Content patterns (empty, error, loading, success)
11. Component API contract (Next.js / React)
12. Naming & file structure
13. Review checklist + open questions

---

## 1. Principles

- **Whisper, never shout.** Contrast, weight, motion — all restrained. The loudest thing on a screen should be a single primary action.
- **One decision per screen.** If a screen has more than one primary CTA, it's two screens.
- **Type does the heavy lifting.** Fraunces sets tone; Inter carries meaning. Almost everything else fades.
- **Warm neutrals, one accent.** Sand and stone are the surface. Maroon is the punctuation. Sage and sunset are used sparingly for status.
- **Motion is breath.** Slow, exhaled, never bouncy. Reduced-motion users get instant transitions with no meaning lost.
- **The system is honest.** No skeuomorphism, no glassmorphism where meaning matters. Textures allowed for hero imagery only.
- **Accessibility is not a mode.** AA is the floor. Focus is visible. Motion has an escape.

---

## 2. Tokens

Tokens live in `packages/tokens/` and are consumed by Tailwind, CSS variables, and design tools. Token names are semantic first; primitives second. Do not reference primitives in components.

### 2.1 Color — primitives

```
--sand-50:   #faf7f2   /* app background (light) */
--sand-100:  #f3ede2   /* card surface */
--sand-200:  #e7dccb   /* border / divider */
--sand-300:  #d6c7b0   /* pressed / hover surface */

--stone-400: #a89a86   /* placeholder, disabled ink */
--stone-500: #8a7f70   /* secondary ink */
--stone-600: #6c6055   /* body ink alt */

--ink:       #161311   /* primary ink */
--ink-2:     #3a3530   /* body ink */

--maroon-500:#7a2f2b   /* brand accent */
--maroon-700:#4d1e1c   /* accent pressed */

--sage-400:  #8a9a82   /* success / calm */
--sunset-400:#c88a5c   /* warmth / attention */
--dawn-400:  #b0c4d0   /* cold / recovery, indicative */

--danger-500:#a24040   /* destructive text (rare) */

--focus:     #6c8fb4   /* focus ring, only visible on keyboard focus */
```

### 2.2 Color — semantic (consume these)

```
--bg-app:            var(--sand-50)
--bg-surface:        var(--sand-100)
--bg-surface-hover:  var(--sand-200)
--bg-surface-press:  var(--sand-300)
--bg-inverse:        var(--ink)

--fg-primary:        var(--ink)
--fg-body:           var(--ink-2)
--fg-secondary:      var(--stone-600)
--fg-muted:          var(--stone-500)
--fg-placeholder:    var(--stone-400)
--fg-inverse:        var(--sand-50)

--border-hairline:   rgba(0,0,0,.06)
--border-soft:       var(--sand-200)
--border-strong:     var(--stone-400)

--accent:            var(--maroon-500)
--accent-press:      var(--maroon-700)
--accent-soft:       rgba(122,47,43,.10)

--status-good:       var(--sage-400)
--status-warm:       var(--sunset-400)
--status-cold:       var(--dawn-400)
--status-danger:     var(--danger-500)

--focus-ring:        var(--focus)
```

### 2.3 Color — dark surface (sign-in, loading, night mode later)

Not a full dark theme in V1. A dedicated set of tokens for cinematic surfaces:

```
--bg-night:          #14100e
--bg-night-2:        #1e1815
--fg-on-night:       #faf7f2
--fg-on-night-muted: rgba(250,247,242,.65)
--border-on-night:   rgba(250,247,242,.22)
--surface-on-night:  rgba(250,247,242,.06)
```

### 2.4 Contrast pairs (WCAG AA)

| FG | BG | Ratio | Usage |
|---|---|---|---|
| `--ink` on `--sand-50` | 15.1 : 1 | Body & headings on app |
| `--ink-2` on `--sand-100` | 11.4 : 1 | Body on card |
| `--stone-600` on `--sand-100` | 5.4 : 1 | Secondary text |
| `--stone-500` on `--sand-50` | 5.2 : 1 | Eyebrows, captions |
| `--maroon-500` on `--sand-50` | 6.9 : 1 | Accent links |
| `--fg-on-night` on `--bg-night` | 15.4 : 1 | Sign-in headline |

`--stone-400` is placeholder-only; not used for readable text.

### 2.5 Typography

Two families. Nothing else.

**Fraunces** — serif, variable, opsz 9..144, wghts 400/500/600. Used for: headlines, ritual/class names, numbers with meaning, italic voice.

**Inter** — sans, wghts 400/500/600/700. Used for: body, meta, UI labels, uppercase micro-copy.

```
--font-serif: 'Fraunces', 'Iowan Old Style', Georgia, serif;
--font-sans:  'Inter', -apple-system, system-ui, 'Segoe UI', sans-serif;
```

**Scale (rem)** — mobile default; scale slightly larger on desktop only where noted.

| Token | rem | px | Use | Family |
|---|---|---|---|---|
| `--text-display` | 3.25 | 52 | Marketing hero | serif 400 italic-optional |
| `--text-h1` | 2.6 | 41 | Screen title | serif 500 |
| `--text-h2` | 1.85 | 30 | Card title | serif 500 |
| `--text-h3` | 1.35 | 22 | Section title | serif 500 |
| `--text-lg` | 1.1 | 18 | Emphasis body | serif 400 or sans 500 |
| `--text-body` | 1.0 | 16 | Body | sans 400 |
| `--text-sm` | 0.88 | 14 | Meta, buttons | sans 500 |
| `--text-xs` | 0.78 | 12 | Fine print | sans 400 |
| `--text-eyebrow` | 0.72 | 11.5 | Uppercase eyebrows | sans 500, tracking .14em |

Line-height: 1.02 for h1/display, 1.1 for h2, 1.3 for h3, 1.5 for body, 1.4 for lg.

Letter-spacing: −0.03em on display/h1, −0.02em on h2, −0.01em on h3, 0 body, 0.14em eyebrows, 0.24em brand mark.

Numbers use `font-feature-settings: 'tnum'` for tabular alignment (timers, prices, durations).

Italics are **meaningful** — used for quotes, notes from a person, and one-word status ("*restored*"). Not decoration.

### 2.6 Spacing

Base unit 4. Use `spacing-N` where N is multiples of the base:

```
--space-1:  4px
--space-2:  8px
--space-3:  12px
--space-4:  16px
--space-5:  20px
--space-6:  24px
--space-7:  28px
--space-8:  32px
--space-10: 40px
--space-12: 48px
--space-16: 64px
--space-20: 80px
```

Vertical rhythm: prefer 24 / 28 / 32 between sections; 12 / 14 inside cards; 4 / 6 between related lines.

### 2.7 Radius

```
--radius-xs:  6px    /* chips, badges */
--radius-sm:  10px   /* small tiles */
--radius:     14px   /* default surface */
--radius-lg:  22px   /* hero card, sheet */
--radius-xl:  32px   /* device shell */
--radius-pill:999px  /* buttons, chips */
```

### 2.8 Shadow

Shadow is **rare**. When used, it is warm and low.

```
--shadow-1: 0 1px 2px rgba(20,15,10,.06)                            /* card lift */
--shadow-2: 0 8px 20px rgba(20,15,10,.08),
            0 2px 6px  rgba(20,15,10,.05)                           /* sheet */
--shadow-3: 0 20px 40px rgba(20,15,10,.10),
            0 8px 16px  rgba(20,15,10,.06)                          /* modal */
--shadow-focus: 0 0 0 3px rgba(108,143,180,.35)                     /* keyboard focus */
--shadow-accent-halo: 0 0 0 4px rgba(122,47,43,.12)                 /* current milestone dot */
```

No `filter: drop-shadow` on text.

### 2.9 Motion

```
--ease-out:  cubic-bezier(0.22, 1, 0.36, 1)
--ease-in:   cubic-bezier(0.5, 0, 0.75, 0)
--ease-inout:cubic-bezier(0.65, 0, 0.35, 1)

--dur-fast:   150ms   /* small state (hover) */
--dur-med:    260ms   /* enter/exit for cards, chips */
--dur-slow:   420ms   /* screen transitions */
--dur-loading:2600ms  /* loading screen (sign-in → arrival) */
--dur-drift:  22s     /* video-layer ambient drift */
```

Motion vocabulary:
- **Rise** — enter with `translateY(6px) → 0` + opacity 0 → 1, `dur-med`
- **Cross-fade** — screen transitions, `dur-slow`
- **Press** — 40ms scale to 0.98 then release
- **Breath** — recovery-index cards, subtle 6s opacity 0.85 ↔ 1
- **Drift** — sign-in ambient, `dur-drift` looped alternate

Reduced motion: all `translate`/`scale` animations disabled, opacity fades preserved at half duration.

### 2.10 Z-index

```
--z-base:    0
--z-sticky:  10   /* topbar, tabbar */
--z-sheet:   30
--z-modal:   40
--z-toast:   50
--z-concierge:60 /* floating button */
--z-overlay: 70  /* scrims */
```

---

## 3. Grid & layout

- Mobile: 4-column implicit, 20–28px page padding
- Tablet: 8-column, 32px page padding, max-width 640
- Desktop: 12-column, max-width 720 for member app screens (mobile-first), 1120 for marketing
- Vertical spacing driven by tokens, not fractional %.
- Cards: 20px side padding by default, 24–26px on hero cards.
- Never use full-bleed cards on desktop; keep card corners visible.
- Safe area: honor `env(safe-area-inset-*)` on the top and bottom bars.

---

## 4. Iconography & imagery

### 4.1 Icons

- **Line icons only**, 1.4 stroke, rounded caps/joins.
- 20 × 20 default, 24 for tab bar, 16 for inline.
- No filled icons. No colored icons. Icon color inherits `currentColor`.
- Icon library: Lucide as the base; custom SVGs for ritual, ice, sauna, contrast, breathwork glyphs.

### 4.2 Imagery

- Photography is the primary emotional carrier.
- **Do**: macro textures (steam on glass, water on skin, linen folds, warm light on stone), moments of stillness, hands and posture over faces where possible.
- **Don't**: stock gym imagery, staged smiles, before/after, aspirational body shots, neon lighting.
- Photo treatment: warm shadows, slightly reduced saturation (~85%), a whisper of grain (< 5%), no vignette.
- Aspect ratios: 4:5 portrait for ritual and class hero; 3:2 landscape for editorial; 1:1 for tiles.

### 4.3 Gradients

Use only for the ambient sign-in / loading layers, and for tile placeholders. Never for buttons or cards.

---

## 5. Component inventory (V1)

Grouped by concern. Numbered for reference in this document and the Storybook.

**Structure**
1. `AppShell`, `PhoneFrame` (preview only)
2. `Topbar`, `Tabbar`
3. `Screen`, `Section`, `Sheet`, `Modal`, `Toast`

**Actions**
4. `Button` (primary, ghost, outline, outline-light, destructive)
5. `IconButton`
6. `Chip` / `Filter`

**Content**
7. `Card` (surface, hero, dark)
8. `RitualCard`
9. `ClassCard`
10. `ServiceTile`
11. `CompStep` + `CompLine`
12. `TimelineItem` + `TimelineTrack`
13. `StatCard`
14. `PairCard` (Paradiso pairing)
15. `Whisper`

**Inputs**
16. `TextField`, `PasswordField`, `EmailField`
17. `TimePicker`, `DatePicker` (day-first)
18. `Segmented`, `Toggle`, `Checkbox`, `Radio`
19. `Slider` (rare — sauna temp preference)

**Feedback**
20. `Skeleton`, `Spinner`, `LoadingScreen`
21. `EmptyState`
22. `ErrorState`
23. `ConfirmDialog`

**Concierge**
24. `ConciergeFAB` (floating action button)
25. `ConciergeMessage` (member, system, action)
26. `ConciergeAction` (structured recommendation card)

**Domain-specific**
27. `PickerRow` (evening picker)
28. `Countdown` (slot-hold)
29. `RecoveryIndexBand` (Steady / Rising / Below)
30. `MilestoneBadge`

---

## 6. Component specs

### 6.1 Button

**Variants**: `primary` · `ghost` · `outline` · `outline-light` · `destructive-quiet`
**Sizes**: `md` (default) · `lg`
**Shapes**: pill (default), block (full-width)

| State | Primary | Ghost | Outline |
|---|---|---|---|
| Rest | bg `--ink` fg `--fg-inverse` | transparent fg `--fg-secondary` | transparent 1px `--border-strong` fg `--fg-primary` |
| Hover | bg #000 | bg `--bg-surface-hover`, fg `--fg-primary` | bg `--bg-surface` |
| Press | scale .98 40ms | scale .98 | scale .98 |
| Focus | + `--shadow-focus` | + `--shadow-focus` | + `--shadow-focus` |
| Disabled | bg `--stone-500` fg `--sand-100`, opacity .55 | fg `--fg-placeholder` | border `--border-soft` fg `--fg-placeholder` |
| Loading | text opacity 0, inline spinner centered |

Padding: 15/20 (md), 18/24 (lg). Radius: pill. Font: Inter 500 14/15px.

No shadow on default state.

Accessibility:
- `role="button"`, keyboard `Enter`/`Space`
- `aria-disabled` on disabled (never `pointer-events: none` without ARIA)
- Loading: `aria-busy="true"`, label unchanged, spinner is decorative

### 6.2 IconButton

36 × 36 hit area minimum, 24 icon inside. Background transparent by default; on hover, `--bg-surface`. Round. Focus ring uses `--shadow-focus`. Required `aria-label`.

### 6.3 Chip / Filter

**Chip** (informational): 6/14 padding, `--bg-surface`, 1px `--border-soft`, 14px Inter 500. No hover.
**Filter** (interactive): same base, hover `--bg-surface-hover`, active `--ink` bg / `--fg-inverse` text. Toggleable.

### 6.4 Card

Three flavours:
- `surface` — `--bg-surface`, 22px radius, no border by default, optional hairline
- `hero` — 24–26px padding, subtle inner border, uses larger heading
- `dark` — `--bg-inverse` bg, used sparingly for the Annual Wellness card and premium invites

Cards do not have their own shadow at rest. A `raised` prop enables `--shadow-1` for float variants.

### 6.5 RitualCard

Props: `title`, `duration`, `eyebrow`, `steps[]`, `primaryCta`, `secondaryCta`.
Layout: eyebrow + duration row → title (Fraunces h2) → step list → CTA stack (vertical on mobile, horizontal on tablet+).
Step item: `01` numeral (Fraunces 14), `name` (Fraunces 18), `meta` (Inter 14 stone-600). Divider hairline between.

### 6.6 ClassCard

Two flavours:
- **Compact** (horizontal scroll) — 168px wide, image 78px, time / name / meta / availability badge
- **Wide** (schedule day-view) — full-width, image on left 96×96, right column with name, coach, meta, chips (intensity, pillar), CTA

Availability badge:
- `open` — sage
- `low` — sunset
- `full` (with waitlist offer) — maroon outline

### 6.7 ServiceTile

Grid item for on-demand recovery services. Layout: glyph (40×40 tinted square) → name (Fraunces 15) → meta (Inter 12). Whole tile is a button. Six colour tints (ice / sauna / steam / contrast / stretch / breath) driven by the service's brand.

### 6.8 CompStep + CompLine

Composition rows on ritual detail. `CompStep`: `56px time column` (Fraunces 30, tabular numerals) + `content` (name, meta). `CompLine`: 20px vertical hairline aligned with time column left edge. Used to visually connect steps as a single sequence.

### 6.9 TimelineItem + TimelineTrack

`TimelineTrack` renders a vertical 1px gradient rail. `TimelineItem` variants:
- `default` — 15px stone-outlined dot
- `current` — filled maroon dot + `--shadow-accent-halo`
- `milestone` — italic title, maroon color
- `origin` — solid ink dot

Content: `date` (eyebrow), `title` (Fraunces 18), optional `note` (Inter 14 stone-600).

### 6.10 StatCard

Two-column grid tile. `stat-num` (Fraunces 28), `stat-lbl` (Inter 12 medium), optional `stat-note` (italic Inter 12 stone-500).

### 6.11 PairCard

60×60 circular thumb + text: eyebrow ("Paired with"), name (Fraunces 17), meta (Inter 13). `--bg-surface` background. Non-interactive by default; button variant for orderable items.

### 6.12 Whisper

The most brand-critical card. Sections:
1. **Attribution row** — avatar (34×34, maroon bg, first initial in Fraunces) + name + role
2. **Body** — Fraunces 16 italic, `--ink-2`, letter-spacing −0.01em
3. Optional **inline action row** — up to two small links styled as `Button ghost sm`

Card: `--bg-surface` (light) or `--bg-inverse` (rare), left border 3px `--accent`. 22px radius. No shadow.

### 6.13 TextField / EmailField / PasswordField

Understated. `--bg-surface` background, no border by default. On focus, a 1px `--focus-ring` inset appears. Placeholder in `--fg-placeholder`.
- Label above the field, `--text-xs` eyebrow style
- Hint below in Inter 12 stone-500
- Error: replace hint with `--danger-500` text, no red background flash

Radius 14. Padding 14/16. Font Inter 15.

### 6.14 TimePicker / DatePicker

Day-first: horizontal chips with `Tonight / Tomorrow / Friday`, each showing `p-day` (small label) and `p-time` (Fraunces 18 tabular). Active chip flips to `--ink` background. If more options exist, an *"Other times"* ghost button opens a sheet with a full-day picker.

### 6.15 Segmented / Toggle / Checkbox / Radio

Segmented: pill container, 4px inner padding, active pill `--ink` background.
Toggle: 44×24 track, 20 knob. Rest `--stone-400`, active `--accent`.
Checkbox / Radio: 20×20, 2px `--border-strong` border, filled `--ink` when checked; check glyph in `--fg-inverse`. No animated bounce.

### 6.16 Skeleton / Spinner / LoadingScreen

- **Skeleton**: shimmering `--sand-100` block, `--dur-drift` shimmer.
- **Spinner**: 16 default, 20/24 sizes, `currentColor`, 1.5 stroke, one-second rotation.
- **LoadingScreen**: full-screen cinematic; specialised for sign-in and long transitions; copy per Phase 4 §2.4.

### 6.17 EmptyState / ErrorState

Composition: eyebrow (rare), Fraunces h3, one line body, one CTA. Never illustrations of characters. Optional single line-icon at 32.

**Empty state examples**
- No classes today: *"A quiet day. Try tomorrow — or hold a ritual for the evening."* [See tomorrow]
- No timeline yet: *"Your journey begins with your first ritual."* [See rituals]

**Error state examples**
- Reservation failed: *"That didn't hold. It's on us — try again in a moment."* [Try again]
- Payment: *"Your bank didn't clear the charge. We'll try again tomorrow — or update your card."* [Update card]

Never *"Oops"*, *"Something went wrong"*, or generic 404 humor.

### 6.18 ConfirmDialog

Modal with h3 title, body paragraph, two buttons (primary + ghost). Uses `--shadow-3`. Body copy must state consequence in one sentence, not two.

### 6.19 Sheet

Bottom sheet, 22px top corners, drag handle 40×4 stone-400. Content padded 24/28. Backdrop `rgba(20,15,10,.35)`. Escape closes; swipe-down closes. Focus trapped inside while open.

### 6.20 Toast

72px height max, `--shadow-2`, `--bg-inverse` background, `--fg-inverse` text, 14 Inter. Auto-dismiss 4s (5s if it has an action). Optional single ghost action. Never used for errors that require action — those become modals.

### 6.21 ConciergeFAB

Floating 56×56 pill (rectangular pill 56×32 on desktop) bottom-right, 20px from screen edge, `--z-concierge`. Icon glyph + optional 8×8 dot indicator when a whisper is pending. Attribution-first: on tap, opens Concierge sheet.

### 6.22 ConciergeMessage

Three variants:
- **From member** — right-aligned, `--bg-surface` bubble, `--fg-primary`
- **From concierge (attributed)** — left-aligned, avatar + name row + Fraunces italic body
- **System** — centered, `--fg-muted`, italic

Bubbles have 18px radius, tight tail-less corner on origin side.

### 6.23 ConciergeAction

Structured recommendation card rendered inline in the conversation. Layout: eyebrow (e.g. "Suggested hold"), Fraunces 17 title (e.g. "Recovery Reset — Friday 7:30"), meta line (duration, location), and two buttons: primary confirm + ghost decline. Never renders raw JSON.

### 6.24 PickerRow

Container for chip-based selection. Grid `1fr 1fr 1fr` at ≤3 options, horizontal scroll beyond. Each chip: two-line (day, time), `--bg-surface` at rest, `--ink` when active. See 6.14.

### 6.25 Countdown

Inline "Held for you until 6:47" component. Tabular numerals, updates every second, changes to `--accent` color in the final 30s. No exclamation.

### 6.26 RecoveryIndexBand

Small horizontal 3-band indicator: `Below · Steady · Rising`. Current band bolded; the other two dimmed. No numeric score is ever shown at member level.

### 6.27 MilestoneBadge

Fraunces italic label with a leading 6px maroon dot. Used inline in Timeline for milestone titles.

---

## 7. Interaction states — base contract

Every interactive element must implement:

| State | Visual delta | Aria |
|---|---|---|
| Rest | base | — |
| Hover (pointer) | subtle bg or color shift | — |
| Focus-visible (keyboard) | `--shadow-focus` ring | — |
| Press | scale .98 40ms | — |
| Active/selected | strong bg or color shift | `aria-pressed`/`aria-selected` |
| Disabled | opacity .55 + non-interactive | `aria-disabled="true"` |
| Loading | busy indicator | `aria-busy="true"` |
| Error | inline error text; never red flash | `aria-invalid`, `aria-describedby` |

Touch targets ≥ 44 × 44 px. Never rely on hover for critical affordance.

Focus-visible only on keyboard nav (`:focus-visible`); mouse click does not produce a persistent ring.

---

## 8. Accessibility contract

- **WCAG 2.2 AA** everywhere. AAA where copy is small (< 14px) — use `--stone-600` minimum.
- **Reduced motion** — honor `prefers-reduced-motion: reduce`: disable translate/scale animations, keep opacity fades halved.
- **Color independence** — no state expressed by color alone (availability chip has a word too).
- **Keyboard** — every action reachable via Tab; Escape closes sheets and modals; Enter and Space activate buttons.
- **Screen reader** — attribution row of a Whisper reads as *"Note from Ritika, Recovery Coach: …"*. Timeline items read *"date, title, note"*.
- **Form errors** — associated with the field via `aria-describedby`; live region announcement on submit failure.
- **Language** — root `lang="en"`; ready for `lang="hi"` and `lang="mr"` later.
- **Landmarks** — one `<main>`, `<nav>` for tab bar, `<header>` for topbar.
- **Alt text** — every meaningful image; hero ambient images may be `alt=""` (decorative) provided context is on the page.
- **Skip link** — hidden until focused, jumps to main content.

Automated: axe-core in CI on Storybook stories.
Manual: monthly VoiceOver + TalkBack pass on the primary flows.

---

## 9. Motion contract

- Default easing `--ease-out` for enter, `--ease-in` for exit.
- No overshoot, no elastic, no bounce.
- Screen transitions: 300ms cross-fade; direction only when semantically meaningful (drill-in from ritual list to ritual detail: 240ms slide-in from right, 8px).
- Micro-interactions: hover 150ms; press 40ms.
- Recovery Index breath: 6s cycle, 0.85 → 1 → 0.85 opacity on the surface, not the text.
- Loading screen: cross-fade 400ms in and out; ambient drift 22s alternating.
- Reduced motion:
  - Slides become crossfades.
  - Breath disabled.
  - Loading screen visual retained but drift paused, bar animated slower.
  - Countdown continues to update (informational, not decorative).

---

## 10. Content patterns

### 10.1 Empty state anatomy
- Eyebrow (optional)
- Fraunces headline (< 8 words)
- One line of body
- One CTA
- No illustration; optional single line icon

### 10.2 Error state anatomy
- Fraunces headline stating what didn't happen, warmly
- Body: what to try, in the member's language
- Primary CTA to retry / fix
- Optional ghost CTA "Talk to Concierge"

### 10.3 Loading anatomy
- Full-screen only for sign-in and long transitions
- Inline skeletons preferred elsewhere
- Loading copy is always specific ("preparing your evening"), never generic

### 10.4 Success anatomy
- Quiet confirmation. No celebration animation.
- Fraunces h3 confirmation ("Reserved for Friday, 7:30")
- One-line meta, one-line policy note
- Two CTAs max: Add to calendar (primary), View reservation (ghost)

### 10.5 Attribution
- Names appear before pronouns
- "Note from Ritika" > "Ritika says"
- Role appears smaller, below the name

### 10.6 Numbers
- Tabular numerals
- Never round hours to fake "45 min" if actual is 42; be honest
- Ranges use en dash "3–8 min"

---

## 11. Component API contract

Next.js 14 + React 18 + TypeScript + Tailwind + shadcn-ui base + Radix primitives where accessibility is delicate (Dialog, Popover, Sheet). Component names in PascalCase; props strongly typed.

### 11.1 Prop conventions

- `variant`, `size`, `tone` are the primary style props.
- `as` prop for polymorphism (`<Button as={Link}>`).
- Slot props: `leading`, `trailing`, `header`, `footer`.
- Async states: `loading`, `disabled`, `error`.
- Analytics: components accept `data-event` and auto-emit `component_interacted` with `component`, `variant`, `event`.

### 11.2 Example — Button

```tsx
type ButtonProps = {
  children: ReactNode
  variant?: 'primary' | 'ghost' | 'outline' | 'outline-light' | 'destructive-quiet'
  size?: 'md' | 'lg'
  block?: boolean
  loading?: boolean
  disabled?: boolean
  leading?: ReactNode
  trailing?: ReactNode
  as?: ElementType
  href?: string
  onClick?: MouseEventHandler
  'data-event'?: string
  'aria-label'?: string
}
```

### 11.3 Example — Whisper

```tsx
type WhisperProps = {
  attribution?: {
    name: string
    role?: string
    avatarInitial?: string
    avatarSrc?: string
  }
  body: string          // Fraunces italic renders automatically
  action?: {
    label: string
    onClick: () => void
  }
  tone?: 'light' | 'inverse'
}
```

### 11.4 Example — ConciergeAction

```tsx
type ConciergeActionProps = {
  eyebrow: string             // "Suggested hold"
  title: string               // "Recovery Reset — Friday 7:30"
  meta?: string[]             // ["50 min", "Sanctuary Vasant Kunj"]
  primary: { label: string; onConfirm: () => Promise<void> }
  secondary?: { label: string; onDecline: () => void }
  disabled?: boolean
}
```

### 11.5 Composition example — Arrival hero

```tsx
<Screen name="arrival">
  <Topbar brand="SANCTUARY" trailing={<ConciergeFAB inline />} />
  <Section pad="lg">
    <Eyebrow>Wednesday · Evening</Eyebrow>
    <Heading level={1}>
      Good evening, <em>Yuvraj</em>.
    </Heading>
    <Lede>You've recovered well since Tuesday.</Lede>
  </Section>
  <RitualCard {...todaysRitual} />
  <ClassStrip title="Classes today" items={classes} />
  <ServiceGrid title="Recovery, on demand" items={services} />
  <Whisper {...ritikaWhisper} />
  <StatRow items={[recoveryStat, visitsStat]} />
  <AmbientFooter city="Delhi" weather="22°C · dry" water="1.4 L logged" />
  <Tabbar current="arrival" />
</Screen>
```

### 11.6 State management

- **Server state**: TanStack Query on top of Supabase / API routes. All reservation writes are optimistic with rollback on failure.
- **Client state**: Zustand for ephemeral UI (sheet open, active tab, slot-hold countdown).
- **URL state**: query params for filters (`/sanctuary/classes?pillar=movement&intensity=hard`).
- No global Redux.

### 11.7 Theming

CSS variables on `:root`. A single `data-theme="night"` attribute switches sign-in / loading surfaces to the dark set. No full dark mode in V1 to preserve the warm-neutral identity; revisit at V2.

---

## 12. Naming & file structure

```
apps/
  web/               # Next.js member app
  admin/             # Ops console
  staff/             # Tablet check-in (subset of web at V1)
packages/
  tokens/            # Design tokens (JSON → CSS vars, JS constants)
  ui/                # Component library
    src/
      button/
      card/
      whisper/
      ritual-card/
      class-card/
      service-tile/
      timeline/
      concierge/
      forms/
      layout/
      motion/        # motion primitives (Rise, Crossfade, Breath)
      icons/
    index.ts
  config/            # eslint, tsconfig, tailwind preset
  api/               # generated types from Supabase
```

Component files:
- `button.tsx` — component
- `button.stories.tsx` — Storybook
- `button.test.tsx` — vitest + testing-library
- `button.css.ts` — vanilla-extract OR `button.module.css` (choose one; recommend Tailwind class recipes via `cva`)

Storybook covers all variants + states + edge cases + reduced-motion + dark-surface stories.

---

## 13. Review checklist — Phase 5

Please confirm before Phase 6 (API & Endpoint Spec):

- [ ] The **color palette** (sand / stone / ink + maroon accent, sage/sunset/dawn status) is right for the brand
- [ ] The **two-family typography** (Fraunces + Inter) is final, or we should evaluate one alternative (Editorial New, Söhne, GT Sectra)
- [ ] The **motion vocabulary** (Rise / Cross-fade / Press / Breath / Drift) is at the correct restraint level
- [ ] The **component inventory** (≈30 components) covers V1, or we're missing something
- [ ] The **API prop conventions** (variant/size/tone/as/slots) fit the team's coding style
- [ ] The **accessibility contract** (WCAG 2.2 AA + reduced motion + axe in CI) is committed
- [ ] The **file structure** (monorepo apps/web + apps/admin + packages/ui + packages/tokens) matches the intended repo shape
- [ ] The **Concierge components** (FAB, Message, Action) capture the LLM interaction model from Phase 4 §7

## Open questions

1. **Component library base** — I've proposed shadcn-ui + Radix (headless a11y primitives, restyle in our tokens). Alternative: build every primitive ourselves. Trade-off is speed vs. control.
2. **Styling engine** — Tailwind with `cva` recipes, or vanilla-extract, or CSS modules? All three work; recommend Tailwind + `cva` for team velocity.
3. **Icon library** — Lucide as the base plus custom SVGs for domain glyphs, or fully custom set from day one? Recommend Lucide base.
4. **Photography source** — commissioned brand shoot at Vasant Kunj, or curated licensed library at launch and shoot afterward? Recommend a small commissioned shoot pre-launch (5–7 hero images).
5. **Dark surface scope** — Sign-in + loading only, or also introduce a night mode for the app after 22:00? V1 recommendation: sign-in + loading only.
6. **Design tool** — Figma library mirroring `packages/ui` tokens and components. Confirm Figma is the source of truth for visuals (I'll assume yes).

## Hand-off to Phase 6

Once approved, Phase 6 (API & Endpoint Spec) will define:
- REST + RPC surface per domain (auth, members, rituals, classes, reservations, concierge, membership, payments, timeline)
- Request/response schemas (Zod-typed)
- Auth model (Supabase JWT + row-level policies referenced back to Phase 3)
- Rate limits, idempotency keys, retry semantics
- Webhook contracts (Razorpay, WhatsApp BSP)
- Concierge LLM call contract (request shape, structured actions, safety hooks)
