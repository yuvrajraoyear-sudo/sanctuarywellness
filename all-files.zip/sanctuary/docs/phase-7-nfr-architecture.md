# Phase 7 — Non-Functional Requirements & Architecture

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

The system's promises about reliability, performance, security, compliance, and cost. Whereas prior phases described *what* the app does, this phase describes *how well it must do it, at what cost, and on what physical substrate*.

Sections:
1. Reliability & SLOs
2. Performance budgets
3. Environment topology & regions
4. Data architecture, backups & DR
5. Security posture
6. Privacy & compliance (DPDP, GST, RBI, health data)
7. Cost model at 1k / 5k / 20k members
8. Deployment topology & CI/CD
9. Feature flags, migrations, rollout
10. Capacity & scalability plan
11. Review checklist

---

## 1. Reliability & SLOs

### 1.1 Availability targets

| Surface | Availability | Error budget / 30d |
|---|---|---|
| Member web app | 99.9% | 43 min |
| Public marketing site | 99.95% | 22 min |
| Staff tablet | 99.5% | 3h 39m |
| Ops console | 99.5% | 3h 39m |
| Webhook receivers | 99.95% | 22 min |
| Concierge LLM | 99.0% | 7h 12m (soft) |

Concierge is graceful-degradation, not hard-critical. When it's down, whispers are suppressed, conversations return `dependency_down`, and the app shows *"Concierge is stepping away for a moment — we'll come find you."* Reservations do not depend on the LLM.

### 1.2 SLIs

| SLI | Target |
|---|---|
| GET p95 latency | < 300 ms |
| Mutation p95 latency (reservation, cancel) | < 800 ms |
| Auth challenge → email delivery | < 5 s p95 |
| Webhook ingest ack | < 500 ms p95 |
| WhatsApp send → delivered | < 30 s p95 |
| Concierge whisper compose | < 6 s p95, < 12 s p99 |
| Concierge conversation turn | < 3 s p95, < 6 s p99 |
| Slot-hold consistency | 100% (never oversell) |
| Reservation double-book rate | 0 |

Slot consistency is non-negotiable — enforced by Postgres row-locks + a `unique (session_id, seat_index)` constraint on `reservation_slots`.

### 1.3 Incident severities

| Sev | Definition | Response | Comm |
|---|---|---|---|
| Sev-1 | Booking down, member data exposure, payment charging incorrectly | Page on-call in 5 min | Status page + email to all members within 30 min |
| Sev-2 | Auth broken, Concierge safety path failing, mass notification failure | Page on-call in 15 min | Status page |
| Sev-3 | Non-critical bug on one flow, one integration degraded | Assign next business day | Internal only |
| Sev-4 | Cosmetic / non-blocking | Backlog | — |

Status page: `status.sanctuary.playhaus.club`. Public.

### 1.4 Postmortems

Every Sev-1 and Sev-2 gets a blameless postmortem within 5 business days. Template: what happened, timeline, root cause, contributing factors, remediation with owners and due dates, changes to prevent recurrence. Filed in `docs/incidents/`.

---

## 2. Performance budgets

Performance is a brand attribute. Slow = not premium.

### 2.1 Page-level budgets (member web)

| Page | LCP | INP | TTFB | JS shipped | CLS |
|---|---|---|---|---|---|
| Sign-in | < 1.8 s | < 200 ms | < 400 ms | < 90 KB gz | < 0.05 |
| Arrival | < 2.0 s | < 200 ms | < 500 ms | < 140 KB gz | < 0.05 |
| Ritual detail | < 2.2 s | < 200 ms | < 500 ms | < 160 KB gz | < 0.05 |
| Class list | < 2.0 s | < 200 ms | < 500 ms | < 150 KB gz | < 0.05 |
| Concierge | < 2.0 s | < 250 ms | < 500 ms | < 180 KB gz | < 0.05 |

Measured with Core Web Vitals on **mid-tier Android (Moto G Power) on 4G**, 75th percentile.

### 2.2 Techniques

- Server components by default; client components only where interactive.
- Route-level code split.
- Font subsetting: Fraunces + Inter, latin subset only, `font-display: swap`.
- Images: AVIF/WebP with responsive srcsets; no image over 200 KB on member web.
- Above-the-fold data: streamed via RSC or hydrated with initial payload; below-the-fold: `useQuery` after mount.
- CDN cache for public catalog (rituals, classes list, coaches). Stale-while-revalidate 60 s.
- No client-side data fetching waterfalls; parallelise via TanStack Query key-batching.

### 2.3 Backend

- Postgres p95 query time < 40 ms on hot paths (`sessions` fetch, `reservations` insert).
- N+1 detection via `pg_stat_statements`; failed builds if any hot endpoint exceeds 3 queries.
- Connection pooling via Supabase Pooler / PgBouncer transaction mode.

### 2.4 Realtime

- WebSocket presence for staff tablet dashboard; graceful poll-fallback at 15 s if WS unavailable.
- Message fan-out latency (server → client) p95 < 300 ms.

---

## 3. Environment topology & regions

### 3.1 Regions

- **Primary:** ap-south-1 (Mumbai). All member and health data resides here.
- **Edge:** Cloudflare global for static assets, images, DNS, WAF.
- **DR standby:** ap-southeast-1 (Singapore) — cold standby for Postgres logical replica; warm in Phase 2 of scale.

Data residency: DPDP compliance requires personal and health data to be processed in India. Vendors used must offer ap-south-1 or an equivalent Indian region.

### 3.2 Stack

| Concern | Choice |
|---|---|
| Web hosting | Vercel (edge functions + serverless) — with fallback plan to Cloudflare Pages/Workers if data-locality becomes an issue |
| Database | Supabase Postgres 15, ap-south-1 |
| Object storage | Supabase Storage (S3-compatible) for photos, invoice PDFs |
| Cache | Upstash Redis (ap-south-1) — session-scoped caching, rate-limit counters |
| Realtime | Supabase Realtime |
| Search | Postgres FTS at V1; consider Meilisearch/Typesense at 5k+ |
| Email | Resend (ap-south-1 or eu-west-1) |
| SMS / WhatsApp | Gupshup (Bengaluru) or AiSensy (Delhi) |
| Payments | Razorpay (Bangalore) |
| Analytics (product) | PostHog (self-hosted in ap-south-1 or PostHog Cloud EU with data-residency addon) |
| Analytics (marketing) | Plausible or Fathom (privacy-first, cookieless) |
| Error tracking | Sentry (EU or India tenant) |
| Logs | Grafana Loki (self-hosted) or Better Stack (India POP if available) |
| Tracing | OpenTelemetry → Grafana Tempo |
| Feature flags | PostHog feature flags (share with analytics) |
| LLM | See §Phase 8 |

### 3.3 Environments

- `local` — every developer, seeded database
- `preview` — every PR gets a Vercel preview + shadow schema in a Supabase branch
- `staging` — mirrors prod schema, synthetic data, integration sandbox for Razorpay and WhatsApp
- `prod`

Traffic to preview and staging is protected by Cloudflare Access + basic auth.

---

## 4. Data architecture, backups & DR

### 4.1 Storage tiers

- **Operational Postgres** — transactional data
- **Object storage** — invoices (immutable PDFs), member avatars, ritual imagery
- **Analytics** — periodic dumps to a warehouse (Postgres → daily Parquet in object storage; loaded into DuckDB or BigQuery for ops queries)

### 4.2 Backups

- **Continuous WAL** archiving to object storage, 15-min RPO
- **Point-in-time recovery** for the last 30 days
- **Nightly logical dumps** retained 90 days, encrypted with per-day key
- **Quarterly cold archive** to a separate account (immutable, 7-year retention for GST / tax records only — personal data stripped or replaced with tokens)

### 4.3 RTO / RPO

| Failure mode | RPO | RTO |
|---|---|---|
| Single Postgres node | < 1 min | < 15 min (failover) |
| Region outage | < 15 min | < 4 h (promote Singapore standby, DNS cutover) |
| Object storage outage | 0 (redundant) | < 2 h |
| Vercel outage | 0 | < 1 h (Cloudflare failover to static app shell + read-only mode) |
| Total data loss | < 24 h | < 8 h (restore from cold archive) |

### 4.4 Read-only degraded mode

If DB is unreachable but the app is up: the app enters *read-only mode* — members can browse their timeline (from CDN-cached page), rituals list, but any mutation returns *"We're stepping away for a moment. Try again shortly."* Staff tablet can view today's reservations from a snapshot exported hourly to object storage.

---

## 5. Security posture

### 5.1 Principles

- **Least privilege everywhere.** RLS by default; service-role only in short-lived jobs.
- **Defense in depth.** WAF (Cloudflare) → app → API → RLS → row-level checks in Postgres functions.
- **Secrets in Vault.** Doppler / Infisical / 1Password Vault. No secrets in code, in Vercel env, or in CI logs. Injected at deploy time.
- **Encryption.**
  - At rest: Postgres AES-256, object storage AES-256, Redis TLS.
  - In transit: TLS 1.3 everywhere. HSTS with preload.
  - Field-level: `member_health.notes` and `concierge_messages.text` encrypted with a KMS key (envelope encryption) — only accessible to ops role.
- **No PII in logs.** Redactor at log adapter (email, phone, address, health flag).
- **CSP.** Strict CSP with nonces on inline scripts; no `unsafe-eval`.
- **CORS.** Origin allow-list per environment; no `*`.
- **CSRF.** Not applicable for pure JWT flows; refresh cookie uses SameSite=strict + double-submit token.
- **Auth token rotation.** Refresh tokens rotate on every use; theft-detection cancels the family.
- **Rate limits & bot protection.** Cloudflare Turnstile on `POST /auth/challenge`, `POST /join`, `POST /guest/{token}/claim`.

### 5.2 OWASP Top-10 stance

| Risk | Mitigation |
|---|---|
| Broken access control | RLS + endpoint-level checks + integration tests per role |
| Cryptographic failures | KMS envelope encryption for health notes; TLS 1.3; no bcrypt on the client |
| Injection | Zod validation on every input; parameterised queries; no dynamic SQL |
| Insecure design | Threat model per feature (documented in Phase 15) |
| Security misconfig | IaC (Terraform); reviewed diffs; scanned with `tfsec`/`checkov` |
| Vulnerable dependencies | Renovate + `npm audit` + Snyk in CI; monthly bump PR |
| ID & auth failures | Supabase Auth + passkey; step-up for critical paths |
| Software / data integrity | Signed webhooks; content hashes on migrations |
| Logging & monitoring gaps | OTel + Sentry + Grafana; SLO alerts |
| SSRF | No user-supplied URLs fetched server-side; if needed later, use a proxy allow-list |

### 5.3 Secrets categorisation

- **Class A** (kill switches): Razorpay live key, WhatsApp BSP key, LLM API key. Rotated quarterly; access limited to founding engineers + platform lead.
- **Class B**: Service role Postgres key, Cloudflare API token. Rotated bi-annually.
- **Class C**: Third-party read-only keys. Rotated annually.

### 5.4 Pentest & audit

- External pentest annually and before every major surface addition (payments, health integrations).
- Bug bounty (private, then public at 5k+ members).
- SOC 2 Type 1 targeted at Year-2 if enterprise / corporate wellness partnerships materialise.

---

## 6. Privacy & compliance

### 6.1 DPDP Act 2023 (India)

- **Data principal rights:** access, correction, erasure, portability, grievance redressal.
- **Consent artefacts:** every consent (T&Cs, health, marketing, photography) is recorded in `consent_records` with version, timestamp, evidence (IP + user-agent), and withdraw-audit trail.
- **Consent granularity:**
  - Necessary (T&Cs, health-for-safety) — pre-checked, cannot be withdrawn without account closure
  - Marketing (WhatsApp, email newsletters) — opt-in, freely withdrawable
  - Analytics beyond product improvement — opt-in
  - Photography at premises — opt-in per session; guests re-consent each visit
- **Data Protection Officer:** appointed; contact in privacy policy and status page.
- **Cross-border transfers:** minimised. Where unavoidable (Sentry EU, Resend EU), contractual clauses + risk assessment retained.
- **Breach notification:** 72h to Data Protection Board of India (once operational rules are notified) + affected members.
- **Grievance:** in-app + email + phone; 30-day response target.

### 6.2 Health data (special category)

- Treated at the highest tier of protection.
- Stored encrypted; visible only to member + assigned trainer + on-duty coach at check-in.
- Never used for marketing.
- Excluded from analytics dumps beyond aggregate.
- Retention: kept for the lifetime of membership + 24 months after off-boarding. On erasure request, categorical flags are retained (audit only) with all free-text removed.

### 6.3 GST

- Registered in Delhi; GST at applicable rate on services (18% currently for gym / spa; specific carve-outs for physiotherapy).
- Invoices carry GSTIN, HSN/SAC codes, place-of-supply, invoice number, date.
- Reverse charge on eligible expenses.
- Monthly GSTR-1 + GSTR-3B; annual GSTR-9. Handled by accounting team, data exported from `invoices`.

### 6.4 RBI e-mandate

- Recurring plans use RBI-compliant e-mandate flow: pre-debit notification 24h before charge, member consent to variable amount limit, cancellation any time.
- Card renewals honour AFA (Additional Factor of Authentication) requirements for auto-debits above the standing threshold.

### 6.5 Photography, testimonials, likeness

- Consent per session; can be withdrawn.
- Withdrawal removes future publication rights and triggers takedown for reasonably reachable prior uses.

### 6.6 Trainer / staff data

- Employment records held separately (HR system).
- App-side `trainer_profiles` contains only what the member sees: name, role, bio, avatar, credentials with member consent.

### 6.7 Children (under-18)

- Kids programs (Play Haus Sports) require guardian consent captured at signup with government ID upload.
- No profiling, no marketing to minors, no third-party analytics.

---

## 7. Cost model

Rupees per month, best-effort estimates. Includes 20% buffer.

### 7.1 At 1,000 members (single location, Vasant Kunj)

| Line item | ₹ / month |
|---|---|
| Vercel Pro + edge fn | 3,500 |
| Supabase Pro (Postgres + Realtime + Storage) | 20,000 |
| Cloudflare Pro | 2,000 |
| Upstash Redis | 1,500 |
| Sentry Team | 3,000 |
| PostHog Cloud (India-resident add-on) | 5,000 |
| Resend | 1,500 |
| WhatsApp BSP (250 msgs / member / mo) | 25,000 |
| Razorpay (2% on ₹4.5cr revenue) | 900,000 |
| LLM (Concierge: 20k whispers + 5k conversations) | 15,000 |
| Domain, DNS, misc SaaS | 3,000 |
| Ops tooling (Slack, 1Password, Notion) | 8,000 |
| **Sub-total (variable + fixed)** | **987,500** |
| **Sub-total (excl. Razorpay)** | **87,500** |

Razorpay is variable to revenue and reported separately; ex-Razorpay run-rate matters more for infrastructure planning.

### 7.2 At 5,000 members (two locations)

| Line item | ₹ / month |
|---|---|
| Vercel Enterprise (edge, WAF, higher limits) | 25,000 |
| Supabase Enterprise / self-managed Postgres on GCP ap-south-1 | 90,000 |
| Cloudflare Business | 8,000 |
| Upstash Redis (higher tier) | 6,000 |
| Sentry Business | 10,000 |
| PostHog | 20,000 |
| Resend | 8,000 |
| WhatsApp BSP | 125,000 |
| LLM | 90,000 |
| Ops tooling & extras | 20,000 |
| **Sub-total (ex-Razorpay)** | **402,000** |

### 7.3 At 20,000 members (five locations, super-app)

| Line item | ₹ / month |
|---|---|
| Vercel Enterprise + reserved | 60,000 |
| Postgres (self-managed, HA + replicas) + PgBouncer | 300,000 |
| Cloudflare Business + Turnstile Pro | 20,000 |
| Redis (managed, multi-AZ) | 25,000 |
| Sentry / logs / traces | 50,000 |
| PostHog | 60,000 |
| Resend / SES | 25,000 |
| WhatsApp BSP | 500,000 |
| LLM | 400,000 |
| Search (Meilisearch) | 20,000 |
| Ops tooling | 40,000 |
| **Sub-total (ex-Razorpay)** | **1,500,000** |

Break-even: at ~350 Resident-tier members, infrastructure is fully paid for. This is where the model becomes healthy.

---

## 8. Deployment topology & CI/CD

### 8.1 Pipelines

- **Trunk-based**, one main branch, short-lived feature branches merged via PR.
- **Preview per PR:** Vercel preview + a Supabase branch DB seeded from a scrubbed staging snapshot.
- **CI stages:** lint → typecheck → unit tests → integration tests (against Supabase branch) → build → Storybook build → Chromatic visual diff → axe a11y checks → deploy preview → e2e smoke tests → require reviewer approval → merge.
- **Deploys are automatic** on merge to `main`: staging → 30-min soak with synthetic monitors → production, canary 5% → 25% → 100% over 30 minutes.
- **Rollback in one command:** Vercel instant rollback + `migrate down` for the tail migration if applicable.

### 8.2 Migrations

- Managed by `supabase migration` (SQL).
- Two-phase for destructive changes: additive migration → application deploy → cleanup migration on next release.
- Never dropping columns in the same release that introduces the code that would notice.
- Migration review checklist: rollback plan, expected downtime, lock-taking analysis (`pg_locks`).

### 8.3 Content deploys

Editorial content (marketing site copy, ritual descriptions, class copy) lives in a headless CMS (Sanity or Payload). Publishing is decoupled from code deploys.

### 8.4 On-call

- Two engineers on rotation, weekly.
- Runbooks per known incident type in `docs/runbooks/`.
- On-call handoff every Monday, documented in a Slack thread with any open incidents.

---

## 9. Feature flags, migrations, rollout

- PostHog feature flags, evaluated server-side for stability, client-side for lightweight toggles.
- **Ring rollout:**
  1. Internal ring — team members only
  2. Early access — 50 hand-picked members
  3. 10% traffic
  4. 50% traffic
  5. 100%
- Any feature can be killed via flag in < 1 min.
- Migration order for a feature involving DB + API + UI:
  1. Ship additive migration
  2. Ship API supporting both shapes
  3. Ship UI behind flag
  4. Enable flag ring-by-ring
  5. Once at 100% for 2 weeks, remove old code path
  6. Ship cleanup migration

---

## 10. Capacity & scalability plan

### 10.1 Capacity per surface (per second, sustained)

| Surface | V1 target | Notes |
|---|---|---|
| Reservation POST | 20 rps | Peak on Monday 09:00 IST (weekly release) |
| Sign-in POST | 40 rps | Global evening rush |
| GET catalog | 200 rps | CDN-cached, mostly edge |
| Webhook ingest | 60 rps | Bursty on renewal day |
| Concierge conversation | 5 rps | Naturally slow, LLM-bound |

### 10.2 Scale playbook

- 3k members → add PgBouncer, dedicated Redis for rate-limit counters
- 8k members → read replica for analytics + heavy dashboards
- 15k members → shard by location for `sessions`, `reservations`, `attendance` (composite partitioning by `location_id`)
- 25k members → move Postgres to dedicated tenancy on managed provider (Neon, RDS, or Google Cloud SQL in ap-south-1)

### 10.3 Load testing

- k6 scenarios per critical path, run on every release candidate
- Fault injection (chaos): kill a Postgres replica in staging monthly; verify RTO holds

---

## 11. Review checklist — Phase 7

- [ ] SLO tiers (member web 99.9%, Concierge 99.0%) are calibrated correctly
- [ ] Performance budgets for member web (LCP < 2.0s on mid-tier Android 4G p75) are achievable and enforced in CI
- [ ] Region strategy (ap-south-1 primary, DPDP-compliant vendor list) is complete
- [ ] Backup + DR plan (15-min RPO, < 4h RTO regional) meets business expectations
- [ ] Security posture (RLS + field-level KMS + WAF + strict CSP + secrets in vault) is agreed
- [ ] DPDP + health + GST + RBI compliance approach is committed
- [ ] Cost model at 1k/5k/20k is within business plan
- [ ] Deployment topology (Vercel + Supabase + Cloudflare, ring rollout, one-command rollback) is right
- [ ] Capacity plan and scale triggers are agreed

## Open questions

1. **Hosting locality.** Vercel is not India-resident for compute. Data resides in Supabase ap-south-1, and Vercel's function egress to Supabase adds ~40ms. Do we accept, or move web tier to Cloudflare Workers / Railway with ap-south-1 presence?
2. **Managed Postgres vs. Supabase.** Supabase for velocity today; managed Postgres (Neon / RDS) at ~15k members. Confirm trigger point.
3. **PostHog cloud vs. self-host.** Self-hosting removes vendor lock-in but adds ops load. Recommend PostHog Cloud with India-resident add-on until 5k members.
4. **SOC 2 timing.** Nice-to-have or must-have before enterprise wellness partnerships?
