# Phase 12 — Operations & Staff Enablement

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

The app is one half of Sanctuary. The other half is the twelve people who greet, guide, coach, and clear tea away. This document specifies who they are, what they do, what tools they have, and how they are prepared to represent the brand.

Sections:
1. Org chart at launch
2. Roles and responsibilities
3. Daily rhythm at a location
4. Staff tablet — surfaces
5. Ops console — surfaces
6. Runbooks
7. Training curriculum
8. Physical operations standards
9. Ops SLAs
10. Staffing plan by member count
11. Review checklist

---

## 1. Org chart at launch (Vasant Kunj)

```
Founder / GM (1)
├── Head Coach — Rohan (1)
│   ├── Recovery Coach — Ritika (1)
│   ├── Movement Lead — Meera (yoga/mindfulness) (1)
│   ├── Pilates Lead — Ananya (1)
│   ├── Mobility Lead — Karan (1)
│   ├── Performance Coach — Priya (HYROX/cardio) (1)
│   ├── Combat Coach — Vikram (1)
│   ├── Wellness Coach — Aarav (breath/meditation) (1)
│   └── Physiotherapist (part-time, 3 days/wk) (1)
├── Concierge Ops Lead (1)
│   ├── Front-desk Host — AM (1)
│   ├── Front-desk Host — PM (1)
│   └── Concierge Assistant (WhatsApp/phone follow-up) (1)
├── Paradiso Manager (1)
│   ├── Barista (2)
│   └── Kitchen assistant (1)
├── Facilities Lead (1)
│   ├── Housekeeping (2 shifts × 2 people) (4)
│   └── Maintenance technician (on-call) (1)
└── Product & Tech (shared org)
    ├── Product Lead
    ├── Platform Engineer × 2
    ├── Design Lead
    └── Data / Analytics (0.5 FTE)
```

Total on-site headcount at Vasant Kunj launch: **~22**.

---

## 2. Roles and responsibilities

### 2.1 Front-desk Host

Owns first and last impression. Not a receptionist.

- Greets by name; references last visit
- Handles check-in on the tablet
- Manages guest arrivals, intake, and orientation
- Owns locker readiness and Signature setup at check-in
- Escalates to Concierge Ops for anything beyond scheduling

### 2.2 Concierge Ops (Assistant + Lead)

- Reviews Concierge whispers during Alpha phase (Phase 8 §11)
- Handles WhatsApp session-window conversations
- Owns the safety-event queue
- Coordinates first-visit intros (calls new inquirers)
- Handles cancellations that fall outside self-serve rules
- Escalates to Head Coach on health-related conversations

### 2.3 Head Coach (Rohan)

- Owns the programming calendar with Movement Lead and Recovery Coach
- Reviews training plans for members with health flags
- Signs monthly member letters (unless a guest writer)
- Owns the coach voice audit (§Phase 8 §10.2)
- Runs the Annual Wellness Review

### 2.4 Coaches (Recovery / Movement / Pilates / Mobility / Performance / Combat / Wellness)

- Deliver rituals and classes
- Own their pillar's monthly programming refresh
- Write the whisper attributions for their pillar
- Respond to Concierge conversation handoffs when their pillar is invoked
- Attend weekly training standup

### 2.5 Physiotherapist

- On-site 3 days/week
- Owns injury/rehab conversations
- Reviews members with orthopaedic contraindications
- Signs off on return-to-activity for injured members

### 2.6 Paradiso Manager

- Owns the menu and its language (Phase 11 §8)
- Coordinates order flow from app → kitchen → seating
- Owns member "usuals" and tea/coffee protocols
- Reviews Paradiso reservations paired with rituals

### 2.7 Facilities Lead

- Owns cleanliness cycles (§8.2)
- Owns sauna, plunge, steam, HVAC, lighting, music
- On-call rotation for maintenance emergencies
- Coordinates deep-clean nights (weekly, after close)

### 2.8 GM / Founder

- Owns the member experience across all functions
- Sits in on Annual Wellness Reviews with Head Coach where useful
- Personally writes the farewell notes to departing Resident+ members
- Attends monthly member dinners

---

## 3. Daily rhythm at a location

### 3.1 Pre-open (05:00–06:00)

- Housekeeping deep-check on all suites
- Sauna warm-up: 45 min lead time to target temperature
- Ice bath: chill check
- Paradiso: kitchen and bar prep
- Front-desk: today's day-view opened on the tablet; note-cards pulled for members with milestones or health notes

### 3.2 Open (06:00)

- Morning arrival flow: 06:00 first-ritual members escorted directly
- Music: morning playlist (curated, no vocals)

### 3.3 Mid-day (11:00–16:00)

- Quieter footfall; used for PT/SGT and physio consults
- Facilities: mid-day audit
- Kitchen: prep for evening rush

### 3.4 Evening peak (17:30–21:30)

- Highest ritual and class density
- Front-desk shift change at 17:00 with 30-min handover
- Concierge Ops on duty for real-time WhatsApp
- Facilities: quick turns between classes

### 3.5 Close (22:00–23:00)

- Last ritual ends by 22:00; Paradiso open until 22:30
- Facilities: full clean and reset
- Head Coach or GM does a "walk of the house" nightly

### 3.6 After-close

- Facilities: sauna and plunge maintenance twice-weekly
- Ops: yesterday's feedback reviewed, member notes updated

---

## 4. Staff tablet — surfaces

One physical device per front-desk position and per suite corridor. Uses `apps/staff`.

### 4.1 Screens

- **Day view** — chronological list of check-ins with time, member name, ritual/class, room, coach, prep notes (e.g. "prefers Locker 12", "78°C sauna")
- **Member card** — from the day view, tap to see Signature, health flags, last three visits, coach of record
- **Check-in** — one tap; also supports member self-check-in via QR
- **Guest intake** — iPad-friendly form for guests filling health intake on arrival
- **Incident** — quick form for staff-initiated incident reports (Phase 4 §Ancillary)
- **Announcements** — pinned notices from GM for the day (weather, closures, VIP visit)

### 4.2 Constraints

- No health details visible in list view (only names + first initial). Full details require a second tap and are visible only to the assigned coach.
- Auto-lock in 60 seconds
- No local data retention beyond the shift's session
- Read-only for non-front-desk roles (coaches see their own sessions; facilities see their own tasks)

---

## 5. Ops console — surfaces

`apps/admin`, web-based, desktop-first.

### 5.1 Modules

- **Dashboard** — today, this week, this month at a glance
- **Members** — search, view, edit tier and notes
- **Reservations** — search, cancel with policy override, refund with reason
- **Waitlist** — see queues, promote manually
- **Concierge queue** — safety events, ops takeovers, sampling
- **Payments** — search, refund, mandate manage
- **Programming** — schedule editor (drag-and-drop; changes propagate with member notifications)
- **Content** — CMS entry links, whisper template management
- **Ops app** — housekeeping tasks, sauna/plunge logs
- **Announcements** — global and per-location broadcasts
- **Audit log** — read-only view for admins

### 5.2 Access control

- Ops role scoped to their location (Vasant Kunj launch)
- Admins have cross-location
- Every mutation logged (`audit_log`)
- Step-up required for refunds > ₹5,000, tier changes, membership status overrides

---

## 6. Runbooks

Living documents at `docs/runbooks/`. First set at launch:

1. **Sauna outage** — cold-fallback ritual, member notification, refund policy
2. **Plunge outage** — same
3. **Payment gateway outage** — hold slot 10 min, capture card manually, backfill on recovery
4. **WhatsApp outage** — email + in-app fallback for pre-arrival notes
5. **LLM Concierge outage** — suppress whispers, show soft copy, ops manual whispers for critical members
6. **Staff no-show** — coach coverage matrix, member notification
7. **Weather event / closure** — mass cancellation flow, refund to credit, priority rebook window
8. **Injury on premises** — first-aid protocol, physiotherapist page, incident recording, medical follow-up
9. **Data breach suspicion** — isolate, page platform + DPO, 72h DPB notification, member comms
10. **VIP visit** — quiet reception protocol, no photography, private route
11. **Founder / press visit** — reception protocol
12. **Complaint escalation** — 3-tier: coach → GM → founder, timelines
13. **Membership dispute** — refund policy tree, escalation path
14. **Concierge safety event** — Phase 8 §9.3

Every runbook has: trigger, first response (< 5 min), escalation path, communication scripts, resolution criteria, postmortem template.

---

## 7. Training curriculum

### 7.1 New-hire onboarding (2 weeks)

Week 1:
- Brand immersion (doc-a, doc-b, doc-c)
- Shadow every coach, one shift each
- Front-desk shadow, both AM and PM
- Facilities shadow (opening + closing)

Week 2:
- Voice training: whisper writing exercises with coach lead
- Tablet and console walkthrough
- Runbook drills (2 scenarios)
- Ritual protocol certification (for coaches)

### 7.2 Ongoing training

- Weekly standup (30 min): whisper audit, member feedback, one runbook drill
- Monthly voice review by product + coach lead
- Quarterly full brand refresh
- Annual retreat (staff-only), off-site, 1.5 days

### 7.3 Coach-specific

- Every coach maintains an active certification in their modality (yoga alliance, pilates, S&C)
- Physiotherapist maintains registration
- Wellness Coach maintains a mindfulness certification (Search Inside Yourself, MBSR, or equivalent)
- Ops covers 80% of continuing-education costs annually

### 7.4 Voice certification

Every staff member (not just coaches) passes a voice-check:
- Reads 20 test scenarios (member arrives late, member cancels last minute, member says they feel off)
- Responds in text as they would in person and on WhatsApp
- Reviewed by product + coach lead
- Retest quarterly

---

## 8. Physical operations standards

### 8.1 Rooms

- Sauna: temperature within ±1°C of target
- Plunge: 10°C ±0.5°C, water rotated per schedule; filter check daily
- Steam: eucalyptus reset weekly
- Mat rooms: swept and mopped between classes; mats laid out to Signature preference where known
- Reformer studio: springs and carriages checked daily

### 8.2 Cleanliness

- Every sauna and plunge use: staff wipe-down within 5 minutes of member exit
- Every locker: reset with fresh towel and water bottle after use
- Full house deep clean: 22:00–23:30 daily
- Machine and equipment deep clean: weekly, Wednesday overnight

### 8.3 Ambient standards

- Music: no vocals in ritual and recovery zones; instrumental low-BPM
- Lighting: sunrise-warm during opening, ambient during peak, sunset-warm at close
- Fragrance: subtle sandalwood or vetiver base; nothing floral
- Temperature: 22°C ± 1°C in common areas; individual zones at protocol

### 8.4 Wardrobe (staff)

- Sand or stone tone linen/cotton uniforms
- No branded slogans
- Name pin, first name only
- Sanctuary lockup on the back-right hem (once artwork is delivered)

---

## 9. Ops SLAs

| Event | Target |
|---|---|
| Member greeting on entry | Within 15 seconds |
| Named by front-desk | 100% (if member is known) |
| Check-in to seated | < 4 minutes (median) |
| Coach acknowledgement in class start | 100% |
| Post-ritual whisper delivered | Within 60 min after end |
| Complaint acknowledgement | Same day |
| Complaint resolution | Within 72 hours |
| Refund processed | Within 5 business days |
| Concierge safety event → human ack | < 3 minutes |
| Emergency incident → 108 (ambulance) call | Within 60 seconds when indicated |

---

## 10. Staffing plan by member count

| Members | Coaches | Front-desk | Concierge Ops | Facilities | Paradiso |
|---|---|---|---|---|---|
| 200 (soft launch) | 4 FT + 3 PT | 2 | 1 lead | 3 | 3 |
| 500 | 7 FT + 3 PT | 3 | 1 lead + 1 assistant | 4 | 4 |
| 1,000 | 9 FT + 4 PT | 4 | 1 lead + 2 assistants | 5 | 5 |
| 2,500 (multi-location) | +full team per location | +2 per location | +1 assistant per location | +3 per location | +4 per location |

Utilisation targets: 65–75% for coaches. Anything higher degrades the experience.

---

## 11. Review checklist

- [ ] Launch org chart (~22 headcount at Vasant Kunj) is aligned with hiring plan
- [ ] Role responsibilities cover the app-supported flows
- [ ] Daily rhythm mirrors the programming schedule
- [ ] Staff tablet and ops console modules are enough for launch (nothing missing)
- [ ] Runbook list is complete for the first ninety days
- [ ] Training curriculum (2-week onboarding + weekly standup + quarterly refresh) is staffed
- [ ] Physical standards (temperature, cleanliness, ambient, wardrobe) are measurable and audited
- [ ] SLAs are agreed and included in ops dashboard
- [ ] Staffing plan matches financial plan
