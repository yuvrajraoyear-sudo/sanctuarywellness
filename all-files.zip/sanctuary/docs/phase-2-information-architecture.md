# Phase 2 — Information Architecture
**Project:** Sanctuary Wellness by Play Haus
**Version:** 1.0
**Depends on:** PRD v1.1 · Brand Bible · Member Experience Blueprint · Service Playbook

The IA translates the hospitality intent of the four foundational documents into a **navigable, permission-aware, super-app-ready** structure. Every screen, tab, URL, and permission scope is designed so V1 (Sanctuary members) can absorb Sports, Paradiso ordering at scale, and Kids in Phase 2/3 without a rewrite.

---

## 1. First Principles for IA

1. **Ritual before feature.** The Arrival is the home. Rituals are the primary way to book. Services (à la carte) are one tap deeper.
2. **Five tabs, no more.** More tabs = more thinking. We commit to five.
3. **The primary tab is quiet.** No badges on the tab bar unless a session is ≤60 minutes away or a payment failed.
4. **Deep links are first-class.** Every ritual, booking, timeline event, and Concierge message has a stable URL — for WhatsApp, email, push, and future OS integrations.
5. **Roles are read from a single source.** No screen decides its own permissions; the router does.
6. **Super-app-ready namespacing.** URLs, feature flags, and data scopes carry a `product` axis (`sanctuary`, `sports`, `paradiso`, `kids`) even when V1 only ships `sanctuary`.

## 2. Product Namespaces (super-app foundation)

```
playhaus.app/
├── sanctuary/       ← V1 lives here
├── sports/          ← Phase 2 (football, pickleball)
├── paradiso/        ← Phase 3 (café at scale)
├── kids/            ← Phase 3
└── account/         ← shared across products (identity, billing, notifications)
```

The member's identity, billing, and notification preferences live under `/account`. Everything experience-specific lives under its product namespace. In V1 the app boots straight into `/sanctuary`; the shell is invisible.

## 3. Member App — Sitemap

Five tabs (bottom bar on mobile, left rail on desktop). Only tabs 1–5 are visible; the Concierge is invoked from anywhere.

```
1. Arrival        (home / dashboard)
2. Rituals        (rituals + à la carte booking)
3. Timeline       (progress + member journey)
4. Membership     (plan, guest passes, invoices, café)
5. Signature      (identity, preferences, account, support)

+ Concierge       (persistent floating invocation — not a tab)
```

### Why not "Community" as a tab?
Community moments (challenges, workshops, Founder dinners) surface **contextually** — inside Arrival, Rituals, or Timeline. A dedicated tab implied a social feed we don't want to build in V1.

### Why not "Paradiso" as a tab?
Paradiso is inline where it matters (end of a ritual, mid-morning suggestion). A dedicated tab would make café ordering feel like the point. It isn't — the ritual is.

---

## 4. Screen Inventory (Member)

Each entry lists: **route · screen · primary action · surrounding secondary actions · roles**.

### 4.1 Tab 1 — Arrival

| Route | Screen | Primary action | Secondary | Roles |
|---|---|---|---|---|
| `/sanctuary` | The Arrival | Begin ritual (single recommendation) | Prefer something else · View schedule | member |
| `/sanctuary/whisper/:id` | Concierge whisper (full) | Follow suggestion | Dismiss · Ask concierge | member |
| `/sanctuary/announcements` | Announcements | Read | Mark all read | member |

**Above-the-fold on The Arrival:** greeting · single ritual recommendation · one primary action.
**Below the fold (revealed on scroll):** next reservations (max 2) · Recovery Index one-line summary · latest Concierge whisper · Timeline highlight if new · ambient (weather, hydration) footer.

### 4.2 Tab 2 — Rituals

| Route | Screen | Primary action | Secondary | Roles |
|---|---|---|---|---|
| `/sanctuary/rituals` | Rituals index | Choose a ritual | View à la carte · Filter by time-of-day | member |
| `/sanctuary/rituals/:slug` | Ritual detail (e.g. Recovery Reset) | Reserve ritual | View composition · Change trainer · See Paradiso pairing | member |
| `/sanctuary/rituals/:slug/reserve` | Slot picker | Confirm | Adjust each step's slot · Add note | member |
| `/sanctuary/rituals/reservations` | My reservations | Open next reservation | Reschedule · Cancel · Waitlist status | member |
| `/sanctuary/rituals/reservations/:id` | Reservation detail | Directions · Prepare | Reschedule · Cancel · Concierge | member |
| `/sanctuary/services` | Services (à la carte) | Reserve a service | View schedule · Filter | member |
| `/sanctuary/services/:slug` | Service detail | Reserve service | Read protocol · Contraindications · Trainers | member |
| `/sanctuary/services/:slug/reserve` | Slot picker | Confirm | Waitlist · Add to a ritual instead | member |
| `/sanctuary/waitlist` | Waitlist | Accept slot | Release · Extend | member |

**Note:** the Rituals tab shows **Rituals** by default; **Services** is a secondary segmented control (à la carte). Members almost never see the schedule grid — they see rituals with time-of-day suggestions. Staff use the full grid.

### 4.3 Tab 3 — Timeline

| Route | Screen | Primary action | Secondary | Roles |
|---|---|---|---|---|
| `/sanctuary/timeline` | Timeline (chronological milestones) | Read | Share (private) · Export summary | member |
| `/sanctuary/progress` | Progress (metrics + Recovery Index detail) | Log an entry | Adjust inputs · Trends · Export | member |
| `/sanctuary/progress/recovery-index` | Recovery Index detail | View breakdown | Adjust weights (advanced) · History | member |
| `/sanctuary/challenges` | Challenges | Join challenge | View leaderboard (opt-in) · Past challenges | member |
| `/sanctuary/badges` | Badges & achievements | Read | Share (private) | member |
| `/sanctuary/events` | Events calendar | RSVP | Add to calendar · Read details | member |
| `/sanctuary/annual-review` | Annual Wellness Review (post-anniversary) | View · download PDF | Book review · Share | member |

The Timeline is the **narrative** surface. Progress and Recovery Index are the **data** surfaces underneath. Both live under Tab 3, but Timeline is the default.

### 4.4 Tab 4 — Membership

| Route | Screen | Primary action | Secondary | Roles |
|---|---|---|---|---|
| `/sanctuary/membership` | Membership overview | Manage | Renew · Upgrade · Freeze · Pause | member |
| `/sanctuary/membership/plan` | Plan detail | Change plan | Compare plans · Contact concierge | member |
| `/sanctuary/membership/freeze` | Freeze | Confirm freeze | Choose dates · Cancel | member |
| `/sanctuary/membership/pause` | Pause | Confirm pause | Resume · Cancel | member |
| `/sanctuary/membership/guest-passes` | Guest passes | Issue pass | Revoke · History · Balance | member |
| `/sanctuary/membership/referrals` | Referrals | Refer someone | Credits balance · History | member |
| `/sanctuary/membership/billing` | Billing history | Download invoice | Payment methods · Retry payment | member |
| `/sanctuary/membership/payment-methods` | Payment methods | Add method | Remove · Set default | member |
| `/sanctuary/membership/status` | Status ladder | View progress | See benefits per tier | member |
| `/sanctuary/paradiso` | Paradiso menu | Order ahead | Reorder · Preferences · Bills | member |
| `/sanctuary/paradiso/order/:id` | Order detail | Track / edit | Reorder · Contact café | member |
| `/sanctuary/paradiso/history` | Purchase history | Reorder | Filter · Export | member |

**Note:** Paradiso is nested under Membership because in V1 the primary financial thread is the member statement. In Phase 3, Paradiso graduates to its own product namespace with a full menu experience.

### 4.5 Tab 5 — Signature (identity + settings)

| Route | Screen | Primary action | Secondary | Roles |
|---|---|---|---|---|
| `/sanctuary/signature` | Member Signature overview | Edit | Reset preferences · Print membership card | member |
| `/sanctuary/signature/preferences` | Preferences (locker, sauna temp, tea, coach, music, coffee) | Edit | Explain how it's used | member |
| `/sanctuary/signature/health` | Health basics (injuries, contraindications) | Edit | Consent for trainers to view | member |
| `/sanctuary/signature/goals` | Goals | Edit | AI reads these for recommendations | member |
| `/sanctuary/signature/notifications` | Notification preferences (channels, categories, DND) | Save | Test notification | member |
| `/sanctuary/signature/privacy` | Privacy & data | Export · Delete | Read policy · Consent history | member |
| `/sanctuary/signature/account` | Account (email, phone, password) | Edit | Sign out from other devices | member |
| `/account/security` | Security (2FA, sessions) | Manage | Recovery codes | member (shared) |
| `/sanctuary/signature/support` | Support | Open ticket | WhatsApp escalation · FAQ | member |
| `/sanctuary/signature/support/:id` | Ticket detail | Reply | Close · Rate | member |
| `/sanctuary/signature/about` | About & credits | Read | Version · Legal · Terms | member |

**Naming choice:** "Signature" instead of "Settings" or "Profile." Everything about the member — preferences, health, goals, account — is one place, framed as their personal signature at the club.

### 4.6 Concierge (persistent, not a tab)

| Route | Screen | Primary action | Secondary | Roles |
|---|---|---|---|---|
| `/sanctuary/concierge` | Concierge (surface) | Open concierge input | View recent whispers · Follow suggestion | member |
| `/sanctuary/concierge/:whisperId` | Whisper detail | Follow action | Rate · Dismiss · Snooze | member |

**Invocation:** floating icon on Arrival + Timeline. Not a tab (see principle 3). Concierge is where the member reaches the club, and where the club reaches back.

---

## 5. Screen Inventory (Staff)

The staff panel lives on the same domain, gated by role, at `/staff`. Same design system, tablet-first layout.

### 5.1 Trainer

| Route | Screen | Purpose |
|---|---|---|
| `/staff` | Today | Own schedule for today, quick check-in |
| `/staff/schedule` | Weekly schedule | Own week |
| `/staff/classes/:id` | Class roster | Attendance, session notes, Signature summary per member |
| `/staff/members/:id` | Member card | Signature, injuries, upcoming sessions, past notes |
| `/staff/concierge/queue` | Concierge queue | AI drafts awaiting trainer approval |
| `/staff/concierge/:whisperId` | Draft review | Approve / edit / reject, attribute to trainer |
| `/staff/signature/:memberId` | Member signature | Read/edit hospitality preferences |

### 5.2 Manager (superset of Trainer)

| Route | Screen | Purpose |
|---|---|---|
| `/staff/roster` | Today's roster (all trainers) | Live view |
| `/staff/capacity` | Capacity live view | Pods, studios, rooms, real-time |
| `/staff/walk-in` | Walk-in check-in | Non-app check-in |
| `/staff/members` | Members directory | Search, filter, provision |
| `/staff/members/new` | Provision member | Onboard new member (from tour → account) |
| `/staff/announcements` | Announcements | Compose to all / segment |
| `/staff/refunds` | Refunds | Process refund with reason |
| `/staff/support` | Support tickets | Assign, respond, close |
| `/staff/events` | Events management | Create, publish, RSVP list |

### 5.3 Owner / Admin (superset of Manager)

| Route | Screen | Purpose |
|---|---|---|
| `/staff/owner` | Owner dashboard | Revenue, MRR, active/new/churned members, cohorts |
| `/staff/owner/utilization` | Utilization | Service × hour-of-day heatmap |
| `/staff/owner/trainers` | Trainer performance | Attendance, ratings, retention |
| `/staff/owner/finance` | Finance | Payouts, reconciliations, GST |
| `/staff/owner/growth` | Growth | Referral funnel, cohort curves |
| `/staff/settings` | Admin | Feature flags, service catalogue, ritual composer, pricing |
| `/staff/settings/services` | Services CRUD | Manage service catalogue |
| `/staff/settings/rituals` | Rituals CRUD | Compose rituals from services |
| `/staff/settings/plans` | Plans CRUD | Membership pricing |
| `/staff/audit` | Audit log | Privileged action history |

---

## 6. Navigation Model

### 6.1 Mobile
Bottom tab bar with 5 tabs; Concierge as a floating action button anchored above the tab bar on the Arrival and Timeline tabs only. Never over the tab bar on Rituals reservation flows (avoid obscuring booking CTAs).

### 6.2 Desktop / tablet
Left rail with the same 5 tabs; Concierge as a top-right invocation. Two-column content on ≥1024px where useful (Rituals list + selected ritual preview; Timeline milestones + selected milestone).

### 6.3 URL principles
- Human-readable slugs (`recovery-reset`, `ice-bath`, `strength`)
- Never expose numeric IDs in member-facing URLs unless necessary (`/reservations/:id` is acceptable for individual bookings; `/rituals/recovery-reset` is required for rituals)
- All routes are stable for 12 months minimum — deep links from WhatsApp and email must not break
- Trailing-slash-free, lowercased, kebab-case

### 6.4 Back behaviour
- Every screen has a clear back path. Reservation flows use a linear stepper; back returns one step, never dumps the member on The Arrival.
- The Arrival is the only screen with **no** back button (it's the home).

### 6.5 Modal vs. page
- **Modals** are used only for: cancellation confirm, quick preference edit (single field), and Concierge quick-reply.
- **Full pages** are used for everything else, including booking confirm. Modals feel like software; pages feel like architecture.

### 6.6 Empty states
Every list has a designed empty state with a warm, contextual line and a single suggested action. Empty states are as considered as populated ones — often the first thing a new member sees.

---

## 7. Content Model → IA Mapping

The IA is grounded in these primary content types (details in Phase 3):

| Content type | Lives at | Owned by |
|---|---|---|
| Member | `/sanctuary/signature`, `/staff/members/:id` | member + staff |
| Signature | `/sanctuary/signature/preferences` | member |
| Health basics | `/sanctuary/signature/health` | member (with trainer read access on consent) |
| Membership plan | `/sanctuary/membership/plan` | admin (catalogue), member (subscription) |
| Service | `/sanctuary/services/:slug`, `/staff/settings/services` | admin (catalogue) |
| Ritual | `/sanctuary/rituals/:slug`, `/staff/settings/rituals` | admin (catalogue) |
| Reservation | `/sanctuary/rituals/reservations/:id` | member (creator), staff (operator) |
| Timeline milestone | `/sanctuary/timeline` | system (emitted), staff (curated) |
| Recovery Index entry | `/sanctuary/progress/recovery-index` | system (computed) + member (self-report) |
| Concierge whisper | `/sanctuary/concierge/:id` | AI (draft), trainer (attribution), member (recipient) |
| Challenge | `/sanctuary/challenges` | staff |
| Event | `/sanctuary/events` | staff |
| Paradiso item / order | `/sanctuary/paradiso`, `/sanctuary/paradiso/order/:id` | staff (menu), member (order) |
| Guest pass | `/sanctuary/membership/guest-passes` | member (issue), guest (redeem) |
| Referral | `/sanctuary/membership/referrals` | member |
| Support ticket | `/sanctuary/signature/support/:id`, `/staff/support` | member + staff |

Each content type carries its own permissions, notification triggers, and Timeline emissions (Phase 3 codifies this).

---

## 8. Role & Permission Matrix

Five roles. Every screen and every mutation is gated by role. RLS on every table (Phase 3).

| Capability | Guest | Member | Trainer | Manager | Admin/Owner |
|---|:---:|:---:|:---:|:---:|:---:|
| Request an introduction | ✓ | — | — | — | — |
| View own Signature | — | ✓ | — | ✓ (via card) | ✓ |
| Edit own Signature | — | ✓ | — | — | — |
| Reserve a ritual / service | — | ✓ | — | ✓ (on-behalf) | ✓ (on-behalf) |
| Cancel own reservation | — | ✓ | — | ✓ | ✓ |
| Waive cancellation fee | — | — | — | ✓ | ✓ |
| Approve Concierge whisper | — | — | ✓ | ✓ | ✓ |
| View member card (Signature summary) | — | — | ✓ (rostered only) | ✓ | ✓ |
| Mark attendance | — | — | ✓ | ✓ | ✓ |
| Provision new member | — | — | — | ✓ | ✓ |
| Refund | — | — | — | ✓ | ✓ |
| View owner dashboard | — | — | — | — | ✓ |
| Manage catalogue (services, rituals, plans) | — | — | — | — | ✓ |
| Feature flags | — | — | — | — | ✓ |
| Audit log | — | — | — | — | ✓ |

**Trainer scoping.** Trainers see only members rostered to a class/session they lead, plus any 1:1 members assigned. This is enforced in RLS, not the UI.

**Manager location scoping.** Multi-location-ready: manager permissions are scoped to their location (Phase 2 physical expansion).

## 9. Deep-linking & External Entrypoints

External triggers must land the member on a **specific, useful surface**, not the home tab.

| Trigger | Channel | Deep link |
|---|---|---|
| Booking confirmation | Email, WhatsApp, Push | `/sanctuary/rituals/reservations/:id` |
| Arrival reminder (60m, 30m) | Push, WhatsApp | `/sanctuary/rituals/reservations/:id?arrival=1` |
| Renewal note (30d) | Email | `/sanctuary/membership` |
| Payment failed | WhatsApp, Push, Email | `/sanctuary/membership/billing?retry=1` |
| Guest pass invite | WhatsApp | `/g/:passCode` → `/sanctuary/membership/guest-passes` for member, guest onboarding for recipient |
| Concierge whisper | Push, WhatsApp | `/sanctuary/whisper/:id` |
| Timeline milestone | Push | `/sanctuary/timeline#:milestoneId` |
| Elevation to tier | Push + WhatsApp + physical note | `/sanctuary/timeline#:milestoneId` |
| Challenge invitation | Push | `/sanctuary/challenges/:slug` |
| Waitlist promotion | Push, WhatsApp | `/sanctuary/waitlist?slotId=:id` (15-min confirm window) |

All deep links pass through an auth-gate. Unauthed members land on the login surface with `?next=` preserving the target.

---

## 10. Notification & Emission IA

Every content type emits at most:
- 0–1 push per event
- 0–1 WhatsApp per event
- 0–1 email per event

Governed by member preferences and the 1-non-transactional-push-per-day cap (from Brand Bible).

| Content type | Emits | Channel default |
|---|---|---|
| Reservation created | ✓ | Push + Email |
| Reservation reminder (60m / 30m) | ✓ | Push (60m), WhatsApp (30m) |
| Reservation cancelled by member | ✓ | Email |
| Reservation cancelled by staff | ✓ | Push + WhatsApp |
| Waitlist promoted | ✓ | Push + WhatsApp (15m confirm) |
| Membership renewal notice (30d / 7d / day-of) | ✓ | In-app note, WhatsApp (7d), Email (day-of) |
| Payment failed | ✓ | WhatsApp + Push + Email |
| Concierge whisper (daily cap 1) | ✓ | Push |
| Timeline milestone | ✓ | Push |
| Elevation to tier | ✓ | Push + WhatsApp + physical (mail) |
| Challenge invitation (monthly) | ✓ | Push |
| Support ticket update | ✓ | Push + Email |
| Birthday (per Signature) | conditionally | WhatsApp (personal note) |

Trainer-authored Concierge whispers include the trainer's name in the copy.

## 11. Search & Discovery

V1 does **not** ship a global search. It ships focused finders:

- Rituals: filter by time-of-day, duration, focus (Recovery / Movement / Calm / Performance)
- Services: filter by category (Recovery / Movement / Strength / Breath)
- Timeline: filter by year, milestone type
- Membership → Billing: filter by month, download
- Signature → Support: search past tickets

A global search adds surface area we don't need. If a member is looking, the Concierge is the search bar.

## 12. Onboarding IA (post-invite)

Six screens, in order (from Doc B stage 4):

1. `/onboarding/welcome`
2. `/onboarding/intents`
3. `/onboarding/rhythm`
4. `/onboarding/preferences`
5. `/onboarding/health`
6. `/onboarding/first-ritual`

After screen 6, the member is dropped on `/sanctuary` (The Arrival) with all state populated. Onboarding is resumable and skippable per screen.

## 13. Support IA

Contextual support surfaces:

- **Inline "Need help?" link** on reservation, membership, and payment surfaces
- **Support tab** inside Signature (`/sanctuary/signature/support`)
- **WhatsApp escalation** button on every ticket
- **FAQ** surfaced via contextual chips on relevant screens (e.g. "How does freeze work?" on Freeze screen)

Support is not a top-level tab. It's a companion to whichever surface needed it.

## 14. Empty, Error, Offline states

| State | Behaviour |
|---|---|
| **First-time member (no history)** | Arrival shows a first-ritual recommendation; Timeline shows the "Joined Sanctuary" milestone only; Progress shows "Steady, we're still learning about you." |
| **Frozen / paused member** | Arrival replaces ritual card with a quiet return card; Rituals tab shows a "See you when you're back" screen |
| **No connectivity** | Arrival + next 2 reservations available read-only from cache; Concierge and booking mutations queued or gently blocked |
| **Server error** | Warm copy per Brand Bible; retry button; if 3 retries fail, offer WhatsApp escalation |
| **Feature disabled by flag** | Route silently redirects to nearest available parent surface; no error page |

## 15. Feature Flags (super-app forward compatibility)

Every new capability is gated on a flag. Default state per environment:

| Flag | Dev | Staging | Prod (V1 launch) | Notes |
|---|---|---|---|---|
| `sanctuary_rituals` | on | on | on | Core |
| `sanctuary_a_la_carte` | on | on | on | Core |
| `sanctuary_concierge` | on | on | on | Core |
| `sanctuary_recovery_index` | on | on | on | Core |
| `sanctuary_timeline` | on | on | on | Core |
| `sanctuary_paradiso` | on | on | on | Café order-ahead |
| `sanctuary_challenges` | on | on | on | Community |
| `sanctuary_events` | on | on | on | Events |
| `sanctuary_status_ladder` | on | on | on | Membership |
| `sanctuary_guest_passes` | on | on | on | Membership |
| `sanctuary_referrals` | on | on | on | Membership |
| `sanctuary_wearables` | on | off | off | Phase 2 |
| `sports_bookings` | on | off | off | Phase 2 |
| `paradiso_full_menu` | on | off | off | Phase 3 |
| `kids_bookings` | on | off | off | Phase 3 |

Flags are read from a single service (Supabase table + edge cache). Every product surface checks flags before rendering routes.

## 16. IA Diagrams

### 16.1 Member sitemap (compact)

```
Arrival (/sanctuary)
├─ Whisper detail
└─ Announcements

Rituals (/sanctuary/rituals)
├─ Ritual detail → Reserve → My reservations → Reservation detail
├─ Services (à la carte) → Service detail → Reserve
└─ Waitlist

Timeline (/sanctuary/timeline)
├─ Progress
│  └─ Recovery Index detail
├─ Challenges
├─ Badges
├─ Events
└─ Annual Wellness Review

Membership (/sanctuary/membership)
├─ Plan → Change plan
├─ Freeze / Pause
├─ Guest passes
├─ Referrals
├─ Billing → Payment methods
├─ Status ladder
└─ Paradiso → Order detail → History

Signature (/sanctuary/signature)
├─ Preferences
├─ Health
├─ Goals
├─ Notifications
├─ Privacy
├─ Account (shared with /account/security)
├─ Support → Ticket detail
└─ About

Concierge (floating, /sanctuary/concierge)
└─ Whisper detail
```

### 16.2 Staff sitemap (compact)

```
Trainer
├─ Today, Schedule, Class roster
├─ Member card
├─ Concierge queue → Draft review
└─ Signature (per member)

Manager (superset)
├─ Roster, Capacity, Walk-in
├─ Members → Provision new
├─ Announcements, Refunds, Support, Events

Owner/Admin (superset)
├─ Owner dashboard → Utilization, Trainers, Finance, Growth
├─ Settings → Services, Rituals, Plans
└─ Audit log
```

---

## 17. Analytics & Instrumentation IA

Every screen has a canonical name; every meaningful action has a canonical event. Aligned with PostHog & product KPIs.

**Screen naming:** `sanctuary/<tab>/<screen>` (e.g. `sanctuary/arrival`, `sanctuary/rituals/ritual-detail`, `sanctuary/membership/billing`).

**Event taxonomy (starter):**

| Event | Properties |
|---|---|
| `ritual_viewed` | `ritual_slug`, `source` (arrival, index, concierge) |
| `ritual_reserved` | `ritual_slug`, `slots`, `total_duration_min` |
| `service_reserved` | `service_slug`, `duration_min` |
| `reservation_cancelled` | `reservation_id`, `lead_time_hours`, `late_flag` |
| `reservation_rescheduled` | `reservation_id`, `lead_time_hours` |
| `waitlist_joined` | `service_slug` |
| `waitlist_confirmed` | `service_slug`, `time_to_confirm_seconds` |
| `arrival_checked_in` | `reservation_id`, `method` (geofence, qr, manual) |
| `concierge_whisper_shown` | `whisper_id`, `theme` |
| `concierge_whisper_followed` | `whisper_id`, `action` |
| `concierge_whisper_dismissed` | `whisper_id`, `reason` |
| `recovery_index_viewed` | `score`, `trend` |
| `membership_freeze_started` | `days` |
| `membership_upgrade` | `from_plan`, `to_plan` |
| `paradiso_ordered` | `items`, `total_inr` |
| `guest_pass_issued` | `pass_id` |
| `referral_sent` | `referral_id` |
| `referral_converted` | `referral_id`, `time_to_convert_days` |
| `timeline_milestone_emitted` | `milestone_type` |
| `tier_elevated` | `from_tier`, `to_tier` |

Enough to answer: what rituals convert, what causes cancellations, what Concierge whispers work.

---

## Phase 2 Review Checklist

Before Phase 3 (Database Schema), please confirm:

- [ ] Five tabs are correct (Arrival, Rituals, Timeline, Membership, Signature) — no missing top-level surface
- [ ] Concierge as a floating invocation (not a tab) is acceptable
- [ ] Paradiso nested under Membership in V1 (graduates in Phase 3) is acceptable
- [ ] Community lives contextually, not as its own tab, in V1
- [ ] Ritual is the default booking surface, à la carte is one segmented-control tap away
- [ ] Rooms/spaces/trainers → to be modelled explicitly in Phase 3 (schema)
- [ ] Deep-link table (Section 9) covers all external entrypoints you plan to use
- [ ] Role matrix (Section 8) matches ops reality (trainer scoping, manager location scoping)
- [ ] Feature flag list (Section 15) leaves the door open for Sports / Paradiso / Kids as intended
- [ ] Event taxonomy (Section 17) covers KPIs and is not over-engineered

On approval, I'll move to **Phase 3 — Database Schema**: tables, columns, indices, RLS policies, triggers, and Supabase migrations — grounded in this IA and the four foundation docs.
