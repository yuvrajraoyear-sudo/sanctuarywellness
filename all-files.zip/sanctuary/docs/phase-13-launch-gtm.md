# Phase 13 — Launch Plan & Go-to-Market

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

Sanctuary opens quietly and deliberately. This document specifies the phasing from private preview to public launch, the go-to-market motion, the acquisition channels, and the specific readiness gates that each phase must clear before the next begins.

Sections:
1. Launch philosophy
2. Phasing and gates
3. Founding Member programme
4. Acquisition channels
5. Content and PR strategy
6. Partnerships
7. Referral and word-of-mouth
8. Pricing and offers
9. Launch-week choreography
10. Metrics per phase
11. Risk register
12. Review checklist

---

## 1. Launch philosophy

- **Quiet, not loud.** Fewer members better served is louder than crowded opening weeks. No red carpets, no influencer stampede.
- **Membership by introduction.** For the first six months, joining is deliberately friction-full: an inquiry, a call, a visit. This is the front door, not a barrier.
- **Word of mouth is the primary channel.** Everything else is scaffolding.
- **The building is the pitch.** If a first visit isn't self-evident, no marketing can compensate.
- **We do not discount our way in.** Founding Members receive time, access, and voice — not price cuts.

---

## 2. Phasing and gates

### 2.1 Phase P0 · Internal (T−60 to T−30 days)

- **Membership** — team, families, close operators
- **Purpose** — real-use validation of every flow and every physical protocol
- **Success gate** — 30 completed rituals with feedback ≥ 4/5, zero Sev-1 incidents, all runbooks drilled once

### 2.2 Phase P1 · Founding Members (T−30 to T+0)

- **Membership** — 50 hand-invited members (see §3)
- **Purpose** — soft-open with real members, no press
- **Programming** — reduced schedule: 60% of catalogue
- **Success gate** — 40+ members retained past 30 days, WRM ≥ 30, NPS ≥ 55 among P1

### 2.3 Phase P2 · Private Launch (T+0 to T+60 days)

- **Membership** — waitlist-based; ~150 additional members admitted
- **Purpose** — normalise operations; observe multi-cohort dynamics
- **Programming** — full catalogue
- **Success gate** — renewal signal healthy, no ops SLA breaches for 30 consecutive days

### 2.4 Phase P3 · Public Launch (T+60 to T+120)

- **Membership** — open with introduction call as the default path
- **Purpose** — press, editorial, member dinners
- **Programming** — full catalogue + first Longevity Weekend

### 2.5 Phase P4 · Steady state (T+120 onward)

- Weekly reviews, monthly ops retro, quarterly brand review
- First expansion planning if occupancy > 75% consistently

---

## 3. Founding Member programme

50 members. Curated. Non-transactional.

### 3.1 Who

- 15 from Play Haus Sports existing community
- 10 from healthcare, physiotherapy, and sports-medicine networks
- 8 from arts, hospitality, and journalism (culture-shaping voices)
- 7 close referrals from founder and coach network
- 10 self-nominated via waitlist screening

### 3.2 What they receive

- **Time** — an extra hour per visit, private tour, coach match ceremony
- **Access** — first access to any new programming or ritual
- **Voice** — a monthly Founding Member roundtable with the founder for the first six months
- **Ritual** — a permanent Founding Member badge in their Timeline and a small, unbranded, hand-numbered keepsake

### 3.3 What they don't receive

- Discounts
- Public recognition unless they choose to share
- Marketing use of their name or image without explicit request

### 3.4 Onboarding

- Personal intro call from GM or Founder
- Site visit before app access opens
- Coach match ceremony (30 min conversation) determines trainer of record
- First ritual booked personally, not via app

---

## 4. Acquisition channels

### 4.1 Word-of-mouth (primary)

- Referral link with experience-credit reward (Phase 4 §9)
- Guest passes with generous intake
- Member dinners (Phase 11 §5.2) with permission to bring +1

Target: > 55% of first-year members via WoM.

### 4.2 Founder network (secondary)

- Founder personally invites 200+ people over the first three months
- Track: intro sent → visit booked → member

### 4.3 Editorial and PR (tertiary)

- One long-form profile in a Delhi lifestyle publication (Vogue India, T Magazine, Conde Nast Traveller) in month 3
- One long-form business piece in month 6 (Mint Lounge, The Ken profile) — focused on the business of premium wellness, not the app
- Own editorial on `sanctuary.playhaus.club/journal` (Phase 11 §6)

Explicitly not doing at V1:
- Influencer marketing (misaligned with quietness principle)
- Discount ads on Instagram / Meta
- Comparison content ("better than X gym")

### 4.4 Corporate wellness (Year-2)

- Small-batch corporate memberships for design firms, VC funds, boutique law offices (10–30 seats each)
- Requires SOC 2 (Phase 7 §5.4) and dedicated onboarding
- Not a launch channel; a planned Year-2 vertical

### 4.5 Search

- Own the terms: *sauna Delhi, ice bath Delhi, cold plunge Delhi, recovery Delhi, hyrox Delhi, longevity clinic Delhi*
- SEO built into content strategy (Phase 11) — long-form editorial doubles as SEO surface
- No paid search at launch; consider selective bidding in Year-2 for competitive-set terms

---

## 5. Content and PR strategy

### 5.1 Pre-launch (T−30 → T+0)

- Website live at a holding page with waitlist form at `sanctuary.playhaus.club` (T−30)
- Instagram account seeded with 6 posts before opening — architecture, texture, coaches, tea, no bodies (T−14)
- Founding Member letter published, unsigned by name (T−7)

### 5.2 Launch week (T+0 to T+7)

- Founder note published on the journal (day 0)
- Instagram: one post per day, no captions longer than 3 sentences
- No paid social

### 5.3 Post-launch (T+8 onward)

- Weekly editorial on the journal (Phase 11 §6)
- Monthly member letter by email
- Quarterly print piece to Resident+ homes
- Founding Member testimonials only with their explicit request

### 5.4 Press one-pager

Ready by T+0; distributed only on request. Contains:
- What Sanctuary is (three lines)
- Founding team, coach credentials
- What Sanctuary is not (three lines) — helps journalists avoid category errors
- Photography rights
- Contact

Never sent unsolicited.

---

## 6. Partnerships

### 6.1 Referral partnerships (medical + performance)

- 3–5 physiotherapy clinics in south Delhi
- 2 sports-medicine practices
- 1–2 sleep clinics
- Two-way referral, formal agreement, capped introduction incentives (experience credits, not cash)

### 6.2 Hospitality partnerships (Year-1)

- Two boutique hotels for guest-day passes to their stay-guests
- One private members' club (arts-focused) for member cross-benefits

### 6.3 Sports partnerships

- HYROX India (already in-house)
- Two running clubs and one triathlon club in Delhi — event support, race-day recovery station pop-ups

### 6.4 Not doing

- Employer wellness aggregators (misaligned)
- ClassPass / Cult.fit / Fitternity (misaligned)

---

## 7. Referral and word-of-mouth

- Every Founding Member receives one Founder-signed introduction card they can pass along at their discretion
- Referral rewards are non-cash (Phase 4 §9)
- Special milestone: 5 referrals in a year → founder-signed note + invite to the annual retreat guest list

Guest program:
- Included with Member and Resident plans
- Guests receive a warm intake with no upsell during their visit
- Post-visit whisper (to the guest) is thanks + optional invitation to explore membership — never immediate

---

## 8. Pricing and offers

### 8.1 Launch pricing (Vasant Kunj)

| Plan | ₹ / month | ₹ / year (annual) | Includes |
|---|---|---|---|
| Explorer (30d, single purchase) | — | ₹12,000 one-time | 6 classes or 3 rituals |
| Member | ₹18,500 | ₹198,000 | Unlimited classes, 8 rituals, 1 guest pass |
| Resident | — | ₹360,000 | Unlimited classes and rituals, 4 guest passes, 1 Annual Review, Sunday Reset priority |
| Inner Circle | — | ₹720,000 | Resident + weekly coach hours + concierge suite (invite) |
| Founder | — | (bespoke) | Whitelist |

Founding-Member pricing = **standard pricing**. The offer is inclusion, not discount.

### 8.2 Add-ons

- Extra ritual (over plan cap): ₹1,500 recovery, ₹2,500 longevity
- Guest pass extra: ₹2,000
- PT hour: ₹3,000
- SGT (small group training) hour: ₹1,500
- Physiotherapy hour: ₹2,500

### 8.3 Prices we won't run

- Introductory offers, seasonal sales, festive discounts
- BOGO, free week trials for the general public
- Discount codes distributed publicly

Corrections and goodwill credits are handled case-by-case by Ops, always as credit or experience, never as cash discount.

---

## 9. Launch-week choreography

Day-by-day, T+0 to T+7. GM owns.

- **T+0 (Fri) 06:00** — Doors open. First ritual booked with a Founding Member.
- **T+0 evening** — Founder note published; email to full waitlist inviting them into a call queue.
- **T+1–T+2 (Sat–Sun)** — Sunday Reset premiere, capacity 12, Founding Members priority.
- **T+3 (Mon)** — Ops retrospective on the weekend; adjust anything friction-heavy.
- **T+4–T+5** — Waitlist call queue begins; ~15 intros scheduled per day.
- **T+6 (Thu)** — First Coach Series event, in-house only.
- **T+7 (Fri)** — Week-1 numbers reviewed with leadership; go/no-go on the next Founding cohort of 25.

No launch party at T+0. First member dinner is at T+21.

---

## 10. Metrics per phase

| Phase | Members | WRM target | Retention gate | Concierge phase |
|---|---|---|---|---|
| P0 | Team only | — | — | Off |
| P1 Founding | 50 | 30 | 30-day > 90% | Alpha (ops-reviewed) |
| P2 Private | +150 | 120 | 30-day > 85% | Alpha |
| P3 Public | +300–500 | 400 | 30-day > 80% | Beta (partial auto) |
| P4 Steady | Growth-driven | 700 by Y1 | 90-day > 75% | GA |

---

## 11. Risk register (launch)

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Sauna or plunge outage in first week | Medium | High | Facilities dry-run 14 days pre-launch; runbook 1 & 2 drilled |
| Coach no-show | Medium | High | Coverage matrix; on-call physio-coach |
| Concierge safety event mishandled | Low | Very high | Alpha-phase ops review + drilled runbook 14 |
| Payment gateway outage during renewals | Low | High | Runbook 3; manual capture rehearsal |
| Founding Member drops out publicly | Low | Medium | Founder-led relationship management; exit gracefully with a private note |
| Press mischaracterises brand ("elite gym") | Medium | Medium | Press one-pager includes "what Sanctuary is not"; founder-first interview policy |
| Waitlist exceeds capacity | High | Low | Introduce cohort waves; publish a wait time transparently |
| App outage during ritual | Low | High | Read-only degraded mode; front-desk fallback via ops app snapshot |

---

## 12. Review checklist

- [ ] Launch philosophy (quiet, introduction-first, no discounting) accepted
- [ ] Phasing P0→P4 with named gates is right
- [ ] Founding Member composition (50 across 5 sources) reflects the community we want
- [ ] Channel mix (WoM primary, founder network secondary, editorial tertiary) is the right restraint
- [ ] Pricing anchor points make business sense and respect the "no discounts" rule
- [ ] Launch-week choreography is executable by the current org
- [ ] Metrics per phase and phase-to-phase gates are the right go/no-go criteria
- [ ] Risk register covers what keeps us up at night
