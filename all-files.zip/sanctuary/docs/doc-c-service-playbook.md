# Doc C — Service Playbook
**Project:** Sanctuary Wellness by Play Haus
**Version:** 1.0
**Owner:** Head Trainer + Operations, in partnership with Product

The Service Playbook is the operational source of truth for every service Sanctuary offers. It exists so the software mirrors real practice — not the other way around. Every parameter here maps to a field or rule in the app.

**Structure of each service:**
1. Purpose
2. Duration & capacity
3. Preparation (member-facing)
4. Contraindications & safety
5. Protocol (staff-facing, step by step)
6. Trainer / attendant role
7. Post-service care
8. Paradiso pairing
9. Concierge follow-up
10. Data captured (for Recovery Index & Timeline)
11. Fail-safe

**Global standards apply to every service.**

---

## Global Standards (apply to all services)

- **Punctuality:** ritual/service starts within 3 minutes of the reserved time. If the club runs late, the trainer greets the member with an apology and a small hospitality gesture.
- **Cleanliness:** every recovery pod, mat, and towel is reset between sessions. Reset window is baked into capacity math.
- **Hydration:** water is offered at every station without asking.
- **Signature honoured:** locker, temperature, tea, music, coach are matched on booking.
- **Consent for touch:** trainers ask before physical contact (e.g. mobility assist). Documented in trainer training.
- **Medical basics on file:** every member has intake data; trainers review before session.
- **Feedback loop:** a one-tap emoji + optional note prompt after the ritual. Fed into Recovery Index & Concierge.
- **Silence is fine.** Members may prefer no conversation. Signature can flag "quiet please" — staff honour it.

---

## 1. Ice Bath

**Purpose.** Cold exposure for nervous-system regulation, inflammation control, recovery.

**Duration & capacity.**
- 3–8 minutes per member (staggered)
- 2 pods; capacity 2 concurrent
- 10-minute reset window (drain, refill, chemistry check) every 6 sessions

**Preparation (member-facing).**
- Arrive 5 minutes early.
- Hydrate the night before.
- Avoid a heavy meal within 2 hours.
- No alcohol for 12 hours prior.

**Contraindications.**
- Cardiovascular conditions (medical clearance required)
- Pregnancy
- Uncontrolled hypertension
- Raynaud's
- Any acute illness / fever
- **Flagged in Signature; trainer sees before session.**

**Protocol (staff).**
1. Confirm member Signature — contraindications review.
2. Water temperature 8–12°C (adjust to Signature if tolerant).
3. Guided breath-in for 30 seconds before entry.
4. Time entry. Beginner: 2 min. Regular: 3–5 min. Advanced: up to 8 min.
5. Exit assist; warm towel ready.
6. 5 minutes seated in warm room; herbal tea offered.

**Trainer / attendant role.** Attendant present throughout; trainer for first three sessions of any new member.

**Post-service care.**
- No hot shower for 30 minutes (preserves the cold-exposure effect).
- Passive rewarming preferred (warm room, blanket).

**Paradiso pairing.** Ginger-turmeric shot; hot herbal tea (ginger, lemon, honey). Never iced.

**Concierge follow-up.** Evening whisper: *"How did the ice feel today? Anything to note?"*

**Data captured.**
- Duration (seconds)
- Temperature (°C)
- Member emotion (1-tap)
- Optional note
- Feeds Recovery Index: "recovery sessions" + variance in tolerance over time

**Fail-safe.** Panic button in the pod area. Immediate exit and warming protocol; medical escalation SOP for any adverse response.

---

## 2. Sauna (Traditional Finnish / Infrared)

**Purpose.** Heat exposure for cardiovascular conditioning, muscle recovery, calm.

**Duration & capacity.**
- 15–30 minutes per session
- 2 sauna rooms (one traditional, one infrared)
- Capacity per room: 6 (traditional), 3 (infrared)

**Preparation.**
- Hydrate well beforehand.
- Remove jewellery.
- Shower before entry (courtesy).

**Contraindications.**
- Uncontrolled hypertension
- Pregnancy (case-by-case, medical clearance)
- Cardiovascular conditions
- Recent surgery
- Acute illness / fever

**Protocol.**
1. Traditional: 75–90°C, humidity managed with löyly by staff on cue.
2. Infrared: 45–60°C, longer duration acceptable (up to 40 min).
3. Signature: preferred temperature stored per member; staff sets before entry.
4. Rounds: 2–3 rounds of 15 minutes with 5 minutes cool-down between.

**Trainer / attendant role.** Attendant checks in every 10 minutes; no in-sauna coaching (respect silence).

**Post-service care.** Cool shower or ice bath (contrast), 500ml water, 5 minutes seated rest.

**Paradiso pairing.** Herbal tea (member Signature preference); coconut water; electrolyte drink for members with heavier heat exposure.

**Concierge follow-up.** None routine. If it's the member's first sauna, one whisper: *"How was the heat?"*

**Data captured.**
- Duration
- Temperature preference
- Rounds
- Emotion post
- Signature refined (temperature preference over time)

**Fail-safe.** Emergency pull cord in each room; staff evacuation protocol; cold water and cool-down bench outside every door.

---

## 3. Steam

**Purpose.** Humid heat for respiratory ease, skin, relaxation.

**Duration & capacity.**
- 15–20 minutes
- Capacity: 4 concurrent per room

**Preparation.** Hydrate. Shower prior.

**Contraindications.** Similar to sauna, plus severe respiratory conditions.

**Protocol.**
1. Temperature 43–46°C, humidity ~100%.
2. Optional eucalyptus infusion — Signature-driven ("scent preference").
3. Rounds of 10–15 minutes.

**Trainer role.** Attendant check-in every 10 minutes.

**Post-service care.** Cool shower, water, 5 minutes rest.

**Paradiso pairing.** Mint-lemon water; light herbal tea.

**Concierge follow-up.** None routine.

**Data captured.** Duration, scent preference, emotion post.

**Fail-safe.** Emergency exit; visible timer inside room.

---

## 4. Contrast Therapy

**Purpose.** Alternating hot/cold to accelerate recovery, nervous-system training.

**Duration & capacity.**
- 20–30 minutes total (3–4 rounds)
- Capacity: 2 concurrent (paired with pod availability)

**Preparation.** Same as ice bath + sauna.

**Contraindications.** Union of ice-bath and sauna contraindications; trainer clearance recommended for first session.

**Protocol.**
1. Round pattern: 3 minutes sauna → 1 minute ice → 30 seconds rest. Repeat 3–4 times.
2. Trainer times each round.
3. Final round ends **cold** (finishes with ice).
4. 5–10 minutes seated warm-up; hydration.

**Trainer role.** Present throughout. Talks through the first two rounds; silent for the last.

**Post-service care.** No hot shower for 30 min. Warm layer, tea.

**Paradiso pairing.** Warm broth; recovery smoothie (protein + tart cherry) if paired with a training session.

**Concierge follow-up.** Whisper next morning: *"How's the body feeling after contrast?"*

**Data captured.** Rounds completed, tolerance progression, emotion.

**Fail-safe.** Panic buttons in both stations; trainer present.

---

## 5. Breathwork

**Purpose.** Structured breathing for calm, focus, sleep, energy — protocol-dependent.

**Duration & capacity.**
- 20–45 minutes
- Studio capacity: 12

**Types on offer.**
- **Coherent breathing** (5.5 breaths/min) — calm, sleep prep
- **Box breathing** — focus
- **Wim-Hof-style** — energy, cold-adaptation (trainer-supervised only)
- **3-part diaphragmatic** — beginner

**Preparation.** Light stomach. Loose clothing.

**Contraindications.**
- Cardiovascular / respiratory conditions (especially for cyclic hyperventilation protocols)
- Pregnancy (case-by-case)
- Anxiety / panic disorder — beginner protocols only, and disclosed
- Recent surgery

**Protocol.**
1. Trainer guides, live (never recorded audio only, in V1).
2. Studio dim, temperature 22°C, no music unless Signature-preferred.
3. Members lie or sit; blankets available.
4. Cyclic hyperventilation always seated or lying (never standing).

**Trainer role.** Certified breath instructor only.

**Post-service care.** 3–5 minutes of silence at end. Slow re-entry.

**Paradiso pairing.** Warm tulsi tea; nothing caffeinated for calm sessions.

**Concierge follow-up.** *"How did you sleep after breathwork?"* the following morning.

**Data captured.** Type, duration, emotion, sleep-quality self-report next day.

**Fail-safe.** Trainer instructed to intervene if member shows distress (tetany, panic). SOP includes bringing member back to normal breath, water, seated recovery.

---

## 6. Yoga

**Purpose.** Movement, mobility, mindfulness — style-dependent.

**Duration & capacity.**
- 45–60 minutes
- Studio capacity: 14

**Levels & styles.**
- Restorative (Sunday morning, Wednesday evening)
- Vinyasa (Tue, Thu mornings)
- Yin (Friday evening)
- Chair yoga (rehab / seniors — case-by-case)

**Preparation.** Light stomach 2h prior. Bring nothing — mats and props provided.

**Contraindications.** Style-dependent; trainer discusses on first session.

**Protocol.**
1. Trainer greets by name at the mat.
2. Studio props preset by Signature preferences.
3. Class runs to duration; hard-stop for the next class.
4. Savasana / stillness always the closing 5 minutes.

**Trainer role.** RYT-200 minimum; certifications logged.

**Post-service care.** Hydration; encourage 10 minutes of stillness after class.

**Paradiso pairing.** Turmeric latte; light bowl.

**Concierge follow-up.** None routine.

**Data captured.** Attendance, teacher, self-rated mobility.

**Fail-safe.** No physical adjustments without verbal consent per session.

---

## 7. Pilates

**Purpose.** Precision core work, posture, low-impact strength.

**Duration & capacity.**
- 50 minutes
- Mat-based: capacity 12. Reformer (if available Phase 1.5): capacity 6.

**Preparation.** Comfortable clothing; grip socks provided.

**Contraindications.** Recent spinal surgery; pregnancy (specialised classes only).

**Protocol.** Standard mat or reformer flow; trainer sequences per level (Foundations / Continuing).

**Trainer role.** Certified Pilates instructor.

**Post-service care.** Hydration.

**Paradiso pairing.** Protein snack; matcha.

**Concierge follow-up.** None routine.

**Data captured.** Attendance, class level.

**Fail-safe.** Trainer supervises reformer settings for every member.

---

## 8. Mobility

**Purpose.** Joint range, tissue quality, longevity foundation.

**Duration & capacity.**
- 45 minutes
- Studio capacity: 14

**Preparation.** Loose clothing, socks.

**Contraindications.** Acute injuries — trainer clearance.

**Protocol.**
1. Warm-up 10 min (breath + light movement)
2. Focus area rotation (hips / spine / shoulders / ankles) — 25 min
3. Cool-down + stretch 10 min

**Trainer role.** Certified mobility coach; note the focus area of each session.

**Post-service care.** Hydration.

**Paradiso pairing.** Turmeric latte, warm broth, ginger tea.

**Concierge follow-up.** After 3 mobility sessions, Concierge may suggest a targeted routine.

**Data captured.** Focus area, self-rated flexibility (weekly).

**Fail-safe.** No forced ranges; verbal cues only.

---

## 9. Strength

**Purpose.** Progressive resistance training for performance and longevity.

**Duration & capacity.**
- 60 minutes group / 60 minutes 1:1
- Group capacity 8; 1:1 unlimited (by trainer availability)

**Preparation.** Fuelled (light meal 2h before). Grip chalk provided.

**Contraindications.** Trainer intake required; recent injuries flagged.

**Protocol.**
1. Warm-up 10 min.
2. Compound lifts progressing per program (squat/hinge/press/pull).
3. Accessory work.
4. Cooldown / mobility 5 min.

**Trainer role.** Certified strength & conditioning coach (NSCA / equivalent).

**Post-service care.** Protein window (30–60 min post) — Paradiso suggestion inline.

**Paradiso pairing.** Protein bowl or shake; electrolytes.

**Concierge follow-up.** After strength days, Concierge often suggests a Recovery Reset for 24–48h later.

**Data captured.** Session type, load progression (from trainer notes), self-rated exertion.

**Fail-safe.** Spotter for heavy lifts; trainer supervises.

---

## 10. HYROX Class (Sanctuary-hosted)

**Purpose.** HYROX-specific conditioning for members preparing for events.

**Duration & capacity.**
- 60 minutes
- Capacity 12

**Preparation.** Well fuelled; hydrated. Water bottle.

**Contraindications.** Cardiovascular clearance for members over 40 first-time.

**Protocol.** HYROX-official coaching template; blocks of run + station work.

**Trainer role.** HYROX-certified.

**Post-service care.** Cool-down, contrast therapy recommended for members with high frequency.

**Paradiso pairing.** Full recovery meal; electrolytes.

**Concierge follow-up.** After HYROX days, Concierge often books Athlete Prep or Post-Event Restore in the ritual library.

**Data captured.** Session type, self-rated exertion, attendance.

**Fail-safe.** AED accessible; staff CPR-certified.

---

## 11. Stretch Sessions (Assisted Stretch, 1:1)

**Purpose.** Assisted, trainer-led stretch for mobility and recovery.

**Duration & capacity.**
- 30 or 60 minutes
- 1:1

**Preparation.** Loose clothing.

**Contraindications.** Trainer clearance for members with recent injuries.

**Protocol.** Trainer-driven; consent for touch at each new position.

**Trainer role.** Certified.

**Paradiso pairing.** Warm herbal tea; light snack.

**Concierge follow-up.** Weekly re-book suggestion if member added stretch as a goal.

**Data captured.** Focus area, self-rated flexibility.

**Fail-safe.** Consent every time.

---

## Ritual Compositions (from PRD 6.3)

Rituals are composed sequences drawn from the services above. The Service Playbook feeds the ritual engine — every ritual is a chain of protocols, with pairings automatic.

| Ritual | Sequence | Notes |
|---|---|---|
| **Morning Reset** | Breathwork (coherent) → Mobility → Paradiso coffee | ~45 min |
| **Recovery Reset** | Sauna → Ice Bath → Contrast → Herbal tea | ~50 min; contrast requires trainer for first attempt |
| **Evening Wind Down** | Steam → Stretch (30 min) → Turmeric latte | ~40 min; late-evening only |
| **Weekend Recharge** | Yoga (restorative) → Sauna → Ice Bath → Nutrition bowl | ~90 min |
| **Athlete Prep** | Mobility → Contrast → Trainer note | Booked 24–48h before event |
| **Post-Event Restore** | Ice Bath → Breathwork (coherent) → Stretch → Recovery smoothie | Same-day post-event |

Ritual metadata each carry:
- Composition (ordered service IDs)
- Total duration
- Ideal time-of-day
- Prerequisites (e.g. first-timer flag)
- Paradiso item suggestion
- Concierge follow-up trigger

---

## Cross-service Recovery Index Inputs

Every service listed in this playbook contributes a defined signal to the Recovery Index. Below is the mapping (used by the AI Coach to compute):

| Service | Signal type | Weight (initial, will tune) |
|---|---|---|
| Ice Bath | Recovery session count, tolerance progression | High |
| Sauna | Heat exposure minutes | Medium |
| Steam | Heat exposure minutes | Low |
| Contrast | Recovery session (double weight) | High |
| Breathwork | Stress delta (self-report next day) | High |
| Yoga | Mobility contribution | Medium |
| Pilates | Mobility, core contribution | Medium |
| Mobility | Mobility score primary input | High |
| Strength | Training load (intensity mix) | High |
| HYROX | Training load (heavy) | High |
| Stretch | Mobility contribution | Medium |

**Self-report inputs (from Concierge nudges):** sleep, stress, mood, hydration — weighted alongside service signals.

---

## Staff Training Standards

Every trainer / attendant carries:
- Current certifications on file
- CPR/AED valid
- First-aid basics
- Sanctuary hospitality training (voice, tone, consent, silence-respect)
- Two-week shadowing before solo shifts
- Quarterly protocol refresh

---

## Review Checklist

- [ ] All service durations, capacities, and contraindications reflect current ops
- [ ] Trainer certifications required per service are correct
- [ ] Ritual compositions match what the club will actually deliver
- [ ] Paradiso pairings are available on the current menu
- [ ] Recovery Index signal weights are acceptable as a starting point (Product will tune post-launch)
- [ ] Fail-safes are actioned in staff training material

Once approved, Phase 2 (Information Architecture) will use these three foundational documents as the shape of the app.
