# Phase 11 — Content & Programming Strategy

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

Content is what a member reads and receives. Programming is what a member walks in and does. Both are how the brand touches the body on a Tuesday evening.

Sections:
1. Content pillars
2. Weekly programming rhythm
3. Ritual catalogue
4. Class catalogue and cadence
5. Special events and workshops
6. Editorial voice and calendar
7. Notifications & whispers content plan
8. Paradiso menu language
9. Member letters (long-form)
10. Content operations
11. Review checklist

---

## 1. Content pillars

Four content pillars, all subordinate to the brand pillars named in the master brief:

- **Recovery** — sauna, cold, contrast, sleep, stress-shedding rituals
- **Movement** — mobility, yoga, pilates, strength, cardio, boxing
- **Performance** — HYROX prep, functional strength, small-group training
- **Mindfulness** — breathwork, meditation, sound, journaling nights

Plus **Longevity** as a cross-cutting theme woven into all four, and **Community** expressed through events, not classes.

Every piece of content — a class blurb, a whisper, an Instagram post, a printed card — is anchored to a pillar.

---

## 2. Weekly programming rhythm

Programming is deliberately slower than a typical gym schedule. Fewer classes, better classes, meaningful spacing.

### 2.1 Daily arc (Vasant Kunj, weekday)

| Time | Anchor session |
|---|---|
| 06:00 | Morning Reset (breath + mobility) |
| 07:00 | Restorative Yoga OR Pilates |
| 08:15 | Mobility Reset |
| 10:00 | Pilates Core (mid-morning) |
| 12:00 | Breathwork · Coherent (lunch break) |
| 16:00 | Strength Foundations |
| 18:00 | Strength & Conditioning OR HYROX Prep |
| 19:30 | Yin Yoga (Evening Wind Down) |
| 20:30 | Sound Bath (twice weekly) |
| 21:00 | Meditation |

Rituals available on-demand between 06:00 and 22:30.

### 2.2 Weekend arc

- Saturday morning long-form class (75-90 min) — Vinyasa or S&C
- Saturday afternoon Weekend Recharge ritual sessions (contrast + Paradiso pair)
- Sunday morning easy long walk to Sanctuary followed by a group Recovery Reset
- Sunday evening: **The Sunday Reset** — a signature ~90 min programme (heat, cold, tea, silence) hosted weekly, capacity limited

### 2.3 Seasonal shifts

- **Summer (Apr–Jun):** contrast and cold protocols emphasised; earlier morning starts (05:30)
- **Monsoon (Jul–Sep):** grounding, breath, mobility; more indoor evenings
- **Autumn (Oct–Nov):** performance push, HYROX season prep
- **Winter (Dec–Feb):** heat rituals, warm Paradiso menu, longer sleep-focused content
- **Spring (Mar):** reset month, cleanse-adjacent (never "detox") programming

---

## 3. Ritual catalogue

Five signature rituals at launch. Each is a composed sequence (Phase 3 §7) with a coach, room, and Paradiso pairing.

### 3.1 Morning Reset · 32 min
- Breath (10) · Mobility (12) · Warm ginger-lemon tea (10)
- Best after wake
- Contraindications: none

### 3.2 Recovery Reset · 50 min
- Sauna (15) · Ice bath (3) · Contrast finish (2) · Ginger tea (30)
- Post-workout or standalone recovery
- Contraindications: uncontrolled hypertension, cardiac, pregnancy

### 3.3 Evening Wind Down · 42 min
- Sauna (15) · Ice bath (3) · Turmeric latte (24)
- End of day, weekday
- Contraindications: as above

### 3.4 Weekend Recharge · 75 min
- Sauna (15) · Steam (12) · Ice bath (5) · Stretch (30) · Paradiso · quiet corner tea + fruit
- Saturday / Sunday afternoons
- Contraindications: as above

### 3.5 Longevity Reset · 90 min
- Breath (10) · Mobility (15) · Sauna (20) · Contrast (10) · Stretch (25) · Paradiso pair
- Weekly cadence, ideal for older members or high performers on rest days
- Contraindications: cardiac, pregnancy

Full text (name, blurb, prepare, contraindications, pair, coach quote, hero image) lives in the CMS with editor sign-off. Contraindications sync from the CMS to the `services` and `rituals` tables via a nightly job — the database is the enforcement layer, the CMS is the human-friendly layer.

---

## 4. Class catalogue and cadence

Complete class taxonomy from Phase 4 §4.4 rendered into weekly counts (Vasant Kunj, launch).

| Modality | Classes / week | Coach primary |
|---|---|---|
| Restorative Yoga | 5 | Meera |
| Vinyasa Yoga | 3 | Meera |
| Yin Yoga | 4 | Meera |
| Pilates (Mat) | 6 | Ananya |
| Pilates (Reformer, capacity 6) | 8 | Ananya |
| Barre | 2 | Ananya |
| Mobility Reset | 5 | Karan |
| Strength & Conditioning | 5 | Rohan |
| HYROX Prep | 3 | Priya |
| Functional | 2 | Rohan |
| Boxing | 3 | Vikram |
| Kickboxing | 2 | Vikram |
| Cardio (Row / Spin) | 3 | Priya |
| Breathwork · Coherent | 3 | Aarav |
| Breathwork · Wim Hof | 1 | Aarav |
| Meditation | 4 | Aarav |
| Sound Bath | 2 | Guest artist |
| Personal Training slots | 40 hours | Various |
| Small-group training slots | 20 hours | Various |
| Kids (weekend) | 2 | Play Haus Kids |

Total: ~65 group sessions/week + PT/SGT. Deliberately restrained.

Class descriptions live in the CMS with a shared voice audit — same reviewers as whispers.

---

## 5. Special events and workshops

Not add-on revenue. Programming that binds the club.

### 5.1 Recurring

- **The Sunday Reset** (weekly) — 90-min signature evening
- **New Moon Breathwork** (monthly) — extended breathwork evening with sound
- **Member Kitchen** (monthly) — cooking demo at Paradiso; small groups
- **Coach Series** (fortnightly) — one-hour deep dive with a coach on a theme (sleep, HRV, hydration)

### 5.2 Quarterly

- **Longevity Weekend** — full Saturday programming: talks, workshops, group rituals
- **Coach Residency** — visiting international coach or physiotherapist
- **Member Dinner** — Paradiso, invite-only, seasonally themed

### 5.3 Annual

- **The Sanctuary Retreat** — 3-day off-site (Ranthambore, Kasauli, Rishikesh) for Resident+ members
- **Founder Circle Evening** — private, unpublished
- **Anniversary Week** — closing every February with reflection programming and a small physical gift for every member

Ticketing (where applicable) via the same `events` table (Phase 3 §14). RSVP creates a reservation-shaped record so the same policies apply.

---

## 6. Editorial voice and calendar

### 6.1 Where editorial appears

- **In-app** — ritual descriptions, class blurbs, coach bios, programming notes, empty and error states
- **Website** — marketing, longer editorial (member letters, journal), waitlist page
- **Email** — magic-link, receipts, monthly letter, event invites
- **WhatsApp** — pre-arrival, waitlist, milestones (short forms)
- **Physical** — welcome kit, membership card, printed dinner menus, farewell cards

### 6.2 Rules

- Sentences under 20 words on average.
- One idea per sentence.
- Prefer verbs to adjectives ("we hold your seat" > "we have a great cancellation policy").
- Named coaches wherever possible.
- No trend words (biohack, dopamine detox, longevity stacks). Longevity is a discipline, not a product.

### 6.3 Editorial calendar (launch quarter)

| Week | Long-form on website | Monthly letter theme | Physical print |
|---|---|---|---|
| 1 | *"Why we built Sanctuary"* — Rohan | Welcome | Welcome card |
| 2 | *"The seven pillars, in one paragraph each"* | — | — |
| 3 | *"On cold water, without the theatre"* — Ritika | — | — |
| 4 | *"An evening at Sanctuary"* — a member's account | — | — |
| 5 | *"Sleep, without the tracker"* — Aarav | — | — |
| 6 | *"Why our classes are quieter"* — Meera | Rhythm | — |
| 7 | *"A note from the founder"* | — | — |
| 8 | *"The Sunday Reset, explained"* | — | — |
| 9 | *"On not tracking your weight"* — Coach panel | — | — |
| 10 | *"The mobility we've all lost"* — Karan | — | — |
| 11 | *"Paradiso, and the case for slow tea"* | Ritual | Recipe card |
| 12 | *"What we don't do"* | — | — |

Content commissioning: 2 coaches + 1 external writer + 1 editor. Cadence sustainable at 1 piece/week.

---

## 7. Notifications & whispers content plan

Concierge whisper library (V1). Each has a variable-body template approved with the WhatsApp BSP.

- Pre-arrival (24h, 2h)
- Ritual reminder (recurring member's usual)
- Post-ritual feedback ask
- Recovery Index below-trend nudge
- Recovery Index rising acknowledgement (rare)
- Missed-day check-in (7 days since last visit)
- Streak recognition (silent, at 10 / 25 / 50)
- Milestone (100 hours, tier change, anniversary)
- Health-form due
- Guest pass claimed (to referrer)
- Referral converted (to referrer)
- Paradiso "your usual is warm" (on arrival)
- Weather-adaptive suggestion (hot day → contrast; cold day → sauna)
- Ops-issued announcement (rare; coach-of-the-week, seasonal note)

Each template ships with:
- Body prompt template (versioned)
- Fixture set (10 examples reviewed by product + coach)
- Do-not-send rules (quiet hours, opt-out, safety context)

---

## 8. Paradiso menu language

The menu is a member touchpoint, not a marketing document.

- Ingredient-forward: *"turmeric latte · warmed almond milk, ginger, black pepper"*
- No caloric counts on the menu (available on request)
- No slogans. No decorative descriptors ("hand-crafted", "artisanal")
- Prices in rupees, unrounded and honest
- Seasonal rotation with a small "off menu today" line for anything unavailable
- "Your usual" prominence on member's own view of the menu

---

## 9. Member letters (long-form)

Once a month, signed by Rohan (or a guest coach), 350–600 words. Read like a note, not a newsletter. Delivered by email; a printed version mailed quarterly to Resident+ members.

Themes for Year-1:
- Feb: A quiet beginning
- Mar: What rest is, and isn't
- Apr: On heat and cold in equal measure
- May: The middle of the year
- Jun: A short letter (monsoon)
- Jul: The people who work here
- Aug: What we learned by watching you
- Sep: On not chasing outcomes
- Oct: The season for effort
- Nov: A softer November
- Dec: The end of the year, without a list
- Jan: An invitation, not a resolution

Editorial oversight: founder + product + coach lead sign off each letter before send.

---

## 10. Content operations

- **Owners:** Editor (part-time contractor Year-1, in-house Year-2), plus one product-side reviewer.
- **Tools:** Google Docs → CMS. Legal reviews T&Cs. Coach reviews any content mentioning protocol.
- **Rhythm:**
  - Weekly: content standup (30 min)
  - Bi-weekly: whisper audit (30 min)
  - Monthly: editorial planning, letter review
  - Quarterly: content retrospective + brand alignment check
- **Style guide:** doc-a Brand Bible §6 (Copywriting Guidelines). Any exception requires a note in the PR.
- **Localisation:** V1 English only. Hindi transliteration for coach names, service names in signage; Hindi content targeted for Year-2.

---

## 11. Review checklist

- [ ] Pillar model (Recovery / Movement / Performance / Mindfulness + Longevity cross-cut + Community) covers V1
- [ ] Programming rhythm (fewer, better, meaningful spacing) is the right differentiation from big gyms
- [ ] Ritual catalogue (5 signatures) is the right launch surface
- [ ] Class catalogue counts (~65 sessions/week) match trainer capacity and rooms
- [ ] Special events cadence (weekly Sunday Reset, monthly New Moon, quarterly Longevity, annual Retreat) is achievable
- [ ] Editorial voice rules and monthly letter cadence agreed
- [ ] Whisper library scope (14 kinds at V1) is enough — nothing missing
- [ ] Paradiso menu language rules are honoured by F&B
- [ ] Content ops (editor, tools, rhythm) is staffed
