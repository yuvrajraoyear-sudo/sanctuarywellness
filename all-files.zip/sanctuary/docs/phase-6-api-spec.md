# Phase 6 — API & Endpoint Spec

**Sanctuary Wellness by Play Haus**
Version 1.0 · draft for review

The API contract that connects the Next.js app, the ops console, the staff tablet, and third-party systems (Razorpay, WhatsApp BSP, Resend, PostHog, the Concierge LLM). Grounded in Phase 3 tables and Phase 4 flows; consumed by Phase 5 components.

Sections:
1. API principles & conventions
2. Auth model
3. Errors, idempotency, rate limits, pagination
4. Domain surfaces (11 domains)
5. Webhook contracts (Razorpay, WhatsApp, email delivery)
6. Concierge LLM call contract
7. Realtime & background jobs
8. Observability, audit, versioning
9. Client SDK & type generation
10. Review checklist + open questions

---

## 1. API principles & conventions

- **Two protocols.** REST-style HTTP JSON for CRUD-shaped resources; a small set of **RPC** endpoints for domain actions that don't fit REST cleanly (`reserve_ritual`, `cancel_reservation`, `hold_slot`, `resolve_recovery_index`, `page_ops`). Both live under `/api/v1/`.
- **Framework.** Next.js Route Handlers (`app/api/**/route.ts`) for the app; Supabase Postgres functions for hot paths that must be transactional (slot-hold, reservation create).
- **Schema everywhere.** Zod for request and response validation; types exported to clients.
- **Content type.** `application/json; charset=utf-8` on requests and responses.
- **Time.** All timestamps are ISO-8601 UTC with `Z` suffix on the wire. Rendering in IST is a client concern.
- **Money.** `amount_paise` (integer) + `currency` ("INR" default). Never floats.
- **IDs.** UUIDv4 for domain resources. `res_*`, `mem_*`, `sess_*` prefixes only in URLs and human-facing artefacts (invoices), not stored.
- **Case.** `snake_case` on the wire (matches Postgres columns); TypeScript types re-map to `camelCase` on the client via a single utility.
- **Enums.** Wire values match Postgres enum labels exactly (`ritual_state`, `payment_status`, etc. from Phase 3).
- **No trailing slashes.**
- **Immutable resources** are addressable at `/domain/{id}`; state-changing verbs live as RPC (`/reservations/{id}/cancel` returns the new state).
- **PATCH is partial.** PUT is used only for full-object replacement (rare).
- **Locale.** Accept `Accept-Language`; V1 responds `en-IN` only. Future `hi-IN`, `mr-IN`.

### 1.1 Base URLs

| Env | Base URL |
|---|---|
| Local | `http://localhost:3000/api/v1` |
| Preview | `https://preview-{sha}.sanctuary.playhaus.club/api/v1` |
| Staging | `https://staging.sanctuary.playhaus.club/api/v1` |
| Production | `https://app.sanctuary.playhaus.club/api/v1` |

### 1.2 Response envelope

Success:

```json
{ "data": { ... }, "meta": { "request_id": "01J...", "server_time": "2026-07-09T18:41:22Z" } }
```

List:

```json
{
  "data": [ { ... }, { ... } ],
  "meta": {
    "request_id": "01J...",
    "page": { "cursor": "eyJ...", "has_more": true, "limit": 20 }
  }
}
```

Error (see §3.1):

```json
{
  "error": {
    "code": "validation_failed",
    "message": "Human message.",
    "field_errors": [ { "path": "email", "message": "not a valid email" } ]
  },
  "meta": { "request_id": "01J..." }
}
```

Never return raw stack traces. Never return raw gateway messages.

---

## 2. Auth model

- **Identity.** Supabase Auth issues short-lived JWTs (RS256, 1h) + refresh tokens (30d rolling) after a magic-link sign-in. Sessions bound to device fingerprint.
- **Transport.** Access token in `Authorization: Bearer <jwt>`. Refresh via `POST /auth/refresh` — refresh token in httpOnly cookie.
- **Row-level security.** Every table has RLS policies (Phase 3). The JWT `sub` = `members.id`. Server code executes as the requester by default; service-role bypass only in privileged jobs (webhooks, cron).
- **Roles.**
  - `member` — default
  - `guest` — pre-onboarded, limited scope
  - `staff` — front-desk (tablet), scoped to their location
  - `trainer` — scoped to their `trainer_assignments`
  - `ops` — Concierge Ops, safety-event queue, back-office
  - `admin` — root; requires step-up
- **Step-up.** Payment mandate changes, health-record edits, admin actions require a `x-step-up: sms|passkey` header issued via `/auth/step-up`. TTL 5 min, single-use.
- **CSRF.** Not needed for pure JWT flows. Cookie-based refresh uses `SameSite=strict`.
- **Origin allow-list.** `app.sanctuary.playhaus.club`, `staging.*`, `admin.*`, `staff.*`. Any other origin returns 403.

### 2.1 Auth endpoints

| Method | Path | Purpose | Auth |
|---|---|---|---|
| POST | `/auth/challenge` | Send magic-link to email | none |
| POST | `/auth/verify` | Exchange magic-link token for session | none |
| POST | `/auth/refresh` | Rotate access token via refresh cookie | refresh-cookie |
| POST | `/auth/signout` | Invalidate current session | bearer |
| POST | `/auth/passkey/register` | Register WebAuthn credential | bearer |
| POST | `/auth/passkey/authenticate` | Sign in with passkey | none |
| POST | `/auth/step-up` | Request step-up token (SMS/passkey) | bearer |

`POST /auth/challenge` request:

```json
{ "email": "yuvraj@example.com", "purpose": "signin" }
```

Response: always `{ "data": { "sent": true } }` — never disclose whether the email is known.

---

## 3. Errors, idempotency, rate limits, pagination

### 3.1 Error codes

`code` is a stable machine string; `message` may change.

| HTTP | Code | Meaning |
|---|---|---|
| 400 | `validation_failed` | Zod / semantic validation |
| 400 | `contraindication_present` | Health flag blocks action |
| 401 | `unauthenticated` | No / invalid token |
| 401 | `session_expired` | Refresh required |
| 403 | `forbidden` | RLS or role denies |
| 403 | `step_up_required` | Needs elevated auth |
| 404 | `not_found` | Resource not visible |
| 409 | `conflict` | State transition invalid |
| 409 | `slot_unavailable` | Capacity reached / concurrent booking |
| 410 | `hold_expired` | Slot-hold TTL passed |
| 422 | `policy_violation` | Cancel window, strike rule, etc. |
| 423 | `locked` | Payment in flight, cannot cancel |
| 429 | `rate_limited` | Too many requests |
| 500 | `internal_error` | Unhandled |
| 503 | `dependency_down` | Razorpay / BSP / LLM unavailable |

Response always includes `request_id`. Client shows generic warm copy per Phase 5 §10.2.

### 3.2 Idempotency

All non-GET requests may include `Idempotency-Key: <uuid>`. **Required** for:
- `POST /reservations`
- `POST /rituals/{id}/reserve`
- `POST /payments/checkout`
- `POST /waitlist/holds`
- `POST /concierge/actions/{id}/confirm`

Server stores `(idempotency_key, request_fingerprint, response)` for 24h; identical retries return the stored response; different fingerprint under the same key returns `409 idempotency_conflict`.

### 3.3 Rate limits

Token-bucket per member and per IP.

| Bucket | Limit | Window |
|---|---|---|
| Global per member | 300 req | 1 min |
| Auth challenge | 5 req | 1 min |
| Reservation create | 20 req | 1 min |
| Concierge conversation | 30 msg | 1 min |
| Search / list | 120 req | 1 min |
| Webhook receivers | 600 req | 1 min |

`429` includes `Retry-After` header.

### 3.4 Pagination

Cursor-based. `?limit=20&cursor=<opaque>` on list endpoints. Cursors are opaque base64; do not attempt to inspect them.

### 3.5 Filtering & sorting

`?filter[field]=value&sort=starts_at:asc,-intensity`. Whitelisted per endpoint. Never expose free-form SQL.

---

## 4. Domain surfaces

Eleven domains, aligned to Phase 4 flows and Phase 3 tables.

Legend: [M] member, [G] guest, [S] staff, [T] trainer, [O] ops, [A] admin.

### 4.1 Members

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/me` | Current member profile + status + tier | M/G/S/T |
| PATCH | `/me` | Update name, avatar, comms prefs | M |
| GET | `/me/signature` | Member Signature (locker, sauna, tea, coach, music) | M |
| PATCH | `/me/signature` | Update Signature (partial) | M |
| GET | `/me/health` | Health record | M |
| PATCH | `/me/health` | Update health (step-up required) | M |
| GET | `/me/timeline` | Milestones + recent activity | M |
| GET | `/me/status` | Recovery Index band, streak, visits | M |
| GET | `/members/{id}` | Ops/trainer view of member | S/T/O |
| PATCH | `/members/{id}` | Ops updates (status, tier, notes) | O |

`GET /me` response (abridged):

```json
{
  "data": {
    "id": "uuid",
    "name": "Yuvraj",
    "email": "yuvraj@example.com",
    "phone_e164": "+91XXXXXXXXXX",
    "status": "member",
    "tier": "resident",
    "joined_at": "2026-02-12T09:00:00Z",
    "home_location_id": "uuid",
    "trainer_id": "uuid",
    "comms": { "whatsapp": true, "email": true, "push": true, "quiet_hours": ["22:00","07:00"] }
  }
}
```

### 4.2 Locations, rooms, trainers

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/locations` | Locations with hours | all |
| GET | `/locations/{id}` | Detail | all |
| GET | `/locations/{id}/rooms` | Rooms + capacity | S/O/A |
| GET | `/trainers` | Directory (public bios) | all |
| GET | `/trainers/{id}` | Detail | all |
| GET | `/trainers/{id}/schedule` | Availability window | M/S/O |

### 4.3 Services & rituals catalog

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/services` | Recovery services catalog | all |
| GET | `/services/{id}` | Detail with variants | all |
| GET | `/rituals` | Composed rituals | M/G |
| GET | `/rituals/{id}` | Detail: composition, contraindications, pairing | M/G |
| GET | `/rituals/{id}/availability` | Available times for date range | M/G |

`GET /rituals/{id}/availability` query: `?location_id=uuid&from=2026-07-09&to=2026-07-14`

Response:

```json
{
  "data": {
    "ritual_id": "uuid",
    "slots": [
      { "starts_at": "2026-07-10T13:15:00Z", "room_id": "uuid", "trainer_id": "uuid", "seats_remaining": 1 },
      { "starts_at": "2026-07-10T14:00:00Z", "room_id": "uuid", "trainer_id": "uuid", "seats_remaining": 2 }
    ]
  }
}
```

### 4.4 Classes & sessions

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/classes` | Day view; filters: pillar, modality, coach, intensity | all |
| GET | `/classes/{id}` | Session detail | all |
| GET | `/classes/day` | `?date=YYYY-MM-DD` grouped day view | M/G |

Query example: `/classes?pillar=movement&intensity=hard&date=2026-07-10&coach=uuid`

### 4.5 Reservations & waitlist

The transactional core. Slot-hold + reservation is a two-step ceremony to prevent double-booking under concurrency.

| Method | Path | Purpose | Roles |
|---|---|---|---|
| POST | `/waitlist/holds` | Create a 3-min slot-hold | M |
| DELETE | `/waitlist/holds/{id}` | Release a hold | M |
| POST | `/reservations` | Convert hold → reservation, or direct book | M |
| GET | `/reservations` | Member's reservations (upcoming/past) | M |
| GET | `/reservations/{id}` | Detail | M/S/O |
| POST | `/reservations/{id}/cancel` | Cancel (applies policy) | M/S/O |
| POST | `/reservations/{id}/check-in` | Staff check-in | S/O |
| POST | `/reservations/{id}/feedback` | Post-ritual feedback | M |
| POST | `/waitlist/join` | Join class waitlist | M |
| POST | `/waitlist/offers/{id}/accept` | Accept offer | M |
| POST | `/waitlist/offers/{id}/decline` | Decline offer | M |

`POST /waitlist/holds` request:

```json
{
  "kind": "reservation",
  "ritual_id": "uuid",
  "starts_at": "2026-07-10T13:15:00Z",
  "location_id": "uuid",
  "trainer_id": "uuid",
  "notes": null
}
```

Response:

```json
{
  "data": {
    "id": "uuid",
    "expires_at": "2026-07-09T18:44:22Z",
    "ttl_seconds": 180
  }
}
```

`POST /reservations` request (from hold):

```json
{
  "hold_id": "uuid",
  "payment_method": { "kind": "membership_credit" }
}
```

Response: full reservation object with child slots and pre-arrival note timing.

`POST /reservations/{id}/cancel` response includes policy outcome:

```json
{
  "data": {
    "id": "uuid",
    "status": "cancelled_late",
    "refund_kind": "credit",
    "refund_amount_paise": 0,
    "strike_incremented": true,
    "note_shown_to_member": "We'll let the room breathe. This one's on us — but if it becomes a rhythm, we'll check in."
  }
}
```

### 4.6 Memberships & billing

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/plans` | Public plan catalog | all |
| GET | `/me/membership` | Active plan, credits, renewal date | M |
| POST | `/memberships` | Purchase (returns Razorpay checkout options) | M |
| POST | `/memberships/{id}/pause` | Self-serve pause | M |
| POST | `/memberships/{id}/resume` | End pause | M |
| POST | `/memberships/{id}/upgrade` | Change plan up | M |
| POST | `/memberships/{id}/downgrade` | Schedule downgrade | M |
| POST | `/memberships/{id}/cancel` | Cancel at cycle end | M |
| GET | `/invoices` | List | M |
| GET | `/invoices/{id}` | Detail + PDF URL | M |
| POST | `/payments/checkout` | Get Razorpay order for arbitrary charge | M |
| POST | `/payments/mandates` | Create e-mandate | M |
| DELETE | `/payments/mandates/{id}` | Cancel mandate | M |

`POST /memberships` response includes:

```json
{
  "data": {
    "membership_id": "uuid",
    "razorpay": {
      "order_id": "order_...",
      "key_id": "rzp_live_...",
      "amount_paise": 4500000,
      "currency": "INR",
      "mandate": { "required": true, "options": { ... } }
    }
  }
}
```

Client hands `razorpay` blob to the Razorpay web SDK; server confirms via webhook (§5.1).

### 4.7 Concierge

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/concierge/whispers` | Ready + delivered whispers for member | M |
| POST | `/concierge/whispers/{id}/dismiss` | Ack + hide | M |
| POST | `/concierge/conversations` | Open a new conversation | M |
| GET | `/concierge/conversations/{id}` | Fetch messages | M |
| POST | `/concierge/conversations/{id}/messages` | Send a member message | M |
| POST | `/concierge/actions/{id}/confirm` | Execute a proposed action | M |
| POST | `/concierge/actions/{id}/decline` | Decline | M |
| GET | `/ops/concierge/queue` | Ops queue: safety events, takeovers | O |
| POST | `/ops/concierge/{conversation_id}/takeover` | Human takes over | O |

`POST /concierge/conversations/{id}/messages` — see §6 for the LLM call contract.

### 4.8 Recovery Index & wellness

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/me/recovery-index` | Current band + narrative + inputs | M |
| POST | `/me/recovery-index/self-report` | Sleep, energy, mood, soreness | M |
| POST | `/me/wellness-metrics` | Bulk upload (integrations later) | M |
| GET | `/me/wellness-metrics` | Recent metrics | M |

`GET /me/recovery-index` response:

```json
{
  "data": {
    "date": "2026-07-09",
    "band": "steady",
    "components": [
      { "kind": "sleep", "band": "steady", "detail": "6h48m avg last 3 nights" },
      { "kind": "load", "band": "high", "detail": "Three high-intensity sessions" },
      { "kind": "self_report_mood", "band": "steady", "detail": "3 of 5" }
    ],
    "narrative": "You've had three intense sessions. Sleep is down slightly. Steady, with room to rest."
  }
}
```

Numeric score never surfaced at member level.

### 4.9 Timeline, tiers, rewards

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/me/timeline` | Milestones + attended visits | M |
| GET | `/me/tier` | Current, next thresholds | M |
| GET | `/me/rewards` | Ledger (experience credits) | M |
| GET | `/me/challenges` | Active challenges | M |
| POST | `/me/challenges/{id}/join` | Opt-in | M |
| GET | `/me/badges` | Earned badges | M |

### 4.10 Guest passes & referrals

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/me/guest-passes` | Available + issued | M |
| POST | `/me/guest-passes` | Issue a pass (link) | M |
| GET | `/guest/{token}` | Guest landing (no auth) | none |
| POST | `/guest/{token}/claim` | Guest intake + first-visit hold | none → guest |
| GET | `/me/referrals` | Referral link + tally | M |

### 4.11 Support, notifications, admin

| Method | Path | Purpose | Roles |
|---|---|---|---|
| GET | `/me/inbox` | In-app inbox | M |
| POST | `/me/inbox/{id}/read` | Mark read | M |
| GET | `/me/notification-preferences` | Channel prefs | M |
| PATCH | `/me/notification-preferences` | Update | M |
| POST | `/support/tickets` | Open ticket | M |
| GET | `/support/tickets` | List | M |
| GET | `/support/tickets/{id}` | Detail | M/O |
| POST | `/support/tickets/{id}/messages` | Reply | M/O |
| GET | `/ops/dashboard` | Today at a glance | S/O/A |
| GET | `/ops/reservations` | Ops schedule | S/O/A |
| POST | `/ops/announcements` | Global broadcast | A |
| GET | `/admin/audit` | Audit log | A |
| GET | `/admin/feature-flags` | Flags | A |
| PATCH | `/admin/feature-flags/{key}` | Toggle | A |

---

## 5. Webhook contracts

All inbound webhooks:
- Signed. Verify before parsing. Reject unsigned requests with 401.
- Idempotent. Store `(source, event_id)` uniqueness in `payment_events` / `webhook_events`.
- Fast-ack. Persist raw payload, enqueue processing job, respond 200 within 2s.
- Retriable. Sources retry with exponential backoff; do not attempt to acknowledge with anything other than 200 on success.

### 5.1 Razorpay

Endpoint: `POST /webhooks/razorpay`
Signature: `X-Razorpay-Signature` = HMAC-SHA256(body, webhook_secret).

Events handled:
- `payment.captured` — mark `payments.status = captured`; write `invoices`; if for membership, flip `memberships.status = active`
- `payment.failed` — mark failed; schedule retry; notify member
- `refund.processed` — write `refunds`
- `subscription.charged` / `subscription.halted` — for mandate renewals
- `order.paid` — canonical order confirmation

Payload storage: `payment_events(raw jsonb, event_id, kind, received_at, processed_at)`.

### 5.2 WhatsApp Business (BSP: Gupshup or AiSensy — TBD)

Endpoint: `POST /webhooks/whatsapp`
Signature: `X-Hub-Signature-256` (BSP-provided) verified against webhook secret.

Events:
- `message.delivered` — update `notifications.status`
- `message.read` — analytics only
- `message.received` — route to Concierge conversation (member reply to a whisper)
- `template.status` — template approval state

### 5.3 Email (Resend)

Endpoint: `POST /webhooks/resend`
Events: `email.delivered`, `email.opened`, `email.bounced`, `email.complained`. Updates `notifications`, feeds deliverability analytics.

### 5.4 Analytics egress

PostHog receives events server-side via `POST` to PostHog's ingest with the project key (server-side capture; no PII).

---

## 6. Concierge LLM call contract

Two model calls:
- **Whisper composer** — offline / scheduled, produces a `concierge_whispers` row
- **Conversation** — online, member turn ↔ system turn

### 6.1 Provider & model

- Provider: to be chosen from OpenAI / Anthropic / Google (Phase 8 evaluation). Contract is provider-agnostic.
- Response format: JSON strict (via tool-call or `response_format: json_schema`).
- Prompt versioning: prompts committed in `packages/concierge/prompts/{name}@{semver}.md`; version stored on every `concierge_messages` row.

### 6.2 Whisper composer

Server-side job triggers on any of: post-ritual completed, recovery-index band change, missed-day streak, birthday-week, milestone-imminent, health-form due.

Request to LLM (abridged):

```json
{
  "prompt_id": "whisper_composer@1.3.0",
  "context": {
    "member": {
      "name": "Yuvraj",
      "tier": "resident",
      "tenure_days": 148,
      "recent_rituals": ["Recovery Reset (2d ago)", "Evening Wind Down (5d ago)"],
      "recovery_band_last_7": ["steady","steady","below","below","below","steady","steady"],
      "signature": { "sauna_temp": 78, "tea": "ginger", "coach": "Ritika" }
    },
    "trainer_of_record": { "name": "Ritika", "role": "Recovery Coach" },
    "trigger": { "kind": "recovery_below_streak", "days": 3 }
  },
  "constraints": {
    "voice": "warm, quiet, precise, attributed",
    "banned_words": ["crush","beast","grind","insane","level up","hustle","sesh","buddy"],
    "medical_claims_forbidden": true,
    "max_sentences": 3
  },
  "response_schema": "WhisperOutput@1"
}
```

`WhisperOutput` schema:

```ts
type WhisperOutput = {
  attribution: { name: string; role: string } | null; // null → system whisper
  body: string;                                        // 1–3 sentences
  action?: {
    label: string;                                     // "Hold Friday 7:30"
    kind: "hold_reservation" | "open_ritual" | "open_class" | "open_conversation";
    payload: Record<string, unknown>;
  };
  confidence: number;                                  // 0..1
}
```

Server validates:
- No banned words
- No medical claim regex hits ("cures", "treats", "will lower your blood pressure by ...")
- Sentence count within bound
- Attribution matches an active trainer for the member if provided

Failing any check ⇒ discard, do not deliver, log to `concierge_validation_failures`.

### 6.3 Conversation turn

`POST /concierge/conversations/{id}/messages`

Request body (from client):

```json
{ "text": "Should I skip cold plunge tomorrow?" }
```

Server assembles the LLM request with:
- Full conversation history (last 20 turns; earlier summarised)
- Latest Recovery Index and last 3 ritual feedback entries
- Member health flags (redacted; only categorical: `no_ice_bath: false`, `pregnancy: false`, etc.)
- The whisper that triggered the conversation (if any)

`ConversationOutput` schema:

```ts
type ConversationOutput = {
  reply_text: string;                                  // 1–4 sentences
  actions: Array<{
    kind: "hold_reservation" | "cancel_reservation" | "open_ritual" | "open_class" | "book_paradiso";
    label: string;
    payload: Record<string, unknown>;
    requires_confirmation: true;                       // always true for state-changing actions
  }>;
  safety_flag: null | {
    kind: "medical_urgency" | "mental_health" | "pregnancy" | "third_party_health";
    detail: string;
  };
  handoff_to_ops: boolean;                             // true if safety_flag is set
}
```

**On `safety_flag != null` or `handoff_to_ops = true`:**
- Server **replaces** `reply_text` with the scripted safety response (Phase 4 §7.7)
- Emits `concierge_safety_event`
- Pages Ops on-call (Slack + SMS)
- Suspends LLM turn generation on this conversation until Ops explicitly returns control

### 6.4 Tool-use / action execution

Actions are proposals, never executions. The server writes them to `concierge_actions` with `status = proposed`. The client renders them as `ConciergeAction` cards (Phase 5 §6.23). On member confirmation, `POST /concierge/actions/{id}/confirm` executes the underlying domain call (reservation, cancel, etc.) with all the usual validations. Rate-limited, idempotent.

### 6.5 Data minimisation

The LLM never receives:
- Email, phone, address
- Payment details
- Numeric Recovery Index score (only bands and narrative)
- Free-text health notes (only categorical flags)

### 6.6 Cost & latency budget

- Whisper composer: < 6s p95, < ₹0.5 per whisper (target)
- Conversation turn: < 3s p95, < ₹0.3 per turn (target)
- Fallback: if the LLM is unavailable, `dependency_down` returned to client; client shows *"Concierge is stepping away for a moment — we'll come find you."*

---

## 7. Realtime & background jobs

### 7.1 Realtime

Supabase Realtime channels for:
- `reservations:member:{member_id}` — status changes
- `waitlist:offers:{member_id}` — offer delivery
- `concierge:conversations:{conversation_id}` — new messages (fallback to polling if WS unsupported by client)
- `ops:dashboard:{location_id}` — live check-ins for staff tablet

Channels are auth-scoped via Supabase RLS on `realtime.messages`.

### 7.2 Scheduled jobs

Postgres `pg_cron` (or platform scheduler) drives:

| Job | Cadence | Purpose |
|---|---|---|
| `recovery_index_recompute` | 03:00 IST daily | Read inputs, write `recovery_index_daily`, emit triggers |
| `whisper_dispatch` | every 5 min | Deliver ready whispers respecting quiet hours |
| `waitlist_release` | every 1 min | Convert cancellations into offers |
| `slot_hold_expiry_sweep` | every 30 sec | Release expired holds |
| `renewal_reminders` | 08:00 IST daily | −14d, −3d, day-of |
| `payment_retry` | 09:00 IST daily | Retry failed payments |
| `strike_forgive_sweep` | 06:00 IST daily | Rolling 60-day forgiveness |
| `timeline_milestone_writer` | 04:00 IST daily | Compute new milestones |
| `analytics_rollup` | 04:30 IST daily | Materialised views for ops dashboard |
| `off_boarding_farewell_queue` | 07:00 IST daily | Print-farewell queue export |

### 7.3 Queues

Job queue: pg-boss (Postgres-native) or Inngest/QStash for HTTP-triggered work (webhooks). Retries with jittered exponential backoff (max 5).

---

## 8. Observability, audit, versioning

- **Request IDs.** `X-Request-Id` accepted from clients, else generated (ULID). Propagated to logs and downstream calls.
- **Structured logs.** JSON to stdout; ingested by Grafana Loki (or similar). Redact PII (email, phone) at the log adapter.
- **Metrics.** Latency, error rate, saturation per endpoint; SLOs at 99% < 300ms for GET, < 800ms for reservation POST.
- **Traces.** OpenTelemetry; sampling 10% baseline, 100% on 5xx and slow spans.
- **Audit.** Every state-changing endpoint writes to `audit_log(who, action, target_kind, target_id, before, after, ip, ua)`. RLS restricts reads to admins.
- **Versioning.** Path-versioned (`/v1`). Additive changes non-breaking; breaking changes ship a new version and a 90-day deprecation window. Deprecated fields return `Deprecation` and `Sunset` headers.

---

## 9. Client SDK & type generation

- **Server-side.** Zod schemas live in `packages/api-contracts/` and are imported by route handlers.
- **Client.** `packages/api-client/` exposes typed functions per endpoint (`api.rituals.availability({ id, from, to })`) built on `fetch` + TanStack Query hooks (`useRitualAvailability`).
- **Types.** Generated once from Zod (`z.infer`) — a single source of truth. No hand-written duplicates.
- **Supabase types.** Postgres types generated by `supabase gen types` for direct-table reads only (reference lists, dropdowns). All member-visible reads go through API endpoints for shaping.
- **OpenAPI.** Emitted from Zod via `zod-to-openapi` for third-party integrations (invoicing partner, hardware devices later).

---

## 10. Review checklist — Phase 6

Please confirm before Phase 7 (Non-Functional Requirements & Architecture):

- [ ] The **base URL and versioning** scheme (`/api/v1`) is acceptable
- [ ] The **snake_case wire format** matching Postgres is the right call, with a client-side camelCase remap
- [ ] The **auth model** (Supabase JWT + refresh cookie + step-up + role matrix) covers member / guest / staff / trainer / ops / admin
- [ ] The **error code catalogue** is complete and stable (any missing codes?)
- [ ] The **idempotency requirement** on the five listed POSTs is right
- [ ] The **rate-limit shape** feels correct
- [ ] The **11 domain surfaces** cover the V1 flows without gaps
- [ ] The **two-step slot-hold + reserve** ceremony is the right primitive for concurrency
- [ ] The **webhook set** (Razorpay + WhatsApp + Resend) plus fast-ack + idempotency pattern is committed
- [ ] The **Concierge LLM contract** (schema-strict, safety flag replaces reply, action proposals + explicit confirm) is the right shape
- [ ] The **data minimisation** rules for the LLM (no email/phone/score/free-text health) are acceptable
- [ ] The **cost/latency budget** for LLM calls is realistic given target providers
- [ ] The **realtime channels** and **scheduled job list** cover what Phase 4 flows need
- [ ] The **audit / observability** approach (structured logs, OTel, per-endpoint SLOs) is agreed
- [ ] The **type-generation** approach (Zod → TS + OpenAPI) fits the team

## Open questions

1. **REST vs. tRPC.** I've specified REST for external clarity and easy OpenAPI. Would tRPC (typed end-to-end) be preferred internally, with a thin REST layer for third parties? Trade-off: tRPC removes boilerplate but hides the wire.
2. **Realtime transport.** Supabase Realtime (WebSocket + Postgres LISTEN) is the default. Confirm we're OK with WebSocket, given the sandbox note that WS isn't supported in the current hosting preview — for production Vercel/managed hosts, WS is fine.
3. **BSP choice.** Gupshup vs. AiSensy — decide before webhook signature format is finalised.
4. **LLM provider.** OpenAI (gpt-4.1 / gpt-4o) vs. Anthropic (Claude Sonnet 4) vs. Google (Gemini 2.5). Recommend a bake-off in Phase 8 with 30 real whispers + 20 conversation turns, scored on voice fidelity, safety, latency, cost.
5. **Step-up channel.** SMS OTP vs. passkey re-prompt vs. WhatsApp OTP. Recommend passkey primary, SMS OTP fallback.
6. **PDF invoices.** Server-side render (Puppeteer / pdfkit) vs. delegate to Razorpay's invoice product. Recommend server-side for brand control.
7. **Search.** No search endpoint yet. Do we need free-text search across classes/coaches at V1, or is filter+sort enough?

## Hand-off to Phase 7

Once approved, Phase 7 (Non-Functional Requirements & Architecture) will define:
- SLOs, SLIs, and the reliability budget
- Environment topology (regions, edge, database, storage, cache)
- Security posture: OWASP top-10 stance, secrets management, PII handling, encryption at rest and in transit
- Compliance: DPDP Act, GST, RBI e-mandate, health-data handling
- Backup, restore, disaster recovery
- Performance budgets (LCP, INP, TTFB per page)
- Cost model at 1k, 5k, 20k members
- Deployment topology (Vercel + Supabase + Cloudflare + object storage)
- CI/CD, previews, migrations, feature-flag rollout
