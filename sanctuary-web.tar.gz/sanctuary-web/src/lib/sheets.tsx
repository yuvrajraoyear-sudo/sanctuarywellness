"use client";

import { createContext, useContext, useState, useCallback, ReactNode } from "react";

type SheetName = "ritual" | "booking" | "topup" | "concierge" | null;

interface SheetContextValue {
  open: SheetName;
  openSheet: (name: SheetName) => void;
  closeSheets: () => void;
}

const SheetContext = createContext<SheetContextValue | null>(null);

export function SheetProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState<SheetName>(null);
  const openSheet = useCallback((name: SheetName) => setOpen(name), []);
  const closeSheets = useCallback(() => setOpen(null), []);
  return (
    <SheetContext.Provider value={{ open, openSheet, closeSheets }}>
      {children}
      <div className={`scrim${open ? " show" : ""}`} onClick={closeSheets} />
    </SheetContext.Provider>
  );
}

export function useSheets() {
  const ctx = useContext(SheetContext);
  if (!ctx) throw new Error("useSheets must be used within SheetProvider");
  return ctx;
}
