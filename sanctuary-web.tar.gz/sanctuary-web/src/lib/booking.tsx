"use client";

import { createContext, useContext, useState, useCallback, ReactNode } from "react";
import { BookingItem } from "@/data/catalogue";

interface BookingContextValue {
  pending: BookingItem | null;
  setPending: (item: BookingItem | null) => void;
  neededPaise: number;
  setNeededPaise: (p: number) => void;
}

const BookingContext = createContext<BookingContextValue | null>(null);

export function BookingProvider({ children }: { children: ReactNode }) {
  const [pending, setPending] = useState<BookingItem | null>(null);
  const [neededPaise, setNeededPaise] = useState(0);
  const setP = useCallback((item: BookingItem | null) => setPending(item), []);
  return (
    <BookingContext.Provider value={{ pending, setPending: setP, neededPaise, setNeededPaise }}>
      {children}
    </BookingContext.Provider>
  );
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error("useBooking must be used within BookingProvider");
  return ctx;
}
