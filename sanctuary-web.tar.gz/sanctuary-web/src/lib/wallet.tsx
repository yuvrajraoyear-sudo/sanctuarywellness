"use client";

import { createContext, useContext, useState, useCallback, ReactNode } from "react";

// The credit wallet. In production, balance and ledger load from Supabase and
// deductions run server-side (a Postgres function that checks funds atomically).
// This client context mirrors that shape so the UI is complete now and the swap
// is a matter of replacing the mutating calls with API calls.

export interface LedgerEntry {
  label: string;
  when: string;
  deltaPaise: number;
}

export interface WalletState {
  plan: string;
  planPricePaise: number;
  grantedPaise: number;
  balancePaise: number;
  renews: string;
  ledger: LedgerEntry[];
}

const initialWallet: WalletState = {
  plan: "Basic · Quarterly",
  planPricePaise: 1800000, // ₹18,000 paid
  grantedPaise: 2100000, // ₹21,000 granted (₹3,000 bonus)
  balancePaise: 1650000, // demo starting balance
  renews: "24 Sep 2026",
  ledger: [
    { label: "Recovery Reset ritual", when: "Tue", deltaPaise: -90000 },
    { label: "Vinyasa Flow", when: "Mon", deltaPaise: -50000 },
    { label: "Strength & Conditioning", when: "Sun", deltaPaise: -70000 },
    { label: "Quarterly credit grant", when: "01 Jul", deltaPaise: +2100000 },
  ],
};

interface WalletContextValue {
  wallet: WalletState;
  charge: (label: string, pricePaise: number) => void;
  topUp: (amountPaise: number) => void;
  canAfford: (pricePaise: number) => boolean;
}

const WalletContext = createContext<WalletContextValue | null>(null);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [wallet, setWallet] = useState<WalletState>(initialWallet);

  const charge = useCallback((label: string, pricePaise: number) => {
    setWallet((w) => ({
      ...w,
      balancePaise: w.balancePaise - pricePaise,
      ledger: [{ label, when: "Today", deltaPaise: -pricePaise }, ...w.ledger],
    }));
  }, []);

  const topUp = useCallback((amountPaise: number) => {
    setWallet((w) => ({
      ...w,
      balancePaise: w.balancePaise + amountPaise,
      ledger: [{ label: "Wallet top-up", when: "Today", deltaPaise: +amountPaise }, ...w.ledger],
    }));
  }, []);

  const canAfford = useCallback(
    (pricePaise: number) => pricePaise <= wallet.balancePaise,
    [wallet.balancePaise]
  );

  return (
    <WalletContext.Provider value={{ wallet, charge, topUp, canAfford }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const ctx = useContext(WalletContext);
  if (!ctx) throw new Error("useWallet must be used within WalletProvider");
  return ctx;
}
