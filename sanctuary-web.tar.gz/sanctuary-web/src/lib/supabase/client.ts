import { createBrowserClient } from "@supabase/ssr";

// Browser-side Supabase client. Reads public env vars (safe to expose).
// When the backend is ready, components call this to read/write member data.
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
