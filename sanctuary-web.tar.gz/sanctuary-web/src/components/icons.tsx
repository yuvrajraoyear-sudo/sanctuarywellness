export const FlameIcon = ({ stroke = "#161311" }: { stroke?: string }) => (
  <svg viewBox="0 0 24 24" fill="none">
    <path
      d="M12 2c0 3-3 4-3 7a3 3 0 006 0c0-1-.5-1.7-1-2.3.8.4 2 1.7 2 4.3a4 4 0 01-8 0c0-4 4-5 4-9z"
      stroke={stroke}
      strokeWidth="1.1"
      strokeLinejoin="round"
    />
  </svg>
);

export const BellIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.7 21a2 2 0 01-3.4 0" />
  </svg>
);

export const ArrivalIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M3 11l9-8 9 8" />
    <path d="M5 10v10h14V10" />
  </svg>
);

export const RitualsIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7v5l3.5 2" />
  </svg>
);

export const TimelineIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M4 4v16" />
    <circle cx="4" cy="8" r="1.6" fill="currentColor" stroke="none" />
    <circle cx="4" cy="14" r="1.6" fill="currentColor" stroke="none" />
    <circle cx="4" cy="20" r="1.6" fill="currentColor" stroke="none" />
    <path d="M9 8h11M9 14h11M9 20h11" />
  </svg>
);

export const MembershipIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <rect x="3" y="6" width="18" height="13" rx="2.5" />
    <path d="M3 10.5h18" />
  </svg>
);

export const SignatureIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <circle cx="12" cy="8" r="3.6" />
    <path d="M4.5 20c1.4-4 4-5.7 7.5-5.7S18.1 16 19.5 20" />
  </svg>
);

export const ConciergeIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4">
    <path d="M21 11.5a8.4 8.4 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.4 8.4 0 01-3.8-.9L3 21l1.9-5.7a8.4 8.4 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.4 8.4 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z" />
  </svg>
);

export const SendIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.6">
    <path d="M4 12l16-8-6 16-3-7-7-1z" />
  </svg>
);
