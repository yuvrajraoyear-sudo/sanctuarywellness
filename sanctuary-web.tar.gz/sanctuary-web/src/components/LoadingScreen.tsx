"use client";

import { useState, useEffect } from "react";
import { FlameIcon } from "./icons";

function loadCopy() {
  const h = new Date().getHours();
  if (h >= 5 && h < 11) return "A moment, while we prepare your morning.";
  if (h >= 11 && h < 16) return "A moment, while we open the doors.";
  if (h >= 16 && h < 22) return "A moment, while we prepare your evening.";
  return "It's late — we'll keep this brief.";
}

export default function LoadingScreen() {
  const [hide, setHide] = useState(false);
  const [copy, setCopy] = useState("A moment, while we prepare your visit.");

  useEffect(() => {
    setCopy(loadCopy());
    const t = setTimeout(() => setHide(true), 1400);
    return () => clearTimeout(t);
  }, []);

  return (
    <div className={`loading-screen${hide ? " hide" : ""}`}>
      <div className="flame"><FlameIcon stroke="#faf7f2" /></div>
      <div className="load-word">SANCTUARY</div>
      <div className="load-copy">Welcome back, Yuvraj. {copy}</div>
      <div className="load-bar"><i /></div>
    </div>
  );
}
