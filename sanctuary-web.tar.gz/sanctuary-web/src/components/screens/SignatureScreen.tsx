"use client";

import { useState } from "react";
import Link from "next/link";
import { useToast } from "@/lib/toast";

function ChipRow({ options, initial }: { options: string[]; initial: number }) {
  const [sel, setSel] = useState(initial);
  return (
    <div className="chiprow">
      {options.map((o, i) => (
        <button key={o} className={`chip${sel === i ? " active" : ""}`} onClick={() => setSel(i)}>{o}</button>
      ))}
    </div>
  );
}

function Toggle({ initial }: { initial: boolean }) {
  const [on, setOn] = useState(initial);
  return (
    <button className={`toggle${on ? " on" : ""}`} onClick={() => setOn(!on)}><i /></button>
  );
}

export default function SignatureScreen() {
  const showToast = useToast();
  const [temp, setTemp] = useState(78);

  return (
    <div className="screen active">
      <div className="eyebrow">Signature</div>
      <h1 className="headline">Known, not tracked.</h1>
      <p className="lede">Preferences the club uses — nothing more.</p>

      <div className="avatarrow">
        <div className="bigav">Y</div>
        <div><div className="bigname">Yuvraj</div><div className="bigsub">Resident · joined 12 Feb 2026</div></div>
      </div>

      <div className="field">
        <label>Preferred sauna temperature</label>
        <div className="slider-wrap">
          <input type="range" min={60} max={95} value={temp} onChange={(e) => setTemp(Number(e.target.value))} />
          <span className="temp-val">{temp}°</span>
        </div>
      </div>

      <div className="field"><label>Tea</label><ChipRow options={["Ginger", "Turmeric", "Tulsi", "None"]} initial={0} /></div>
      <div className="field"><label>Preferred coach</label><ChipRow options={["Ritika", "Rohan", "Meera", "Anyone"]} initial={0} /></div>
      <div className="field"><label>Preferred time</label><ChipRow options={["Morning", "Midday", "Evening", "Late"]} initial={2} /></div>
      <div className="field"><label>Birthday</label><ChipRow options={["Celebrate", "Quietly", "Not at all"]} initial={1} /></div>

      <div className="divider" />

      <div className="card hairline">
        <Link href="/team" className="listrow" style={{ textDecoration: "none", color: "inherit" }}>
          <div><div className="lname">Meet the team</div><div className="lsub">Every coach, and what they teach</div></div>
          <span className="chev">›</span>
        </Link>
      </div>

      <div className="card hairline" style={{ marginTop: 12 }}>
        <div className="toggle-row"><span className="lname">Quiet please — no small talk</span><Toggle initial={false} /></div>
        <div className="toggle-row"><span className="lname">Session replay (analytics)</span><Toggle initial={false} /></div>
        <div className="toggle-row"><span className="lname">Marketing emails</span><Toggle initial={true} /></div>
      </div>

      <button className="btn btn-primary btn-block" style={{ marginTop: 20 }} onClick={() => showToast("Your Signature has been saved.")}>Save preferences</button>
      <p style={{ textAlign: "center", fontSize: 11.5, color: "var(--stone-500)", marginTop: 14 }}>Your data belongs to you. Download it any time.</p>
    </div>
  );
}
