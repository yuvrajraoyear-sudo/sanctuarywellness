"use client";

import { useState, useEffect } from "react";
import { useToast } from "@/lib/toast";
import { TabName } from "../TabBar";

function dayPart() {
  const h = new Date().getHours();
  if (h >= 5 && h < 11) return { part: "Morning", greet: "Good morning", lede: "Ready when you are." };
  if (h >= 11 && h < 16) return { part: "Midday", greet: "Good midday", lede: "A quiet stretch of the day." };
  if (h >= 16 && h < 22) return { part: "Evening", greet: "Good evening", lede: "You've recovered well since Tuesday." };
  return { part: "Late", greet: "Good evening", lede: "The club is quiet at this hour." };
}

const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function ArrivalScreen({
  onNavigate,
  onBeginRitual,
  onOpenConcierge,
}: {
  onNavigate: (t: TabName) => void;
  onBeginRitual: (slug: string) => void;
  onOpenConcierge: () => void;
}) {
  const showToast = useToast();
  const [dp, setDp] = useState<ReturnType<typeof dayPart> | null>(null);
  const [dateLabel, setDateLabel] = useState("");
  const [feeling, setFeeling] = useState<string | null>(null);
  const [whisperDismissed, setWhisperDismissed] = useState(false);

  useEffect(() => {
    const p = dayPart();
    setDp(p);
    setDateLabel(days[new Date().getDay()] + " · " + p.part);
  }, []);

  const feelingMsg: Record<string, string> = {
    Restored: "Wonderful. Ritika will lean into more of what's working.",
    Steady: "Noted. Thank you — this shapes what Ritika suggests next.",
    Off: "Thank you for the honesty. Ritika will ease the next few days.",
  };

  return (
    <div className="screen active">
      <div className="eyebrow">{dateLabel || "\u00A0"}</div>
      <h1 className="headline">
        {dp ? dp.greet : "Good evening"}, <em>Yuvraj</em>.
      </h1>
      <p className="lede">{dp ? dp.lede : "\u00A0"}</p>

      <div className="ritual-card" onClick={() => onBeginRitual("evening-wind-down")}>
        <div className="rc-top">
          <span className="eyebrow">Today&apos;s ritual</span>
          <span className="dur">~42 min</span>
        </div>
        <h2>Evening Wind Down</h2>
        <div className="steplist">
          <div className="step"><span className="num">01</span><div><span className="sname">Sauna</span><div className="smeta">15 min · 78°C, as you like it</div></div></div>
          <div className="step"><span className="num">02</span><div><span className="sname">Ice Bath</span><div className="smeta">3 min</div></div></div>
          <div className="step"><span className="num">03</span><div><span className="sname">Turmeric Latte</span><div className="smeta">24 min · at Paradiso</div></div></div>
        </div>
        <div className="rc-cta">
          <button className="btn btn-primary" onClick={(e) => { e.stopPropagation(); onBeginRitual("evening-wind-down"); }}>Begin ritual</button>
          <button className="btn btn-ghost" onClick={(e) => { e.stopPropagation(); showToast("Here are a few other rituals for tonight."); onNavigate("rituals"); }}>Prefer something else</button>
        </div>
      </div>

      {/* Post-ritual feedback */}
      <div className="feedback-card">
        {!feeling ? (
          <div>
            <h3>How did Tuesday&apos;s Recovery Reset feel?</h3>
            <div className="fc-sub">One tap. No wrong answer.</div>
            <div className="feel-row">
              <button className="feel-btn" onClick={() => setFeeling("Restored")}><span className="fe">🌤️</span><span className="fl">Restored</span><span className="fl-sub">Better than before</span></button>
              <button className="feel-btn" onClick={() => setFeeling("Steady")}><span className="fe">🍃</span><span className="fl">Steady</span><span className="fl-sub">About the same</span></button>
              <button className="feel-btn" onClick={() => setFeeling("Off")}><span className="fe">🌫️</span><span className="fl">Off</span><span className="fl-sub">Not quite right</span></button>
            </div>
          </div>
        ) : (
          <div className="feedback-thanks">
            <div className="ft-mark">🕊️</div>
            <div className="ft-txt">{feelingMsg[feeling]}</div>
          </div>
        )}
      </div>

      <div className="section-lbl"><h3>Recovery Index</h3><span className="see" onClick={() => onNavigate("timeline")}>See detail →</span></div>
      <div className="ri-band">
        <div className="ri-pill">Below</div>
        <div className="ri-pill active">Steady</div>
        <div className="ri-pill">Rising</div>
      </div>
      <p className="ri-note">You&apos;ve had three intense sessions this week. Sleep is down slightly. Steady, with room to rest.</p>

      <div className="section-lbl"><h3>Next up</h3><span className="see" onClick={() => onNavigate("rituals")}>See all →</span></div>
      <div className="card hairline" style={{ padding: "4px 18px" }}>
        <div className="resv-row">
          <div className="resv-time">7<small>:30 PM</small></div>
          <div><div className="resv-name">Evening Wind Down</div><div className="resv-meta">Sauna Suite 1 · Ritika</div></div>
        </div>
        <div className="resv-row">
          <div className="resv-time">Sat<small>10:00</small></div>
          <div><div className="resv-name">The Sunday Reset</div><div className="resv-meta">Recovery Room · capacity 12</div></div>
        </div>
      </div>

      {!whisperDismissed && (
        <>
          <div className="section-lbl"><h3>A note from Ritika</h3></div>
          <div className="whisper">
            <div className="attrib"><div className="avatar">R</div><div><div className="who">Ritika</div><div className="role">Recovery Coach</div></div></div>
            <p className="body">You&apos;ve had three intense sessions this week. A slower evening tonight will do more than another cold plunge would.</p>
            <div className="actions">
              <button onClick={onOpenConcierge}>How does that sit?</button>
              <button className="secondary" onClick={() => setWhisperDismissed(true)}>Dismiss</button>
            </div>
          </div>
        </>
      )}

      <div className="stat-row">
        <div className="stat-card"><div className="stat-num">148</div><div className="stat-lbl">Days with us</div></div>
        <div className="stat-card"><div className="stat-num">42</div><div className="stat-lbl">Visits</div></div>
      </div>
      <p className="ri-note" style={{ color: "var(--stone-500)", fontSize: 12, marginTop: 0 }}>Delhi · 22°C · dry · 1.4 L logged today</p>
    </div>
  );
}
