"use client";

import { useWallet } from "@/lib/wallet";
import { useToast } from "@/lib/toast";
import { rupees, priceForBooking } from "@/data/catalogue";

export default function MembershipScreen({ onTopUp }: { onTopUp: (neededPaise: number) => void }) {
  const { wallet } = useWallet();
  const showToast = useToast();

  const pct = Math.max(0, Math.min(100, Math.round((wallet.balancePaise / wallet.grantedPaise) * 100)));
  const bonus = wallet.grantedPaise - wallet.planPricePaise;

  return (
    <div className="screen active">
      <div className="eyebrow">Membership</div>
      <h1 className="headline">Your wallet.</h1>
      <p className="lede">Credits from your plan — spent as you book.</p>

      <div className="wallet-card">
        <div className="wc-top">
          <div>
            <div className="wc-tier">{wallet.plan}</div>
            <div className="wc-balance">{rupees(wallet.balancePaise)}</div>
            <div className="wc-sub">of {rupees(wallet.grantedPaise)} granted</div>
          </div>
          <button className="wc-topup" onClick={() => onTopUp(priceForBooking({ name: "", category: "Recovery" }))}>Top up</button>
        </div>
        <div className="wc-bar"><i style={{ width: pct + "%" }} /></div>
        <div className="wc-meta">
          <span>Plan {rupees(wallet.planPricePaise)} · +{rupees(bonus)} bonus credits</span>
          <span>Renews {wallet.renews}</span>
        </div>
      </div>

      <div className="section-lbl"><h3>Recent activity</h3></div>
      <div className="card hairline" style={{ padding: "4px 18px" }}>
        {wallet.ledger.slice(0, 6).map((e, i) => {
          const plus = e.deltaPaise > 0;
          return (
            <div className="ledger-row" key={i}>
              <div><div className="ledger-name">{e.label}</div><div className="ledger-when">{e.when}</div></div>
              <div className={`ledger-delta ${plus ? "plus" : "minus"}`}>{plus ? "+" : "−"}{rupees(Math.abs(e.deltaPaise))}</div>
            </div>
          );
        })}
      </div>

      <div className="section-lbl"><h3>Your plan</h3></div>
      <div className="card hairline">
        <div className="listrow" onClick={() => showToast("Freeze up to 30 days a year, self-serve.")}><div><div className="lname">Freeze membership</div><div className="lsub">Up to 30 days / year</div></div><span className="chev">›</span></div>
        <div className="listrow" onClick={() => showToast("Upgrading to Resident grants a larger quarterly wallet.")}><div><div className="lname">Change plan</div><div className="lsub">Basic · Quarterly</div></div><span className="chev">›</span></div>
        <div className="listrow" onClick={() => showToast("Issuing a guest pass sends a link by WhatsApp.")}><div><div className="lname">Issue a guest pass</div><div className="lsub">2 remaining this year</div></div><span className="chev">›</span></div>
        <div className="listrow" onClick={() => showToast("Your latest invoice has been sent to your email.")}><div><div className="lname">Billing history</div><div className="lsub">GST invoices</div></div><span className="chev">›</span></div>
      </div>

      <div className="section-lbl"><h3>Paradiso</h3><span className="see">Order ahead →</span></div>
      <div className="card hairline">
        <div className="listrow"><div><div className="lname">Turmeric latte · warmed almond milk, ginger, black pepper</div><div className="lsub">Your usual</div></div><span className="chev">₹320</span></div>
        <div className="listrow"><div><div className="lname">Ginger-turmeric shot</div><div className="lsub">Paired with Ice Bath</div></div><span className="chev">₹180</span></div>
      </div>
    </div>
  );
}
