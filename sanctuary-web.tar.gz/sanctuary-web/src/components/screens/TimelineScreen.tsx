"use client";

const items = [
  { current: true, milestone: false, date: "12 Jul", title: "Founder Dinner invitation", note: "A private evening, hosted by Rohan." },
  { current: false, milestone: true, date: "22 Jun", title: "100 hours of recovery", note: "A quiet milestone. Thank you for being here." },
  { current: false, milestone: true, date: "01 May", title: "Elevated to Resident", note: "" },
  { current: false, milestone: false, date: "14 Apr", title: "Completed 30-Day Mobility Challenge", note: "" },
  { current: false, milestone: false, date: "04 Mar", title: "10th visit", note: "" },
  { current: false, milestone: false, date: "15 Feb", title: "First Recovery Reset", note: "" },
  { current: false, milestone: false, date: "12 Feb", title: "Joined Sanctuary", note: "A quiet beginning." },
];

export default function TimelineScreen() {
  return (
    <div className="screen active">
      <div className="eyebrow">Timeline</div>
      <h1 className="headline">Your journey here.</h1>
      <p className="lede">A quiet record — not a leaderboard.</p>

      <div className="stat-row">
        <div className="stat-card"><div className="stat-num">Resident</div><div className="stat-lbl">Current status</div></div>
        <div className="stat-card"><div className="stat-num">100h</div><div className="stat-lbl">Recovery hours</div></div>
      </div>

      <div className="tl">
        {items.map((it, i) => (
          <div className={`tl-item${it.current ? " current" : ""}${it.milestone ? " milestone" : ""}`} key={i}>
            <div className="tl-dot" />
            <div className="tl-date">{it.date}</div>
            <div className="tl-title">{it.title}</div>
            {it.note && <div className="tl-note">{it.note}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}
