"use client";

import { useState } from "react";
import Link from "next/link";
import { rituals, classCatalogue, Category, ClassItem, BookingItem } from "@/data/catalogue";
import { coachByName } from "@/data/coaches";

type Segment = "rituals" | "services" | "classes";
type Filter = "all" | Category;

const services: { name: string; glyph: string; bg: string; color: string; meta: string }[] = [
  { name: "Ice Bath", glyph: "❄", bg: "var(--dawn-400)", color: "#123", meta: "3–8 min" },
  { name: "Sauna", glyph: "♨", bg: "var(--sunset-400)", color: "#3a1c04", meta: "15–30 min" },
  { name: "Steam", glyph: "☁", bg: "var(--sand-300)", color: "#3a3530", meta: "15–20 min" },
  { name: "Contrast", glyph: "◐", bg: "var(--maroon-soft)", color: "var(--maroon-500)", meta: "20–30 min" },
  { name: "Breathwork", glyph: "〰", bg: "var(--sage-400)", color: "#1e2b1a", meta: "20–45 min" },
  { name: "Assisted Stretch", glyph: "⟡", bg: "var(--sand-200)", color: "var(--ink-2)", meta: "30 or 60 min" },
];

export default function RitualsScreen({
  onOpenRitual,
  onOpenBooking,
}: {
  onOpenRitual: (slug: string) => void;
  onOpenBooking: (item: BookingItem) => void;
}) {
  const [segment, setSegment] = useState<Segment>("rituals");
  const [filter, setFilter] = useState<Filter>("all");

  const cats: Category[] = filter === "all" ? ["Dance", "Fitness", "Recovery"] : [filter];

  function availLabel(a: ClassItem["avail"]) {
    return a === "full" ? "Full · waitlist" : a === "low" ? "Filling up" : "Open";
  }

  function classToBooking(item: ClassItem, category: Category): BookingItem {
    const displayName = item.name + (item.level ? " · " + item.level.charAt(0).toUpperCase() + item.level.slice(1) : "");
    return { name: displayName, coach: item.coach, dur: item.dur, meta: item.meta, avail: item.avail, contra: item.contra, category };
  }

  return (
    <div className="screen active">
      <div className="eyebrow">Rituals</div>
      <h1 className="headline">Choose your ritual.</h1>
      <p className="lede">Composed sequences, held for you — start to finish.</p>

      <div className="segmented">
        <button className={segment === "rituals" ? "active" : ""} onClick={() => setSegment("rituals")}>Rituals</button>
        <button className={segment === "services" ? "active" : ""} onClick={() => setSegment("services")}>Services</button>
        <button className={segment === "classes" ? "active" : ""} onClick={() => setSegment("classes")}>Classes</button>
      </div>

      {segment === "rituals" && (
        <div>
          {rituals.map((r) => (
            <div className="ritual-card" key={r.slug} onClick={() => onOpenRitual(r.slug)}>
              <div className="rc-top"><span className="eyebrow">{r.eyebrow}</span><span className="dur">{r.dur}</span></div>
              <h2>{r.name}</h2>
              <div className="steplist">
                {r.steps.map((s, i) => (
                  <div className="step" key={i}>
                    <span className="num">0{i + 1}</span>
                    <div><span className="sname">{s.name}</span><div className="smeta">{s.detail}</div></div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {segment === "services" && (
        <div className="tilegrid">
          {services.map((s) => (
            <button className="tile" key={s.name} onClick={() => onOpenBooking({ name: s.name, coach: "Attendant", dur: s.meta, avail: "open", category: "Recovery", contra: s.name === "Sauna" || s.name === "Contrast" ? "cardiac" : undefined })}>
              <div className="glyph" style={{ background: s.bg, color: s.color }}>{s.glyph}</div>
              <span className="tname">{s.name}</span>
              <div className="tmeta">{s.meta}</div>
            </button>
          ))}
        </div>
      )}

      {segment === "classes" && (
        <div>
          <div className="filterrow">
            {(["all", "Dance", "Fitness", "Recovery"] as Filter[]).map((f) => (
              <button key={f} className={`chip${filter === f ? " active" : ""}`} onClick={() => setFilter(f)}>
                {f === "all" ? "All" : f}
              </button>
            ))}
            <Link href="/team" className="chip" style={{ textDecoration: "none", color: "var(--maroon-500)", fontWeight: 600 }}>
              Meet the team →
            </Link>
          </div>
          {cats.map((cat) => {
            const block = classCatalogue[cat];
            return (
              <div key={cat}>
                <div className="cat-head">{cat}</div>
                {filter !== "all" && <p className="cat-intro">{block.intro}</p>}
                {block.subgroups.map((sg) => (
                  <div key={sg.label}>
                    <div className="pillar-head">{sg.label}</div>
                    {sg.items.map((c, i) => {
                      const coach = coachByName(c.coach);
                      return (
                        <div className="classrow" key={i}>
                          <div className="ctime" onClick={() => onOpenBooking(classToBooking(c, cat))}>{c.time}</div>
                          <div className="cbody" onClick={() => onOpenBooking(classToBooking(c, cat))}>
                            <div className="cname">
                              {c.name}
                              {c.level && <span className={`level-badge level-${c.level}`}>{c.level}</span>}
                              {c.contra && <span className="care-dot">care</span>}
                            </div>
                            <div className="cmeta">
                              {coach ? (
                                <Link href={`/team/${coach.slug}`} className="coach-link" onClick={(e) => e.stopPropagation()}>
                                  by {coach.name}
                                </Link>
                              ) : (
                                <span>{c.coach}</span>
                              )}
                              {" "}· {c.dur}{c.meta ? " · " + c.meta : ""}
                            </div>
                          </div>
                          <div className={`avail-badge ${c.avail !== "open" ? c.avail : ""}`} onClick={() => onOpenBooking(classToBooking(c, cat))}>{availLabel(c.avail)}</div>
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
