"use client";

import { ArrivalIcon, RitualsIcon, TimelineIcon, MembershipIcon, SignatureIcon } from "./icons";

export type TabName = "arrival" | "rituals" | "timeline" | "membership" | "signature";

const tabs: { name: TabName; label: string; Icon: () => JSX.Element }[] = [
  { name: "arrival", label: "Arrival", Icon: ArrivalIcon },
  { name: "rituals", label: "Rituals", Icon: RitualsIcon },
  { name: "timeline", label: "Timeline", Icon: TimelineIcon },
  { name: "membership", label: "Membership", Icon: MembershipIcon },
  { name: "signature", label: "Signature", Icon: SignatureIcon },
];

export default function TabBar({
  active,
  onChange,
}: {
  active: TabName;
  onChange: (t: TabName) => void;
}) {
  return (
    <div className="tabbar">
      {tabs.map(({ name, label, Icon }) => (
        <button
          key={name}
          className={`tab${active === name ? " active" : ""}`}
          data-tab={name}
          onClick={() => onChange(name)}
        >
          <Icon />
          <span>{label}</span>
        </button>
      ))}
    </div>
  );
}
