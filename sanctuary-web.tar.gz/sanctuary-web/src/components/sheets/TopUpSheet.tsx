"use client";

import { useWallet } from "@/lib/wallet";
import { useToast } from "@/lib/toast";
import { rupees } from "@/data/catalogue";

const packs = [
  { credits: 500000, price: 500000, bonus: 0 },
  { credits: 1150000, price: 1000000, bonus: 150000 },
  { credits: 2400000, price: 2000000, bonus: 400000 },
];

export default function TopUpSheet({
  neededPaise,
  show,
  onClose,
}: {
  neededPaise: number;
  show: boolean;
  onClose: () => void;
}) {
  const { wallet, topUp } = useWallet();
  const showToast = useToast();

  function doTopUp(amount: number) {
    // In production this opens Razorpay checkout; on webhook success the server
    // credits the wallet. Here we credit immediately for the prototype.
    topUp(amount);
    onClose();
    showToast(`${rupees(amount)} added. Your wallet is ready — go ahead and book.`);
  }

  return (
    <div className={`sheet${show ? " show" : ""}`}>
      <div className="handle" />
      <button className="close" onClick={onClose}>&times;</button>
      <div className="topup-hero"><div className="tu-glyph">◆</div></div>
      <h2 style={{ textAlign: "center" }}>A little short on credits</h2>
      <div className="topup-shortfall">
        <div className="tu-line">
          This session needs <b>{rupees(neededPaise)}</b>. Your balance is <b>{rupees(wallet.balancePaise)}</b>.
        </div>
      </div>
      <p className="lede" style={{ textAlign: "center" }}>Top up your wallet and we&apos;ll hold your place right after.</p>
      {packs.map((p) => (
        <button className="topup-opt" key={p.credits} onClick={() => doTopUp(p.credits)}>
          <div>
            <div className="to-amount">{rupees(p.credits)} credits</div>
            {p.bonus > 0 && <div className="to-bonus">+{rupees(p.bonus)} bonus</div>}
          </div>
          <div className="to-price">{rupees(p.price)}</div>
        </button>
      ))}
      <p style={{ textAlign: "center", fontSize: 11.5, color: "var(--stone-500)", marginTop: 8 }}>Or renew your plan for a full quarterly grant.</p>
    </div>
  );
}
