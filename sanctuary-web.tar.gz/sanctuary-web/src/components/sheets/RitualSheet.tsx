"use client";

import { useState } from "react";
import { Ritual, rupees, priceForBooking } from "@/data/catalogue";
import { useWallet } from "@/lib/wallet";
import { useToast } from "@/lib/toast";

const times = ["Tonight · 7:30", "Tomorrow · 7:00", "Friday · 6:45"];

export default function RitualSheet({
  ritual,
  show,
  onClose,
  onNeedTopUp,
}: {
  ritual: Ritual | null;
  show: boolean;
  onClose: () => void;
  onNeedTopUp: (neededPaise: number) => void;
}) {
  const { wallet, charge, canAfford } = useWallet();
  const showToast = useToast();
  const [timeIdx, setTimeIdx] = useState(0);

  if (!ritual) return null;
  const price = priceForBooking({ name: ritual.name, category: "Ritual" });

  function reserve() {
    if (!ritual) return;
    if (!canAfford(price)) {
      onNeedTopUp(price);
      return;
    }
    charge(ritual.name + " ritual", price);
    onClose();
    showToast(`${ritual.name} — held for ${times[timeIdx]} · ${rupees(price)} credits used.`);
  }

  return (
    <div className={`sheet${show ? " show" : ""}`} id="ritualSheet">
      <div className="handle" />
      <button className="close" onClick={onClose}>&times;</button>
      <div className="eyebrow">{ritual.eyebrow}</div>
      <h2>{ritual.name}</h2>
      <p className="lede" style={{ marginTop: 2 }}>{ritual.tagline} · {ritual.dur}</p>
      <div className="steplist">
        {ritual.steps.map((s, i) => (
          <div className="step" key={i}>
            <span className="num">0{i + 1}</span>
            <div><span className="sname">{s.name}</span><div className="smeta">{s.detail}</div></div>
          </div>
        ))}
      </div>
      <div className="divider" />
      <div className="field">
        <label>Choose a time</label>
        <div className="chiprow">
          {times.map((t, i) => (
            <button key={t} className={`chip${timeIdx === i ? " active" : ""}`} onClick={() => setTimeIdx(i)}>{t}</button>
          ))}
        </div>
      </div>
      <div className="cost-row">
        <div className="cost-left"><span className="cost-label">This ritual</span><span className="cost-price">{rupees(price)} credits</span></div>
        <div className="cost-right"><span className="cost-after-label">Balance after</span><span className={`cost-after${wallet.balancePaise - price < 0 ? " negative" : ""}`}>{rupees(wallet.balancePaise - price)}</span></div>
      </div>
      <button className="btn btn-primary btn-block" onClick={reserve}>Reserve ritual</button>
      <p style={{ textAlign: "center", fontSize: 11.5, color: "var(--stone-500)", marginTop: 12 }}>Free to cancel up to 4 hours before.</p>
    </div>
  );
}
