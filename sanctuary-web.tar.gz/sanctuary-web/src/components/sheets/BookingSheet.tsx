"use client";

import { useState, useEffect, useRef } from "react";
import { BookingItem, rupees, priceForBooking } from "@/data/catalogue";
import { useWallet } from "@/lib/wallet";
import { useToast } from "@/lib/toast";

// Member health flags — in production these come from member_health via RLS.
const memberHealthFlags: Record<string, boolean> = { cardiac: true };

const times = ["Today · 6:00 PM", "Tomorrow · 6:00 PM", "Sat · 10:00 AM"];

export default function BookingSheet({
  item,
  show,
  onClose,
  onNeedTopUp,
}: {
  item: BookingItem | null;
  show: boolean;
  onClose: () => void;
  onNeedTopUp: (neededPaise: number) => void;
}) {
  const { wallet, charge, canAfford } = useWallet();
  const showToast = useToast();
  const [gateCleared, setGateCleared] = useState(false);
  const [timeIdx, setTimeIdx] = useState(0);
  const [held, setHeld] = useState(false);
  const [remaining, setRemaining] = useState(180);
  const timer = useRef<ReturnType<typeof setInterval>>();

  // reset when a new item opens
  useEffect(() => {
    if (show) {
      setGateCleared(false);
      setTimeIdx(0);
      setHeld(false);
      setRemaining(180);
      clearInterval(timer.current);
    }
    return () => clearInterval(timer.current);
  }, [show, item]);

  if (!item) return null;

  const price = priceForBooking(item);
  const isFull = item.avail === "full";
  const gated = !!item.contra && memberHealthFlags[item.contra] && !gateCleared;

  function startCountdown() {
    clearInterval(timer.current);
    let r = 180;
    setRemaining(r);
    timer.current = setInterval(() => {
      r -= 1;
      if (r < 0) {
        clearInterval(timer.current);
        onClose();
        showToast("The room opened back up. Would you like to try again?");
        return;
      }
      setRemaining(r);
    }, 1000);
  }

  function hold() {
    if (!canAfford(price)) {
      onNeedTopUp(price);
      return;
    }
    setHeld(true);
    startCountdown();
  }

  function confirm() {
    if (!item) return;
    if (!canAfford(price)) {
      onNeedTopUp(price);
      return;
    }
    clearInterval(timer.current);
    charge(item.name, price);
    onClose();
    const costNote = price > 0 ? ` · ${rupees(price)} credits used` : "";
    showToast(`${item.name} — confirmed for ${times[timeIdx]}${costNote}.`);
  }

  function joinWaitlist() {
    onClose();
    showToast(`You're on the waitlist for ${item?.name}. We'll message you the moment a place opens.`);
  }

  const mm = Math.floor(remaining / 60);
  const ss = String(remaining % 60).padStart(2, "0");
  const afterPaise = wallet.balancePaise - price;

  return (
    <div className={`sheet${show ? " show" : ""}`}>
      <div className="handle" />
      <button className="close" onClick={onClose}>&times;</button>
      <div className="eyebrow">{item.category}</div>
      <div className="book-hero">
        <h2>{item.name}</h2>
        <span className="dur" style={{ fontFamily: "var(--font-serif)", color: "var(--stone-600)" }}>
          {item.avail === "full" ? "Full · waitlist" : item.avail === "low" ? "Filling up" : "Open"}
        </span>
      </div>
      <div className="book-meta">{item.coach}{item.dur ? " · " + item.dur : ""}{item.meta ? " · " + item.meta : ""}</div>

      {gated ? (
        <div className="health-gate">
          <div className="hg-title">A quick word before we hold this</div>
          <div className="hg-body">
            {item.contra === "cardiac"
              ? "Your Signature notes a cardiac consideration. For heat and cold work we like a coach with you the first time — shall we have Ritika meet you?"
              : "Your Signature notes something worth a quick check before this one. A coach will meet you at the start."}
          </div>
          <div className="hg-actions">
            <button className="btn btn-outline btn-sm" onClick={() => { setGateCleared(true); showToast("Ritika will be with you for this one."); }}>Yes, with a coach</button>
            <button className="btn btn-ghost btn-sm" onClick={onClose}>Not now</button>
          </div>
        </div>
      ) : (
        <div>
          {item.category === "Recovery" && (
            <div className="pairing-note">
              <div className="pn-glyph">☕</div>
              <div className="pn-txt"><b>Paradiso pairing</b> — a warm ginger-turmeric tea, waiting when you finish.</div>
            </div>
          )}

          <div className="field" style={{ marginTop: 8 }}>
            <label>Choose a time</label>
            <div className="chiprow">
              {times.map((t, i) => (
                <button key={t} className={`chip${timeIdx === i ? " active" : ""}`} onClick={() => setTimeIdx(i)}>{t}</button>
              ))}
            </div>
          </div>

          <div className="cost-row">
            <div className="cost-left">
              <span className="cost-label">This session</span>
              <span className={`cost-price${price === 0 ? " free" : ""}`}>{price === 0 ? "Included" : rupees(price) + " credits"}</span>
            </div>
            <div className="cost-right">
              <span className="cost-after-label">Balance after</span>
              <span className={`cost-after${afterPaise < 0 ? " negative" : ""}`}>{rupees(afterPaise)}</span>
            </div>
          </div>

          {held && (
            <div className={`countdown-card${remaining <= 30 ? " ending" : ""}`}>
              <div className="cd-num">{mm}:{ss}</div>
              <div className="cd-label">Held for you. Confirm below to lock it in.</div>
            </div>
          )}

          {isFull ? (
            <button className="btn btn-primary btn-block" onClick={joinWaitlist}>Join the waitlist</button>
          ) : !held ? (
            <button className="btn btn-primary btn-block" onClick={hold}>Hold my place</button>
          ) : (
            <button className="btn btn-primary btn-block" onClick={confirm}>Confirm reservation</button>
          )}
          <p style={{ textAlign: "center", fontSize: 11.5, color: "var(--stone-500)", marginTop: 12 }}>Free to cancel up to 2 hours before a class.</p>
        </div>
      )}
    </div>
  );
}
