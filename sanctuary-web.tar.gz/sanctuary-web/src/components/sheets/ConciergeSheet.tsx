"use client";

import { useState, useRef, useEffect } from "react";
import { useToast } from "@/lib/toast";
import { SendIcon } from "../icons";

const SAFETY_WORDS = ["chest pain", "can't breathe", "cant breathe", "shortness of breath", "dizzy", "faint", "suicidal", "kill myself", "self harm", "emergency"];

interface Action {
  eyebrow: string;
  title: string;
  meta: string;
}

type Msg =
  | { kind: "member"; text: string }
  | { kind: "concierge"; who: string; role: string; text: string; action?: Action }
  | { kind: "safety" }
  | { kind: "system"; text: string };

export default function ConciergeSheet({ show, onClose }: { show: boolean; onClose: () => void }) {
  const showToast = useToast();
  const [messages, setMessages] = useState<Msg[]>([
    { kind: "concierge", who: "Ritika", role: "Recovery Coach", text: "You've had three intense sessions this week. A slower evening tonight will do more than another cold plunge would." },
  ]);
  const [input, setInput] = useState("");
  const [confirmedActions, setConfirmedActions] = useState<Record<number, "confirmed" | "declined">>({});
  const convoRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    convoRef.current?.scrollTo({ top: convoRef.current.scrollHeight });
  }, [messages]);

  function send() {
    const text = input.trim();
    if (!text) return;
    setInput("");
    const lower = text.toLowerCase();
    const isSafety = SAFETY_WORDS.some((w) => lower.includes(w));
    setMessages((m) => [...m, { kind: "member", text }]);

    setTimeout(() => {
      if (isSafety) {
        setMessages((m) => [...m, { kind: "safety" }, { kind: "system", text: "A coach is with you." }]);
        return;
      }
      let who = "Ritika", role = "Recovery Coach", reply: string, action: Action | undefined;
      if (lower.includes("sleep")) {
        reply = "A twelve-minute breathwork session tonight before bed tends to help.";
        action = { eyebrow: "Suggested hold", title: "Breathwork · Coherent", meta: "Tonight · 9:30 PM · Breath Studio" };
      } else if (lower.includes("cancel") || lower.includes("reschedul")) {
        reply = "Free to cancel up to four hours before. Which reservation would you like to change?";
      } else if (lower.includes("sauna") || lower.includes("hot")) {
        reply = "Seventy-eight degrees, as usual? I can have it ready for this evening.";
        action = { eyebrow: "Suggested hold", title: "Sauna · 78°C", meta: "This evening · Sauna Suite 1" };
      } else if (lower.includes("guest") || lower.includes("friend")) {
        who = "Sanctuary"; role = "Sanctuary Concierge";
        reply = "You have two guest passes remaining this year. Shall I send one along?";
      } else {
        reply = "Noted. I'll pass this to Ritika — she reads every note personally.";
      }
      setMessages((m) => [...m, { kind: "concierge", who, role, text: reply, action }]);
    }, 550);
  }

  return (
    <div className={`sheet${show ? " show" : ""}`} style={{ maxHeight: "88%" }}>
      <div className="handle" />
      <button className="close" onClick={onClose}>&times;</button>
      <div className="eyebrow">Concierge</div>
      <h2 style={{ marginBottom: 14 }}>A word, whenever.</h2>
      <div className="convo" ref={convoRef}>
        {messages.map((m, i) => {
          if (m.kind === "member") return <div className="msg member" key={i}>{m.text}</div>;
          if (m.kind === "system") return <div className="msg system" key={i}>{m.text}</div>;
          if (m.kind === "safety")
            return (
              <div className="msg safety" key={i}>
                <p className="txt">Let&apos;s have a person help with this. Rohan is being paged now — you&apos;ll hear from him in a few minutes. If this is urgent, please call the front desk or your doctor.</p>
              </div>
            );
          return (
            <div key={i}>
              <div className="msg concierge">
                <div className="attrib">
                  <div className="avatar" style={{ width: 22, height: 22, fontSize: 10.5 }}>{m.who[0]}</div>
                  <b>{m.who} · {m.role}</b>
                </div>
                <p className="txt">{m.text}</p>
              </div>
              {m.action && (
                <div className={`action-card${confirmedActions[i] ? " confirmed" : ""}`}>
                  <div className="ac-eyebrow">{m.action.eyebrow}</div>
                  <div className="ac-title">{m.action.title}</div>
                  <div className="ac-meta">{m.action.meta}</div>
                  {!confirmedActions[i] ? (
                    <div className="ac-actions">
                      <button className="btn btn-primary btn-sm" onClick={() => { setConfirmedActions((c) => ({ ...c, [i]: "confirmed" })); showToast(`${m.action!.title} — held for you.`); }}>Hold it for me</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => setConfirmedActions((c) => ({ ...c, [i]: "declined" }))}>Not now</button>
                    </div>
                  ) : confirmedActions[i] === "confirmed" ? (
                    <span className="ac-confirmed-tag">✓ Held — a confirmation is on its way</span>
                  ) : (
                    <span className="ac-meta" style={{ margin: 0 }}>No trouble. Just a whisper.</span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
      <div className="composer">
        <input
          type="text"
          value={input}
          placeholder="Say something…"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter") send(); }}
        />
        <button onClick={send} aria-label="Send"><SendIcon /></button>
      </div>
    </div>
  );
}
