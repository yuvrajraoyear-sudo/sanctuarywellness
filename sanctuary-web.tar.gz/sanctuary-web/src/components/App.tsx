"use client";

import { useState } from "react";
import { ToastProvider } from "@/lib/toast";
import { SheetProvider, useSheets } from "@/lib/sheets";
import { rituals, Ritual, BookingItem } from "@/data/catalogue";

import TopBar from "./TopBar";
import TabBar, { TabName } from "./TabBar";
import LoadingScreen from "./LoadingScreen";
import { ConciergeIcon } from "./icons";

import ArrivalScreen from "./screens/ArrivalScreen";
import RitualsScreen from "./screens/RitualsScreen";
import TimelineScreen from "./screens/TimelineScreen";
import MembershipScreen from "./screens/MembershipScreen";
import SignatureScreen from "./screens/SignatureScreen";

import RitualSheet from "./sheets/RitualSheet";
import BookingSheet from "./sheets/BookingSheet";
import TopUpSheet from "./sheets/TopUpSheet";
import ConciergeSheet from "./sheets/ConciergeSheet";

function Shell() {
  const { open, openSheet, closeSheets } = useSheets();
  const [tab, setTab] = useState<TabName>("arrival");
  const [activeRitual, setActiveRitual] = useState<Ritual | null>(null);
  const [activeBooking, setActiveBooking] = useState<BookingItem | null>(null);
  const [neededPaise, setNeededPaise] = useState(0);

  function openRitual(slug: string) {
    const r = rituals.find((x) => x.slug === slug) || rituals[2];
    setActiveRitual(r);
    openSheet("ritual");
  }
  function openBooking(item: BookingItem) {
    setActiveBooking(item);
    openSheet("booking");
  }
  function requestTopUp(needed: number) {
    setNeededPaise(needed);
    openSheet("topup");
  }

  return (
    <div className="app">
      <LoadingScreen />
      <TopBar onCreditClick={() => setTab("membership")} />

      <div className="screens">
        {tab === "arrival" && (
          <ArrivalScreen
            onNavigate={setTab}
            onBeginRitual={openRitual}
            onOpenConcierge={() => openSheet("concierge")}
          />
        )}
        {tab === "rituals" && <RitualsScreen onOpenRitual={openRitual} onOpenBooking={openBooking} />}
        {tab === "timeline" && <TimelineScreen />}
        {tab === "membership" && <MembershipScreen onTopUp={requestTopUp} />}
        {tab === "signature" && <SignatureScreen />}
      </div>

      <button className="fab" onClick={() => openSheet("concierge")} aria-label="Open Concierge">
        <div className="dot" />
        <ConciergeIcon />
      </button>

      <TabBar active={tab} onChange={setTab} />

      <RitualSheet
        ritual={activeRitual}
        show={open === "ritual"}
        onClose={closeSheets}
        onNeedTopUp={requestTopUp}
      />
      <BookingSheet
        item={activeBooking}
        show={open === "booking"}
        onClose={closeSheets}
        onNeedTopUp={requestTopUp}
      />
      <TopUpSheet neededPaise={neededPaise} show={open === "topup"} onClose={closeSheets} />
      <ConciergeSheet show={open === "concierge"} onClose={closeSheets} />
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <SheetProvider>
        <Shell />
      </SheetProvider>
    </ToastProvider>
  );
}
