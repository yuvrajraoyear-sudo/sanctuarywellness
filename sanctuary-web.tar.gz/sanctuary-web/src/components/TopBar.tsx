"use client";

import { useWallet } from "@/lib/wallet";
import { useToast } from "@/lib/toast";
import { rupees } from "@/data/catalogue";
import { FlameIcon, BellIcon } from "./icons";

export default function TopBar({ onCreditClick }: { onCreditClick: () => void }) {
  const { wallet } = useWallet();
  const showToast = useToast();
  const low = wallet.balancePaise < 200000;

  return (
    <div className="topbar">
      <div className="brandmark">
        <FlameIcon />
        <span>SANCTUARY</span>
      </div>
      <div className="topbar-right">
        <button
          className={`credit-pill${low ? " low" : ""}`}
          onClick={onCreditClick}
          aria-label="Credit balance"
        >
          <span className="cp-glyph">◆</span>
          <span className="cp-amount">{rupees(wallet.balancePaise)}</span>
        </button>
        <button
          className="iconbtn"
          aria-label="Notifications"
          onClick={() => showToast("Nothing new since your last visit.")}
        >
          <BellIcon />
        </button>
      </div>
    </div>
  );
}
