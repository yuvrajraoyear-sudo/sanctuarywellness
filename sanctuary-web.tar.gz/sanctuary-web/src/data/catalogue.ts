// Catalogue data for Sanctuary. In production these come from Supabase
// (tables: rituals, services, sessions). Kept here as typed seed data so the
// UI is fully functional before the backend is wired in.

export type Category = "Dance" | "Fitness" | "Recovery";
export type Availability = "open" | "low" | "full";
export type Level = "beginner" | "intermediate" | "advanced";

export interface ClassItem {
  name: string;
  time: string;
  coach: string;
  dur: string;
  avail: Availability;
  level?: Level;
  meta?: string;
  contra?: string; // health flag key that gates booking
}

export interface Subgroup {
  label: string;
  items: ClassItem[];
}

export interface CategoryBlock {
  intro: string;
  subgroups: Subgroup[];
}

export interface RitualStep {
  name: string;
  detail: string;
}

export interface Ritual {
  slug: string;
  eyebrow: string;
  name: string;
  tagline: string;
  dur: string;
  steps: RitualStep[];
}

export const rituals: Ritual[] = [
  {
    slug: "morning-reset",
    eyebrow: "Morning · Any time",
    name: "Morning Reset",
    tagline: "Begin before the day begins.",
    dur: "32 min",
    steps: [
      { name: "Breathwork", detail: "10 min · coherent" },
      { name: "Mobility", detail: "12 min" },
      { name: "Ginger-Lemon Tea", detail: "10 min · Paradiso" },
    ],
  },
  {
    slug: "recovery-reset",
    eyebrow: "Post-workout · Recovery",
    name: "Recovery Reset",
    tagline: "Sauna, a short cold, tea after.",
    dur: "50 min",
    steps: [
      { name: "Sauna", detail: "15 min" },
      { name: "Ice Bath", detail: "3 min" },
      { name: "Contrast Finish", detail: "2 min" },
      { name: "Ginger Tea", detail: "30 min · Paradiso" },
    ],
  },
  {
    slug: "evening-wind-down",
    eyebrow: "Evening · Weekday",
    name: "Evening Wind Down",
    tagline: "Steam the day off, close it gently.",
    dur: "42 min",
    steps: [
      { name: "Sauna", detail: "15 min" },
      { name: "Ice Bath", detail: "3 min" },
      { name: "Turmeric Latte", detail: "24 min · Paradiso" },
    ],
  },
  {
    slug: "weekend-recharge",
    eyebrow: "Weekend afternoon",
    name: "Weekend Recharge",
    tagline: "The long version, for a long day off.",
    dur: "75 min",
    steps: [
      { name: "Sauna", detail: "15 min" },
      { name: "Steam", detail: "12 min" },
      { name: "Ice Bath", detail: "5 min" },
      { name: "Stretch", detail: "30 min" },
      { name: "Paradiso pairing", detail: "—" },
    ],
  },
  {
    slug: "longevity-reset",
    eyebrow: "Weekly · Longevity",
    name: "Longevity Reset",
    tagline: "The full sequence, for the discipline of it.",
    dur: "90 min",
    steps: [
      { name: "Breathwork", detail: "10 min" },
      { name: "Mobility", detail: "15 min" },
      { name: "Sauna", detail: "20 min" },
      { name: "Contrast", detail: "10 min" },
      { name: "Stretch", detail: "25 min" },
    ],
  },
];

export const classCatalogue: Record<Category, CategoryBlock> = {
  Dance: {
    intro: "Workshops and drop-in classes across genres. Levels marked where they matter.",
    subgroups: [
      {
        label: "Open classes",
        items: [
          { name: "Zumba", time: "6:00 PM", coach: "Pallavi", dur: "45 min", avail: "open" },
          { name: "Dance Cardio", time: "5:30 PM", coach: "Vikram", dur: "45 min", avail: "low" },
          { name: "Beginner Dance · Contemporary", time: "11:00 AM", coach: "Akshita", dur: "50 min", avail: "open" },
        ],
      },
      {
        label: "Hip Hop",
        items: [
          { name: "Hip Hop", level: "beginner", time: "5:00 PM", coach: "Akshita", dur: "50 min", avail: "open" },
          { name: "Hip Hop", level: "intermediate", time: "6:15 PM", coach: "Vikram", dur: "50 min", avail: "low" },
          { name: "Hip Hop", level: "advanced", time: "7:30 PM", coach: "Vikram", dur: "50 min", avail: "open" },
        ],
      },
      {
        label: "Bollywood",
        items: [
          { name: "Bollywood", level: "beginner", time: "11:00 AM", coach: "Akshita", dur: "50 min", avail: "open" },
          { name: "Bollywood", level: "intermediate", time: "5:00 PM", coach: "Vikram", dur: "50 min", avail: "open" },
          { name: "Bollywood", level: "advanced", time: "6:30 PM", coach: "Vikram", dur: "50 min", avail: "low" },
        ],
      },
      {
        label: "Workshops",
        items: [
          { name: "Dance Workshop", time: "Sat · 4:00 PM", coach: "Visiting choreographer", dur: "90 min", avail: "low", meta: "Monthly · genre rotates" },
        ],
      },
    ],
  },
  Fitness: {
    intro: "Movement and conditioning — starts with the studio staples, into strength and the pool.",
    subgroups: [
      {
        label: "Studio",
        items: [
          { name: "Power Yoga", time: "6:00 AM", coach: "Sahil", dur: "55 min", avail: "open" },
          { name: "Restorative Yoga", time: "7:00 AM", coach: "Sahil", dur: "60 min", avail: "open" },
          { name: "Vinyasa Flow", time: "6:30 PM", coach: "Meera", dur: "60 min", avail: "open" },
          { name: "Zumba", time: "6:00 PM", coach: "Pallavi", dur: "45 min", avail: "open" },
          { name: "HIIT", time: "7:00 AM", coach: "Priya", dur: "40 min", avail: "open" },
          { name: "Aerobics", time: "8:15 AM", coach: "Priya", dur: "45 min", avail: "low" },
          { name: "Mat Pilates", time: "8:15 AM", coach: "Ananya", dur: "50 min", avail: "low" },
          { name: "Mobility Reset", time: "8:15 AM", coach: "Karan", dur: "45 min", avail: "open" },
        ],
      },
      {
        label: "Pool",
        items: [
          { name: "Aqua Fit", time: "9:00 AM", coach: "Priya", dur: "40 min", avail: "open", meta: "Pool deck" },
          { name: "Aqua Yoga", time: "10:00 AM", coach: "Meera", dur: "45 min", avail: "open", meta: "Pool deck" },
        ],
      },
      {
        label: "Strength & performance",
        items: [
          { name: "Strength & Conditioning", time: "6:00 PM", coach: "Rohan", dur: "60 min", avail: "open" },
          { name: "HYROX Prep", time: "6:00 PM", coach: "Priya", dur: "60 min", avail: "full" },
          { name: "Boxing", time: "7:15 PM", coach: "Vikram", dur: "50 min", avail: "open" },
          { name: "Morning Run Club", time: "5:45 AM", coach: "Priya", dur: "45 min", avail: "open", meta: "Meets at reception · outdoor" },
        ],
      },
    ],
  },
  Recovery: {
    intro: "The heat-and-cold circuit. Some carry health guidance — we check before we hold a slot.",
    subgroups: [
      {
        label: "Water & heat",
        items: [
          { name: "Pool", time: "Open · lap swim", coach: "Lifeguard on deck", dur: "Any time", avail: "open", meta: "Book a lane" },
          { name: "Steam", time: "Open · on request", coach: "Attendant", dur: "15–20 min", avail: "open" },
          { name: "Sauna", time: "Open · 78°C", coach: "Attendant", dur: "15–30 min", avail: "open", contra: "cardiac" },
          { name: "Ice Plunge", time: "Open · on request", coach: "Attendant", dur: "3–8 min", avail: "low", contra: "cardiac" },
        ],
      },
      {
        label: "Guided",
        items: [
          { name: "Contrast Therapy", time: "6:00 PM", coach: "Ritika", dur: "20–30 min", avail: "open", contra: "cardiac", meta: "First time needs a coach" },
          { name: "Breathwork · Coherent", time: "12:00 PM", coach: "Aarav", dur: "30 min", avail: "open" },
          { name: "Assisted Stretch", time: "By appointment", coach: "Karan", dur: "30 or 60 min", avail: "open", meta: "1:1" },
          { name: "Sound Bath", time: "Fri · 8:30 PM", coach: "Guest artist", dur: "50 min", avail: "low" },
        ],
      },
    ],
  },
};

// ---- Pricing (in paise). Backend will own this; kept client-mirrored for the UI. ----
export const priceTable = {
  category: { Dance: 60000, Fitness: 50000, Recovery: 80000 } as Record<Category, number>,
  overrides: {
    "HYROX Prep": 70000,
    "Strength & Conditioning": 70000,
    Boxing: 70000,
    "Contrast Therapy": 90000,
    "Ice Plunge": 80000,
    Sauna: 60000,
    Steam: 50000,
    Pool: 40000,
    "Assisted Stretch": 120000,
    "Dance Workshop": 110000,
    "Morning Run Club": 0,
  } as Record<string, number>,
  ritualDefault: 90000,
};

export interface BookingItem {
  name: string;
  category: Category | "Ritual";
  coach?: string;
  dur?: string;
  meta?: string;
  avail?: Availability;
  contra?: string;
}

export function priceForBooking(item: BookingItem): number {
  if (item?.name) {
    const base = item.name.split(" · ")[0];
    if (priceTable.overrides[base] !== undefined) return priceTable.overrides[base];
    if (priceTable.overrides[item.name] !== undefined) return priceTable.overrides[item.name];
  }
  if (item?.category && item.category !== "Ritual") {
    const c = priceTable.category[item.category];
    if (c !== undefined) return c;
  }
  return priceTable.ritualDefault;
}

export function rupees(paise: number): string {
  return "₹" + (paise / 100).toLocaleString("en-IN");
}

export interface CoachClassEntry {
  category: Category;
  name: string;
  level?: Level;
  time: string;
  dur: string;
}

export function classesByCoach(coachName: string): CoachClassEntry[] {
  const out: CoachClassEntry[] = [];
  (Object.keys(classCatalogue) as Category[]).forEach((cat) => {
    classCatalogue[cat].subgroups.forEach((sg) => {
      sg.items.forEach((item) => {
        if (item.coach === coachName) {
          out.push({ category: cat, name: item.name, level: item.level, time: item.time, dur: item.dur });
        }
      });
    });
  });
  return out;
}
