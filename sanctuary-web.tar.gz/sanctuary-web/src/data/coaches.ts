// Coach registry — single source of truth for instructor names, specialties,
// and bios. Class/service data (catalogue.ts) references coaches by name;
// this file is where the Team page and any "meet your coach" UI reads from.
// In production this becomes the `trainer_profiles` table (Phase 3 schema).

export interface Coach {
  slug: string;
  name: string;
  role: string; // headline specialty shown on cards, e.g. "Dance · Beginner"
  category: "Dance" | "Fitness" | "Recovery" | "Mindfulness" | "Concierge";
  bio: string;
  certifications?: string;
  initial: string;
}

export const coaches: Coach[] = [
  {
    slug: "akshita",
    name: "Akshita",
    role: "Dance · Beginner",
    category: "Dance",
    bio: "Akshita leads every member's first steps into Hip Hop and Bollywood — patient, precise, and big on making beginners feel like dancers on day one.",
    certifications: "Certified dance instructor, 6 years teaching",
    initial: "A",
  },
  {
    slug: "pallavi",
    name: "Pallavi",
    role: "Zumba",
    category: "Fitness",
    bio: "Pallavi's Zumba sessions are the loudest room in the club, on purpose. High energy, full-body, and always ends with everyone smiling.",
    certifications: "Licensed Zumba instructor",
    initial: "P",
  },
  {
    slug: "sahil",
    name: "Sahil",
    role: "Yoga",
    category: "Fitness",
    bio: "Sahil teaches Power and Restorative Yoga with equal ease — strong sequencing for those who want a challenge, deep stillness for those who need rest.",
    certifications: "RYT-200 certified",
    initial: "S",
  },
  {
    slug: "vikram",
    name: "Vikram",
    role: "Hip Hop, Boxing & Kickboxing",
    category: "Dance",
    bio: "Vikram brings a performer's precision to Hip Hop and a fighter's discipline to Boxing — intermediate and advanced dancers train with him.",
    certifications: "Choreographer, certified boxing coach",
    initial: "V",
  },
  {
    slug: "meera",
    name: "Meera",
    role: "Yoga & Breathwork",
    category: "Recovery",
    bio: "Meera holds the club's Restorative Yoga, Vinyasa, and Aqua Yoga practice — a steady, quiet presence for members winding down.",
    certifications: "RYT-500 certified",
    initial: "M",
  },
  {
    slug: "rohan",
    name: "Rohan",
    role: "Strength & Conditioning",
    category: "Fitness",
    bio: "Rohan heads Strength & Conditioning and Sanctuary's coaching team — every trainer's protocols pass through him first.",
    certifications: "Head Coach · NSCA certified",
    initial: "R",
  },
  {
    slug: "priya",
    name: "Priya",
    role: "HIIT, HYROX & Aqua Fit",
    category: "Fitness",
    bio: "Priya runs the club's performance track — HIIT, Aerobics, HYROX Prep, and the early Morning Run Club.",
    certifications: "HYROX-certified coach",
    initial: "P",
  },
  {
    slug: "ananya",
    name: "Ananya",
    role: "Pilates & Barre",
    category: "Fitness",
    bio: "Ananya's Mat Pilates and Barre classes are precise, low-impact, and quietly demanding — a favourite for building control.",
    certifications: "Certified Pilates instructor",
    initial: "A",
  },
  {
    slug: "karan",
    name: "Karan",
    role: "Mobility & Assisted Stretch",
    category: "Recovery",
    bio: "Karan leads Mobility Reset and 1:1 Assisted Stretch — the coach most members book the week before a big event.",
    certifications: "Certified movement therapist",
    initial: "K",
  },
  {
    slug: "aarav",
    name: "Aarav",
    role: "Breathwork & Meditation",
    category: "Mindfulness",
    bio: "Aarav teaches Coherent and Wim Hof breathwork, and closes most weeknights with Meditation.",
    certifications: "Breathwork facilitator",
    initial: "A",
  },
  {
    slug: "ritika",
    name: "Ritika",
    role: "Recovery Coach",
    category: "Recovery",
    bio: "Ritika oversees Recovery Reset and Contrast Therapy, and is the voice behind most of your Concierge whispers.",
    certifications: "Recovery & regeneration specialist",
    initial: "R",
  },
];

export function coachBySlug(slug: string) {
  return coaches.find((c) => c.slug === slug);
}

export function coachByName(name: string) {
  return coaches.find((c) => c.name === name);
}
