import Link from "next/link";
import { coaches } from "@/data/coaches";
import TeamPageClient from "./TeamPageClient";

export const metadata = {
  title: "The Team — Sanctuary",
};

export default function TeamPage() {
  return <TeamPageClient coaches={coaches} />;
}
