"use client";

import Link from "next/link";
import { Coach } from "@/data/coaches";

const order: Coach["category"][] = ["Dance", "Fitness", "Recovery", "Mindfulness", "Concierge"];

export default function TeamPageClient({ coaches }: { coaches: Coach[] }) {
  return (
    <div className="app">
      <div className="topbar">
        <Link href="/" className="back-link" aria-label="Back to Sanctuary">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </Link>
        <div className="brandmark" style={{ position: "absolute", left: "50%", transform: "translateX(-50%)" }}>
          <span>THE TEAM</span>
        </div>
        <div style={{ width: 36 }} />
      </div>

      <div className="screens">
        <div className="screen active" style={{ position: "static", opacity: 1, transform: "none" }}>
          <div className="eyebrow">Sanctuary</div>
          <h1 className="headline">The people who hold it.</h1>
          <p className="lede">Every ritual, class, and whisper comes from someone. Here they are.</p>

          {order.map((cat) => {
            const members = coaches.filter((c) => c.category === cat);
            if (!members.length) return null;
            return (
              <div key={cat}>
                <div className="cat-head">{cat}</div>
                {members.map((c) => (
                  <Link href={`/team/${c.slug}`} className="coach-card" key={c.slug}>
                    <div className="coach-avatar">{c.initial}</div>
                    <div className="coach-info">
                      <div className="coach-name">{c.name}</div>
                      <div className="coach-role">{c.role}</div>
                    </div>
                    <span className="chev">›</span>
                  </Link>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
