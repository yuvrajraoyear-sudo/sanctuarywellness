"use client";

import Link from "next/link";
import { Coach } from "@/data/coaches";
import { classesByCoach } from "@/data/catalogue";

export default function CoachPageClient({ coach }: { coach: Coach }) {
  const classes = classesByCoach(coach.name);

  return (
    <div className="app">
      <div className="topbar">
        <Link href="/team" className="back-link" aria-label="Back to the team">
          <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth="1.6">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </Link>
        <div className="brandmark" style={{ position: "absolute", left: "50%", transform: "translateX(-50%)" }}>
          <span>SANCTUARY</span>
        </div>
        <div style={{ width: 36 }} />
      </div>

      <div className="screens">
        <div className="screen active" style={{ position: "static", opacity: 1, transform: "none" }}>
          <div className="avatarrow">
            <div className="bigav">{coach.initial}</div>
            <div>
              <div className="bigname">{coach.name}</div>
              <div className="bigsub">{coach.role}</div>
            </div>
          </div>

          <p className="lede">{coach.bio}</p>
          {coach.certifications && (
            <div className="card hairline" style={{ marginTop: 4 }}>
              <div className="listrow" style={{ borderTop: "none" }}>
                <div>
                  <div className="lname">Certification</div>
                  <div className="lsub">{coach.certifications}</div>
                </div>
              </div>
            </div>
          )}

          {classes.length > 0 && (
            <>
              <div className="section-lbl"><h3>Teaching this week</h3></div>
              <div className="card hairline" style={{ padding: "4px 18px" }}>
                {classes.map((c, i) => (
                  <div className="ledger-row" key={i}>
                    <div>
                      <div className="ledger-name">
                        {c.name}
                        {c.level && <span className={`level-badge level-${c.level}`} style={{ marginLeft: 7 }}>{c.level}</span>}
                      </div>
                      <div className="ledger-when">{c.category} · {c.dur}</div>
                    </div>
                    <div className="ledger-delta minus" style={{ color: "var(--stone-600)" }}>{c.time}</div>
                  </div>
                ))}
              </div>
            </>
          )}

          <Link href="/" className="btn btn-primary btn-block" style={{ marginTop: 24, textDecoration: "none", textAlign: "center" }}>
            Back to Sanctuary
          </Link>
        </div>
      </div>
    </div>
  );
}
