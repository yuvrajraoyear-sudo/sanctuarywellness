import { coaches, coachBySlug } from "@/data/coaches";
import { notFound } from "next/navigation";
import CoachPageClient from "./CoachPageClient";

export function generateStaticParams() {
  return coaches.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const coach = coachBySlug(slug);
  return { title: coach ? `${coach.name} — Sanctuary` : "Team — Sanctuary" };
}

export default async function CoachPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const coach = coachBySlug(slug);
  if (!coach) notFound();
  return <CoachPageClient coach={coach} />;
}
