# Sanctuary — Web App

The Sanctuary member app, rebuilt as a real Next.js project (App Router, TypeScript). This replaces the single-file prototype — same design, same flows, now a proper codebase you can run locally, push to GitHub, and deploy to Vercel.

## What's in this version

- **5-tab member app** — Arrival, Rituals (Rituals · Services · Classes), Timeline, Membership, Signature
- **Credit wallet** — Basic · Quarterly plan, per-class pricing, slot-hold countdown, low-balance top-up flow
- **Concierge** — attributed whispers, structured action cards, safety-phrase handoff
- **The Team** — a real route (`/team` and `/team/[slug]`) listing every coach with their bio and weekly classes, linked from every class listing ("by Akshita") and from Signature
- All content — rituals, classes, coaches, pricing — lives in typed files under `src/data/`, not hardcoded in components

## Running it locally

```bash
npm install
cp .env.example .env.local   # fill in your Supabase keys (see below)
npm run dev
```

Open http://localhost:3000.

## Deploying to Vercel

1. Push this project to a GitHub repo.
2. In Vercel: **New Project** → import the repo.
3. Add the environment variables from `.env.example` under **Settings → Environment Variables**.
4. Deploy. Vercel auto-detects Next.js — no config needed.

## Connecting Supabase (do this before real members use it)

The Supabase client is already wired (`src/lib/supabase/client.ts` for the browser, `src/lib/supabase/server.ts` for server-side code) — it just needs your project's credentials and a schema.

1. In your Supabase project: **Settings → API** → copy the Project URL and `anon public` key into `.env.local` / Vercel env vars as `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
2. Also copy the `service_role` key into `SUPABASE_SERVICE_ROLE_KEY` — **server-only**, never expose this to the browser. It's for the backend work below.
3. The database schema itself (members, rituals, reservations, the credit wallet ledger, RLS policies) is **not built yet** — see "What's still needed" below.

## What's still needed before this is a real, launchable product

This is the frontend only, matching your instruction. Three things stand between this and a live product:

### 1. The backend (the big one)
Right now the wallet balance, bookings, and class availability all live in-memory in the browser — they reset on refresh and aren't shared between members or devices. A real backend needs:
- **Database schema** on Supabase Postgres — members, rituals, sessions, reservations, the credit ledger, with row-level security so members can only see their own data
- **Server-side wallet logic** — credit deductions must happen in a database function or API route, never in the browser, so a member can't just edit their balance in devtools
- **Auth** — Supabase Auth (email OTP, matching the docs) so `/team` is public but the app itself requires sign-in

### 2. Payments (Razorpay)
Wallet top-ups currently credit instantly on the client for demo purposes. Real top-ups need:
- Razorpay Checkout opened from the top-up sheet
- A webhook endpoint that verifies the payment server-side and *then* credits the wallet — never trust a client-side "payment succeeded" signal

### 3. Real content
Class times, instructor assignments, and rituals are currently typed data in `src/data/`. Long-term these move into the database (or a CMS) so staff can update the schedule without a code deploy.

**My recommendation:** tackle the backend next — it's the dependency for both payments and dynamic content. I can scaffold the Supabase schema and the API routes when you're ready.

## Project structure

```
src/
  app/                  Next.js routes (page.tsx = home, team/ = coach pages)
  components/
    screens/             The 5 tab screens
    sheets/              Bottom sheets (ritual, booking, top-up, concierge)
  data/
    catalogue.ts          Rituals, classes, pricing
    coaches.ts             Coach registry
  lib/
    wallet.tsx             Credit wallet state (React context — swap for Supabase later)
    toast.tsx, sheets.tsx, booking.tsx    Shared UI state
    supabase/               Client + server Supabase setup (ready, not yet connected to a schema)
  styles/globals.css      Design tokens + all component styles
```
